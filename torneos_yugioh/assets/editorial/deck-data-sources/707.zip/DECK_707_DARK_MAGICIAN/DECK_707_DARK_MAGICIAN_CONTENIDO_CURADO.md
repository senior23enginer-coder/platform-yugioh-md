# Dark Magician


## IDENTIDAD BÁSICA

- `deck_id`: **707**
- Nombre registrado: **Dark Magician**
- Formato: **rush_duel**
- Main: **30**; Extra: **7**; Side: **0**; Reserva: **0**.


## PERFIL BREVE — CONOCE TU DECK

- **Arquetipo:** Dark Magician de Rush Duel, con habilidad Illusion of Execution.
- **Tipo de estrategia:** apoyo de Mágicas, acceso al nombre Mago Oscuro y Fusiones condicionadas.
- **Estilo de juego:** control por herramientas Mágicas y desarrollo de monstruos Lanzadores de Conjuros.
- **Cómo se juega:** Mago Oscuro habilita cartas de apoyo como Mil Cuchillos y Ataque Mágico Oscuro cuando se cumplen sus condiciones; la Skill y las Fusiones registradas deben tratarse según sus textos y materiales exactos.
- **Cartas representativas:** Dark Magician, Dark Eradicator Warlock, Thousand Knives, Dark Magic Attack e Illusion of Execution.
- **Qué vigilar:** nombre temporal, turno habilitado de la Skill y acceso real a los materiales de Fusión.

## CARTAS: FUNCIÓN, RESTRICCIONES Y UTILIDAD

#### 01. Ataque Mágico Oscuro

![Carta Rush CID 15451](imagenes/rush/15451.png)

- **Zona y copias:** Main **2x**. CID Rush: **15451**.
- **Rol funcional:** Carta Mágica Normal — removal / apertura de campo.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Requisito específico:** Controlar un Mago Oscuro boca arriba.
- **Efecto / resultado concreto:** Destruye todas las cartas Mágicas y Trampas del campo rival.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15451&ope=2
- **Contraste de fuente Rush:** CID 15451: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Destruye todas las cartas Mágicas y Trampas del campo rival.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Ataque Mágico Oscuro**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Destruye todas las cartas Mágicas y Trampas del campo rival.
- **Cómo aprovecharla en este deck:** Destruye todas las cartas Mágicas y Trampas del campo rival.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Cuándo tener precaución:** el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 02. Distribuidor Maravilloso

![Carta Rush CID 16772](imagenes/rush/16772.png)

- **Zona y copias:** Main **1x**. CID Rush: **16772**.
- **Rol funcional:** Monstruo de Efecto — consistencia / reciclaje.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Requisito específico:** Tener hasta tres monstruos en el Cementerio y pagar 300 LP.
- **Efecto / resultado concreto:** Enviar tres cartas de la mano al Cementerio y robar tres cartas.
- **Ir primero, segundo y juego tardío:** Primero: priorizar consistencia sin comprometer piezas de Fusión; segundo: buscar la carta que falta para superar el campo rival; tardío: solo aporta ventaja si queda un objetivo y su coste puede pagarse.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=16772&ope=2
- **Contraste de fuente Rush:** CID 16772: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Enviar tres cartas de la mano al Cementerio y robar tres cartas.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Distribuidor Maravilloso**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Enviar tres cartas de la mano al Cementerio y robar tres cartas.
- **Cómo aprovecharla en este deck:** Enviar tres cartas de la mano al Cementerio y robar tres cartas.
- **Uso y consumo de recursos:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 03. Maga Legendaria

![Carta Rush CID 18685](imagenes/rush/18685.png)

- **Zona y copias:** Main **2x**. CID Rush: **18685**.
- **Rol funcional:** Monstruo de Efecto — monstruo de apoyo/material o recurso de Sacrificio.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Requisito específico:** No tiene requisito de activación.
- **Efecto / resultado concreto:** Revelar las tres cartas superiores; puede enviar un monstruo revelado al Cementerio y recuperar un monstruo Normal LEGEND del Cementerio.
- **Ir primero, segundo y juego tardío:** Primero: conservarlo si es material expresamente exigido por una Fusión o Sacrificio; segundo: emplearlo como cuerpo solo tras calcular ATK y riesgo de batalla; tardío: recurso para reconstruir material desde el GY si una carta lo autoriza.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=18685&ope=2
- **Contraste de fuente Rush:** CID 18685: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Revelar las tres cartas superiores; puede enviar un monstruo revelado al Cementerio y recuperar un monstruo Normal LEGEND del Cementerio.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Maga Legendaria**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Revelar las tres cartas superiores; puede enviar un monstruo revelado al Cementerio y recuperar un monstruo Normal LEGEND del Cementerio.
- **Cómo aprovecharla en este deck:** Revelar las tres cartas superiores; puede enviar un monstruo revelado al Cementerio y recuperar un monstruo Normal LEGEND del Cementerio.
- **Uso y consumo de recursos:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Cuándo tener precaución:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 04. Mago Oscuro Sabio

![Carta Rush CID 19597](imagenes/rush/19597.png)

- **Zona y copias:** Main **1x**. CID Rush: **19597**.
- **Rol funcional:** Monstruo de Efecto — extensión de campo y recuperación de recursos.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Requisito específico:** Enviar desde la mano al Cementerio un Lanzador de Conjuros/OSCURIDAD.
- **Efecto / resultado concreto:** Roba una carta; después puede Invocar de Modo Especial un Mago Oscuro del Cementerio.
- **Ir primero, segundo y juego tardío:** Primero: priorizar consistencia sin comprometer piezas de Fusión; segundo: buscar la carta que falta para superar el campo rival; tardío: solo aporta ventaja si queda un objetivo y su coste puede pagarse.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19597&ope=2
- **Contraste de fuente Rush:** CID 19597: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Roba una carta; después puede Invocar de Modo Especial un Mago Oscuro del Cementerio.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Mago Oscuro Sabio**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Roba una carta; después puede Invocar de Modo Especial un Mago Oscuro del Cementerio.
- **Cómo aprovecharla en este deck:** Roba una carta; después puede Invocar de Modo Especial un Mago Oscuro del Cementerio.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 05. Grito de Monstruo

![Carta Rush CID 19329](imagenes/rush/19329.png)

- **Zona y copias:** Main **2x**. CID Rush: **19329**.
- **Rol funcional:** Carta Mágica Normal — extensión de campo y recuperación de recursos.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Requisito específico:** Enviar de la mano un monstruo al Cementerio.
- **Efecto / resultado concreto:** Roba una carta; después puede Invocar del Cementerio un monstruo sin efecto que tenga ATK 2000 o DEF 2100.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19329&ope=2
- **Contraste de fuente Rush:** CID 19329: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Roba una carta; después puede Invocar del Cementerio un monstruo sin efecto que tenga ATK 2000 o DEF 2100.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Grito de Monstruo**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Roba una carta; después puede Invocar del Cementerio un monstruo sin efecto que tenga ATK 2000 o DEF 2100.
- **Cómo aprovecharla en este deck:** Roba una carta; después puede Invocar del Cementerio un monstruo sin efecto que tenga ATK 2000 o DEF 2100.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 06. Hechicero Eliminador Oscuro

![Carta Rush CID 19773](imagenes/rush/19773.png)

- **Zona y copias:** Main **3x**. CID Rush: **19773**.
- **Rol funcional:** Monstruo de Efecto — apoyo situacional sujeto a condición escrita.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan….
- **Requisito específico:** Enviar la primera carta de tu Deck al Cementerio.
- **Efecto / resultado concreto:** Se llama Mago Oscuro ese turno; puede devolver diez Mágicas del Cementerio al Deck para destruir un monstruo rival boca arriba de Nivel 8 o inferior.
- **Ir primero, segundo y juego tardío:** Primero: construir la condición de activación; segundo: verificar que la jugada responde al estado rival actual; tardío: ahorrar el recurso si todavía no se cumple el requisito.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19773&ope=2
- **Contraste de fuente Rush:** CID 19773: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Se llama Mago Oscuro ese turno; puede devolver diez Mágicas del Cementerio al Deck para destruir un monstruo rival boca arriba de Nivel 8 o inferior.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Hechicero Eliminador Oscuro**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Se llama Mago Oscuro ese turno; puede devolver diez Mágicas del Cementerio al Deck para destruir un monstruo rival boca arriba de Nivel 8 o inferior.
- **Cómo aprovecharla en este deck:** Se llama Mago Oscuro ese turno; puede devolver diez Mágicas del Cementerio al Deck para destruir un monstruo rival boca arriba de Nivel 8 o inferior.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan….
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 07. Ráfaga de Resonancia Oscura

![Carta Rush CID 17209](imagenes/rush/17209.png)

- **Zona y copias:** Main **3x**. CID Rush: **17209**.
- **Rol funcional:** Carta Mágica Normal — presión de combate / modificación de estadísticas.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Requisito específico:** Sin requisito de activación.
- **Efecto / resultado concreto:** Otorga 1000 ATK por el turno a un Lanzador de Conjuros OSCURIDAD propio de Nivel 6+; otorga otros 1000 si controlas Mago Oscuro o Chica Maga Oscura.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=17209&ope=2
- **Contraste de fuente Rush:** CID 17209: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Otorga 1000 ATK por el turno a un Lanzador de Conjuros OSCURIDAD propio de Nivel 6+; otorga otros 1000 si controlas Mago Oscuro o Chica Maga Oscura.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Ráfaga de Resonancia Oscura**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Otorga 1000 ATK por el turno a un Lanzador de Conjuros OSCURIDAD propio de Nivel 6+; otorga otros 1000 si controlas Mago Oscuro o Chica Maga Oscura.
- **Cómo aprovecharla en este deck:** Otorga 1000 ATK por el turno a un Lanzador de Conjuros OSCURIDAD propio de Nivel 6+; otorga otros 1000 si controlas Mago Oscuro o Chica Maga Oscura.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Cuándo tener precaución:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 08. Brillo Sombrío

![Carta Rush CID 20151](imagenes/rush/20151.png)

- **Zona y copias:** Main **2x**. CID Rush: **20151**.
- **Rol funcional:** Carta de Trampa Normal — consistencia / reciclaje.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución.
- **Requisito específico:** Cuando el rival Invoca un monstruo en su turno; enviar una carta de la mano al Cementerio.
- **Efecto / resultado concreto:** Pone hasta dos monstruos de Efecto boca arriba de cualquier Campo boca abajo en Defensa; si incluyó un monstruo rival con ATK original de al menos 2600, recupera 1500 LP.
- **Ir primero, segundo y juego tardío:** Primero: Colocar y reservar la respuesta para la ventana legal; segundo: tras side y cambio de turno, evaluar si puede activarse a tiempo; tardío: no asumir efecto si falta el objetivo o el estado de campo.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=20151&ope=2
- **Contraste de fuente Rush:** CID 20151: fuente oficial Rush consultada en japonés; tipo Carta de Trampa Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Pone hasta dos monstruos de Efecto boca arriba de cualquier Campo boca abajo en Defensa; si incluyó un monstruo rival con ATK original de al menos 2600, recupera 1500 LP.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Brillo Sombrío**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Pone hasta dos monstruos de Efecto boca arriba de cualquier Campo boca abajo en Defensa; si incluyó un monstruo rival con ATK original de al menos 2600, recupera 1500 LP.
- **Cómo aprovecharla en este deck:** Pone hasta dos monstruos de Efecto boca arriba de cualquier Campo boca abajo en Defensa; si incluyó un monstruo rival con ATK original de al menos 2600, recupera 1500 LP.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución.
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 09. Piedra de los Magos Oscuros

![Carta Rush CID 19598](imagenes/rush/19598.png)

- **Zona y copias:** Main **3x**. CID Rush: **19598**.
- **Rol funcional:** Carta Mágica Normal — extensor / habilitador de material.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Requisito específico:** Sin requisito de activación.
- **Efecto / resultado concreto:** Invoca desde la mano y/o Cementerio hasta un Lanzador de Conjuros OSCURIDAD con 2500 ATK y hasta otro con 2000 ATK, boca arriba.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19598&ope=2
- **Contraste de fuente Rush:** CID 19598: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Invoca desde la mano y/o Cementerio hasta un Lanzador de Conjuros OSCURIDAD con 2500 ATK y hasta otro con 2000 ATK, boca arriba.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Piedra de los Magos Oscuros**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Invoca desde la mano y/o Cementerio hasta un Lanzador de Conjuros OSCURIDAD con 2500 ATK y hasta otro con 2000 ATK, boca arriba.
- **Cómo aprovecharla en este deck:** Invoca desde la mano y/o Cementerio hasta un Lanzador de Conjuros OSCURIDAD con 2500 ATK y hasta otro con 2000 ATK, boca arriba.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Cuándo tener precaución:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 10. Mago Oscuro

![Carta Rush CID 15410](imagenes/rush/15410.png)

- **Zona y copias:** Main **1x**. CID Rush: **15410**.
- **Rol funcional:** Monstruo Normal — material de Fusión/Sacrificio o presencia de combate; sin efecto activado.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Requisito específico:** No tiene efecto.
- **Efecto / resultado concreto:** Monstruo Normal LEGEND.
- **Ir primero, segundo y juego tardío:** Primero: conservarlo si es material expresamente exigido por una Fusión o Sacrificio; segundo: emplearlo como cuerpo solo tras calcular ATK y riesgo de batalla; tardío: recurso para reconstruir material desde el GY si una carta lo autoriza.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15410&ope=2
- **Contraste de fuente Rush:** CID 15410: fuente oficial Rush consultada en japonés; tipo Monstruo Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Monstruo Normal LEGEND.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Mago Oscuro**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Monstruo Normal LEGEND.
- **Cómo aprovecharla en este deck:** Monstruo Normal LEGEND.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Cuándo tener precaución:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 11. Lily Aniquiladora

![Carta Rush CID 20305](imagenes/rush/20305.png)

- **Zona y copias:** Main **1x**. CID Rush: **20305**.
- **Rol funcional:** Monstruo de Efecto — apoyo situacional sujeto a condición escrita.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Requisito específico:** Haber sido Invocada de Modo Normal este turno.
- **Efecto / resultado concreto:** Envía la primera carta del Deck al Cementerio; si era Lanzador de Conjuros, esta carta cuenta por dos Sacrificios para un Lanzador de Conjuros/OSCURIDAD en Ataque este turno.
- **Ir primero, segundo y juego tardío:** Primero: construir la condición de activación; segundo: verificar que la jugada responde al estado rival actual; tardío: ahorrar el recurso si todavía no se cumple el requisito.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=20305&ope=2
- **Contraste de fuente Rush:** CID 20305: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Envía la primera carta del Deck al Cementerio; si era Lanzador de Conjuros, esta carta cuenta por dos Sacrificios para un Lanzador de Conjuros/OSCURIDAD en Ataque este turno.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Lily Aniquiladora**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Envía la primera carta del Deck al Cementerio; si era Lanzador de Conjuros, esta carta cuenta por dos Sacrificios para un Lanzador de Conjuros/OSCURIDAD en Ataque este turno.
- **Cómo aprovecharla en este deck:** Envía la primera carta del Deck al Cementerio; si era Lanzador de Conjuros, esta carta cuenta por dos Sacrificios para un Lanzador de Conjuros/OSCURIDAD en Ataque este turno.
- **Uso y consumo de recursos:** Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano.
- **Cuándo tener precaución:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 12. Chica Maga Oscura

![Carta Rush CID 16371](imagenes/rush/16371.png)

- **Zona y copias:** Main **3x**. CID Rush: **16371**.
- **Rol funcional:** Monstruo de Efecto — presión de combate / modificación de estadísticas.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Requisito específico:** No necesita activación.
- **Efecto / resultado concreto:** Gana 500 ATK por cada Mago Oscuro en ambos Cementerios.
- **Ir primero, segundo y juego tardío:** Primero: preparar acceso y campo necesario sin gastar la respuesta antes de tiempo; segundo: usarla para abrir combate o retirar la amenaza que cumple su condición; tardío: evaluar si quedan objetivos reales.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=16371&ope=2
- **Contraste de fuente Rush:** CID 16371: fuente oficial Rush consultada en japonés; tipo Monstruo de Efecto; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Gana 500 ATK por cada Mago Oscuro en ambos Cementerios.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Chica Maga Oscura**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Gana 500 ATK por cada Mago Oscuro en ambos Cementerios.
- **Cómo aprovecharla en este deck:** Gana 500 ATK por cada Mago Oscuro en ambos Cementerios.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Cuándo tener precaución:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 13. Mil Cuchillos

![Carta Rush CID 15450](imagenes/rush/15450.png)

- **Zona y copias:** Main **2x**. CID Rush: **15450**.
- **Rol funcional:** Carta Mágica Normal — removal / apertura de campo.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Requisito específico:** Controlar un Mago Oscuro boca arriba.
- **Efecto / resultado concreto:** Destruye un monstruo del Campo rival.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15450&ope=2
- **Contraste de fuente Rush:** CID 15450: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Destruye un monstruo del Campo rival.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Mil Cuchillos**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Destruye un monstruo del Campo rival.
- **Cómo aprovecharla en este deck:** Destruye un monstruo del Campo rival.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Cuándo tener precaución:** el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 14. ¡Equitación Lindasesina!

![Carta Rush CID 19341](imagenes/rush/19341.png)

- **Zona y copias:** Main **1x**. CID Rush: **19341**.
- **Rol funcional:** Carta de Trampa Normal — extensor / habilitador de material.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Requisito específico:** Cuando el rival Invoca boca arriba un monstruo de Efecto.
- **Efecto / resultado concreto:** Invoca del Cementerio en Ataque propio un monstruo cuyo ATK no supere el del recién invocado; después puede reducir en 1800 ATK hasta dos monstruos rivales boca arriba ese turno.
- **Ir primero, segundo y juego tardío:** Primero: Colocar y reservar la respuesta para la ventana legal; segundo: tras side y cambio de turno, evaluar si puede activarse a tiempo; tardío: no asumir efecto si falta el objetivo o el estado de campo.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19341&ope=2
- **Contraste de fuente Rush:** CID 19341: fuente oficial Rush consultada en japonés; tipo Carta de Trampa Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Invoca del Cementerio en Ataque propio un monstruo cuyo ATK no supere el del recién invocado; después puede reducir en 1800 ATK hasta dos monstruos rivales boca arriba ese turno.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — ¡Equitación Lindasesina!**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Invoca del Cementerio en Ataque propio un monstruo cuyo ATK no supere el del recién invocado; después puede reducir en 1800 ATK hasta dos monstruos rivales boca arriba ese turno.
- **Cómo aprovecharla en este deck:** Invoca del Cementerio en Ataque propio un monstruo cuyo ATK no supere el del recién invocado; después puede reducir en 1800 ATK hasta dos monstruos rivales boca arriba ese turno.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Cuándo tener precaución:** comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 15. Orden Secreta

![Carta Rush CID 17212](imagenes/rush/17212.png)

- **Zona y copias:** Main **1x**. CID Rush: **17212**.
- **Rol funcional:** Carta Mágica Normal — recurso táctico cuya condición y resultado están descritos en su ficha.
- **Estado de sinergia y función:** Sinergia directa descrita. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: la condición de una Mágica/Trampa y sus blancos deben cumplirse antes de resolver. No confundir esta carta con un monstruo….
- **Requisito específico:** Sin requisito de activación.
- **Efecto / resultado concreto:** Invoca un monstruo Normal de Nivel 7 desde mano o Cementerio; le da 700 ATK ese turno y lo protege frente a destrucción por Trampas rivales.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** **ILLUSION OF EXECUTION** permite enviar «Mago Oscuro» desde Deck al GY bajo sus condiciones; puede alimentar recuperación, pero la Skill solo se usa una vez por duelo.
- **Riesgos y dependencias:** la condición de una Mágica/Trampa y sus blancos deben cumplirse antes de resolver. No confundir esta carta con un monstruo ni usarla como material.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=17212&ope=2
- **Contraste de fuente Rush:** CID 17212: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Invoca un monstruo Normal de Nivel 7 desde mano o Cementerio; le da 700 ATK ese turno y lo protege frente a destrucción por Trampas rivales.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Orden Secreta**

- **Label funcional:** Sinergia directa. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Invoca un monstruo Normal de Nivel 7 desde mano o Cementerio; le da 700 ATK ese turno y lo protege frente a destrucción por Trampas rivales.
- **Cómo aprovecharla en este deck:** Invoca un monstruo Normal de Nivel 7 desde mano o Cementerio; le da 700 ATK ese turno y lo protege frente a destrucción por Trampas rivales.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: la condición de una Mágica/Trampa y sus blancos deben cumplirse antes de resolver. No confundir esta carta con un monstruo….
- **Cuándo tener precaución:** la condición de una Mágica/Trampa y sus blancos deben cumplirse antes de resolver. No confundir esta carta con un monstruo ni usarla como material.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 16. Olla de la Codicia

![Carta Rush CID 16372](imagenes/rush/16372.png)

- **Zona y copias:** Main **1x**. CID Rush: **16372**.
- **Rol funcional:** Carta Mágica Normal — consistencia / reciclaje.
- **Estado de sinergia y función:** Sinergia indirecta de recursos. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Material o destino del Extra condicionado a los requisitos de invocación.
- **Requisito específico:** Sin requisito de activación.
- **Efecto / resultado concreto:** Roba dos cartas.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=16372&ope=2
- **Contraste de fuente Rush:** CID 16372: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Roba dos cartas. Aportación posible como material, coste o objetivo; verificar consumidor.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Olla de la Codicia**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Roba dos cartas.
- **Cómo aprovecharla en este deck:** Roba dos cartas. Aportación posible como material, coste o objetivo; verificar consumidor.
- **Uso y consumo de recursos:** Material o destino del Extra condicionado a los requisitos de invocación.
- **Cuándo tener precaución:** disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 17. Maldición de la Luz Ascendente

![Carta Rush CID 21007](imagenes/rush/21007.png)

- **Zona y copias:** Main **1x**. CID Rush: **21007**.
- **Rol funcional:** Carta Mágica Normal — consistencia / reciclaje.
- **Estado de sinergia y función:** Sinergia indirecta (soporte o recursos). Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Requisito específico:** El rival debe tener una o ninguna carta en mano.
- **Efecto / resultado concreto:** Cambia un monstruo rival a Ataque boca arriba o Defensa boca abajo. Si el rival activó una Trampa ese turno o es el primer turno del jugador segundo, ambos roban dos.
- **Ir primero, segundo y juego tardío:** Primero: usarla si su efecto abre recursos o deja protección aprovechable; segundo: priorizar su resultado concreto frente a las amenazas rivales; tardío: comprobar materiales, objetivos y si aún quedan recursos en Deck o Cementerio.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=21007&ope=2
- **Contraste de fuente Rush:** CID 21007: fuente oficial Rush consultada en japonés; tipo Carta Mágica Normal; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Cambia un monstruo rival a Ataque boca arriba o Defensa boca abajo.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Maldición de la Luz Ascendente**

- **Label funcional:** Sinergia indirecta. Clasificación documental; una relación es válida solo si se satisfacen sus condiciones exactas.
- **Qué hace:** Cambia un monstruo rival a Ataque boca arriba o Defensa boca abajo. Si el rival activó una Trampa ese turno o es el primer turno del jugador segundo, ambos roban dos.
- **Cómo aprovecharla en este deck:** Cambia un monstruo rival a Ataque boca arriba o Defensa boca abajo.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Cuándo tener precaución:** disponer de cartas suficientes en Deck y distinguir robo de búsqueda.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.


#### 18. Gaia el Campeón Dragón Rápido

![Carta Rush CID 19995](imagenes/rush/19995.png)

- **Zona y copias:** Extra **3x**. CID Rush: **19995**.
- **Rol funcional:** Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre.
- **Estado de sinergia y función:** Sin acceso demostrado con el inventario. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Requisito específico:** Fusionar un Guerrero con DEF 2100 y Maldición de Dragón; para el efecto, enviar la carta superior del Deck al Cementerio.
- **Efecto / resultado concreto:** Inflige daño de penetración este turno y, si la mano está vacía, puede robar una carta.
- **Ir primero, segundo y juego tardío:** Primero: preparar materiales y «Fusión» si es alcanzable; segundo: considerar el efecto de campo o daño que se produzca tras una Fusión legal; tardío: comprobar si quedan materiales nombrados en campo y Extra.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19995&ope=2
- **Contraste de fuente Rush:** CID 19995: fuente oficial Rush consultada en japonés; tipo Monstruo de Fusión; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Gaia el Campeón Dragón Rápido**

- **Label funcional:** **SIN ACCESO CON EL MAIN ACTUAL**: falta Curse of Dragon, material obligatorio; **probar quitar sus 3 copias** si el dueño aprueba.
- **Qué hace:** Inflige daño de penetración este turno y, si la mano está vacía, puede robar una carta.
- **Cómo aprovecharla en este deck:** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo….
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo de búsqueda. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.

**CÓMO LLEGAR DESDE TU DECK — SIN RUTA DEMOSTRADA**

- La biblioteca actual no contiene una ruta identificada para esta carta del Extra. No se debe exhibir una descripción genérica como sustituto de mano inicial, materiales y pasos. Para completarla, contrastar requisitos oficiales y recursos del Main; si no es alcanzable, explicar el impedimento exacto.

#### 19. Gaia el Campeón Dragón

![Carta Rush CID 18298](imagenes/rush/18298.png)

- **Zona y copias:** Extra **3x**. CID Rush: **18298**.
- **Rol funcional:** Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre.
- **Estado de sinergia y función:** Sin acceso demostrado con el inventario. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte. verificar en campo….
- **Requisito específico:** Materiales nombrados: Gaia el Caballero Feroz y Maldición de Dragón.
- **Efecto / resultado concreto:** Monstruo Fusión sin efecto activado.
- **Ir primero, segundo y juego tardío:** Primero: preparar materiales y «Fusión» si es alcanzable; segundo: considerar el efecto de campo o daño que se produzca tras una Fusión legal; tardío: comprobar si quedan materiales nombrados en campo y Extra.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte. verificar en campo los materiales nombrados y el momento legal de la Fusión Rush; no usar materiales de mano sin permiso textual. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=18298&ope=2
- **Contraste de fuente Rush:** CID 18298: fuente oficial Rush consultada en japonés; tipo Monstruo de Fusión; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Gaia el Campeón Dragón**

- **Label funcional:** **SIN ACCESO CON EL MAIN ACTUAL**: faltan Gaia the Fierce Knight y Curse of Dragon; **probar quitar sus 3 copias** si el dueño aprueba.
- **Qué hace:** Monstruo Fusión sin efecto activado.
- **Cómo aprovecharla en este deck:** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte. verificar en campo….
- **Cuándo tener precaución:** no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte. verificar en campo los materiales nombrados y el momento legal de la Fusión Rush; no usar materiales de mano sin permiso textual. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.

**CÓMO LLEGAR DESDE TU DECK — SIN RUTA DEMOSTRADA**

- La biblioteca actual no contiene una ruta identificada para esta carta del Extra. No se debe exhibir una descripción genérica como sustituto de mano inicial, materiales y pasos. Para completarla, contrastar requisitos oficiales y recursos del Main; si no es alcanzable, explicar el impedimento exacto.

#### 20. Gaia, el Conquistador de Campeones

![Carta Rush CID 19323](imagenes/rush/19323.png)

- **Zona y copias:** Extra **1x**. CID Rush: **19323**.
- **Rol funcional:** Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre.
- **Estado de sinergia y función:** Sin acceso demostrado con el inventario. Es una clasificación de juego; revisar la relación concreta en A06.
- **Papel como recurso, descarte o coste:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan….
- **Requisito específico:** Fusionar Gaia el Caballero Feroz y Maldición de Dragón; el turno que fue Invocado de Modo Especial, devolver al Deck un monstruo del Cementerio que no sea Caballero Mágico.
- **Efecto / resultado concreto:** Elegir entre atacar directamente este turno o destruir una Mágica/Trampa rival.
- **Ir primero, segundo y juego tardío:** Primero: preparar materiales y «Fusión» si es alcanzable; segundo: considerar el efecto de campo o daño que se produzca tras una Fusión legal; tardío: comprobar si quedan materiales nombrados en campo y Extra.
- **Relación con habilidad y otras piezas:** La Skill **ILLUSION OF EXECUTION** se aplica desde turno 2, una vez por duelo, después de comprobar sus restricciones de construcción.
- **Riesgos y dependencias:** pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Confianza:** **RESUMEN_FUNCIONAL_DE_GUIA_PREVIA_CON_FUENTE_KONAMI**; pendiente cotejo adicional de traducción/ventanas según la liga. Fuente Rush oficial: https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19323&ope=2
- **Contraste de fuente Rush:** CID 19323: fuente oficial Rush consultada en japonés; tipo Monstruo de Fusión; descripción funcional en español procede de la guía previa y sigue siendo interpretación editorial.
- **Aplicación concreta dentro de este deck (A06):** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Alcance de esta ficha:** interpretación táctica editorial. Los costes, objetivos, ventanas y límites exactos se deben cotejar con el texto oficial antes de considerarlos verificados en una secuencia A09.

**USO PRÁCTICO Y SINERGIA — Gaia, el Conquistador de Campeones**

- **Label funcional:** **SIN ACCESO CON EL MAIN ACTUAL**: faltan Gaia the Fierce Knight y Curse of Dragon; **probar quitar su única copia** si el dueño aprueba.
- **Qué hace:** Elegir entre atacar directamente este turno o destruir una Mágica/Trampa rival.
- **Cómo aprovecharla en este deck:** Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada.
- **Uso y consumo de recursos:** Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan….
- **Cuándo tener precaución:** pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival. las tres Fusiones Gaia del Extra mencionan materiales que no aparecen completos en el Main fotografiado; NO asumir Invocación ejecutable.
- **Alcance de la guía:** explicación de función y aplicación derivada de la ficha existente. No certifica una nueva secuencia de invocación o cadena.

**CÓMO LLEGAR DESDE TU DECK — SIN RUTA DEMOSTRADA**

- La biblioteca actual no contiene una ruta identificada para esta carta del Extra. No se debe exhibir una descripción genérica como sustituto de mano inicial, materiales y pasos. Para completarla, contrastar requisitos oficiales y recursos del Main; si no es alcanzable, explicar el impedimento exacto.

## SINERGIAS Y MOTORES
## RESUMEN FUNCIONAL DE SINERGIAS — 707

**Medición descriptiva de etiquetas existentes (NO certificación):** 17/20 identidades con etiqueta directa/indirecta (85.0 %). Main: 17/17 (100.0 %); Extra: 0/3 (0.0 %). Se cuenta una identidad una sola vez; una carta autónoma puede ser útil sin sinergia de motor. Estas cifras provienen de clasificaciones documentales A05/A06: **no son el porcentaje final de sinergias verificadas**, ni una tasa estadística de victoria. Para promoverlas a métricas verificadas, se deben comprobar los pares de cartas y su operación legal.



#### A06.0 — En 30 segundos: cómo cooperan realmente estas cartas


- **Dictamen de conjunto:** Mago Oscuro Rush y sus Mágicas nombradas cooperan; el Extra Gaia registrado es actualmente incompatible por ausencia de acceso demostrado.
- **Motor que mueve el deck:** Mago Oscuro, Piedra, Orden Secreta, Sabio y Skill crean disponibilidad real o nombre válido de Mago Oscuro para habilitar Mágicas específicas.
- **Puentes reales:** Mil Cuchillos y Ataque Mágico Oscuro ofrecen retiradas distintas cuando el nombre de Mago Oscuro realmente está activo; Chica Maga Oscura aporta presión dependiente del estado.
- **Sinergia indirecta:** una carta enviada al GY puede servir como objetivo de recuperación, pero su mera presencia no activa por sí sola los efectos que requieren ese nombre en campo.
- **Conflicto decisivo:** la Skill local opera desde turno 2 y bajo límite por duelo; el nombre temporal solo existe tras resolver su efecto. Gaia, Gaia Campeón Dragón y Gaia Conquistador no cuentan como destinos jugables sin materiales/procedimiento.
- **Decisión concreta:** aclarar si siete ranuras del Extra Gaia son históricas o se desea modificar la construcción; no borrar ni agregar cartas sin autorización.
- **Qué aprender después:** elegir Cuchillos si el objetivo es monstruo o Ataque Mágico Oscuro si son M/T, nunca atribuir ambos finales a una mano que posee solo uno.



#### Motor principal de acceso a Mago Oscuro

1. **Piezas de identidad.** **Mago Oscuro** (CID 15410) es Monstruo Normal LEGEND del Main; **Chica Maga Oscura** (16371) gana ATK por cada Mago Oscuro en cualquier Cementerio. **Hechicero Eliminador Oscuro** (19773), al cumplir su propio envío de carta superior del Deck, se trata como «Mago Oscuro» **solo ese turno** y puede ejercer retirada de monstruo con coste adicional de Mágicas en GY. No confundir identidad temporal con copia adicional de la carta LEGEND.
2. **Acceso desde mano y GY.** **Piedra de los Magos Oscuros** (19598) puede Invocar desde mano/GY hasta un Lanzador OSCURIDAD con **2500 ATK** y otro con **2000 ATK**, de modo que Mago Oscuro y Chica Maga Oscura son candidatos por sus estadísticas, si cumplen los límites de la carta. **Orden Secreta** (17212) revive/Invoca un **Normal Nivel 7** como Mago Oscuro. **Grito de Monstruo** (19329) envía monstruo de mano, roba y puede traer del GY monstruo **sin efecto** con ATK 2000 o DEF 2100; Mago Oscuro cumple el criterio por su DEF, pero se necesita tenerlo efectivamente en GY.
3. **Recuperación con Mago Oscuro Sabio.** **Mago Oscuro Sabio** (19597) manda Lanzador OSCURIDAD de mano al GY para robar y, si procede, Invocar **Mago Oscuro desde GY**. **Maga Legendaria** (18685) excava tres y puede recuperar un Normal LEGEND desde GY; si la carta elegida no existe allí, no se presume recuperar. **Lily Aniquiladora** (20305) puede contar por dos Sacrificios para Lanzador OSCURIDAD si su envío superior cumple la condición de Tipo.
4. **Remoción condicionada al nombre.** **Ataque Mágico Oscuro** (15451) destruye las M/T rivales y **Mil Cuchillos** (15450) destruye un monstruo rival **solo mientras se controla un «Mago Oscuro» boca arriba**. El nombre temporal de Hechicero Eliminador Oscuro puede satisfacer la condición si el efecto ya resolvió; no activar la Mágica antes de establecer el nombre. **Ráfaga de Resonancia Oscura** (17209) aumenta el ATK de Lanzador OSCURIDAD de Nivel 6+ y aumenta más si hay Mago Oscuro/Chica Maga Oscura según el texto.
5. **Relleno y Skill.** **ILLUSION OF EXECUTION (RD/SK01-002)** (registrada también como Illusion of Executor en el contexto de liga) desde turno 2 revela un monstruo Nivel 5+ y exige composición de Lanzadores con nombres altos restringidos; excava tres, puede añadir una Mágica y enviar las demás al GY, y luego puede enviar un Mago Oscuro desde Deck al GY. **Una vez por duelo** según texto local; no es carta robable ni se certifica su aplicación sin reglamento aprobado. **Distribuidor Maravilloso** (16772) y **Maldición de la Luz Ascendente** (21007) aportan intercambio/robo bajo sus costes y condiciones, no acceso incondicional a Mago Oscuro.
6. **Defensas.** **Brillo Sombrío** (20151) responde a Invocación rival cambiando monstruos de efecto a Defensa boca abajo tras enviar de mano; **¡Equitación Lindasesina!** (19341) puede recuperar del GY un monstruo adecuado ante Invocación rival y bajar ATK enemigo. Son Trampas con ventana real, no recursos disponibles instantáneamente desde el Deck.

#### Bloqueo crítico del Extra Deck actual

El Extra contiene **Gaia el Campeón Dragón Rápido** (CID 19995, 3x), **Gaia el Campeón Dragón** (18298, 3x) y **Gaia, el Conquistador de Campeones** (19323, 1x). Sus materiales nombrados involucran **Gaia el Caballero Feroz o un Guerrero con DEF 2100**, y **Maldición de Dragón**, y requieren un procedimiento de Fusión cuando corresponda. **No figura «Maldición de Dragón» ni una carta «Fusión» en las 30 cartas del Main cargado.** Por tanto, con el inventario actual **no hay ruta de Fusión demostrada para esos siete Extra**. La similitud «Mago Oscuro» ≠ «Gaia» no autoriza sustituir materiales. No se cambiará la lista sin confirmación de Miguel.

#### Mapa de relaciones para fotografía auténtica

| Relación por CID | Resultado | Requisito / límite | Visual |
|---|---|---|---|
| Skill ILLUSION OF EXECUTION → Mago Oscuro (15410) en GY | Preparar recuperación y buscar Mágica entre tres excavadas. | Desde turno 2, una vez por duelo, requisito de composición y revelado. | ![Skill ILLUSION OF EXECUTION](imagenes/skills/707_ILLUSION_OF_EXECUTION.jpeg) ![CID 15410](imagenes/rush/15410.png) |
| Piedra (19598) → Mago Oscuro (15410) + Chica Maga Oscura (16371) | Recuperar hasta dos cuerpos con ATK original indicado. | Objetivos realmente disponibles en mano/GY y efectos propios. | ![CID 19598](imagenes/rush/19598.png) ![CID 15410](imagenes/rush/15410.png) ![CID 16371](imagenes/rush/16371.png) |
| Mago Oscuro Sabio (19597) / Orden Secreta (17212) → Mago Oscuro | Reanimación por dos vías distintas. | Descarte Lanzador OSCURIDAD o Normal Nivel 7 disponible. | ![CID 19597](imagenes/rush/19597.png) ![CID 17212](imagenes/rush/17212.png) |
| Hechicero Eliminador (19773) → Ataque Mágico Oscuro (15451) / Mil Cuchillos (15450) | Habilitar Mágicas que exigen «Mago Oscuro» boca arriba. | Primero resolver el efecto de identidad temporal; duración solo ese turno. | ![CID 19773](imagenes/rush/19773.png) ![CID 15451](imagenes/rush/15451.png) ![CID 15450](imagenes/rush/15450.png) |
| Gaia Rápido (19995) / Gaia (18298) / Gaia Conquistador (19323) | **Sin relación operativa actualmente demostrada**. | Faltan material «Maldición de Dragón» y método «Fusión» registrado. | ![CID 19995](imagenes/rush/19995.png) ![CID 18298](imagenes/rush/18298.png) ![CID 19323](imagenes/rush/19323.png) |

#### Conflictos, redundancias y cierre editorial

- Las distintas vías de traer **Mago Oscuro** no crean copias nuevas ni garantizan que siga en GY; Piedra, Orden Secreta, Sabio y Grito compiten por ese recurso. Chica Maga Oscura necesita a Mago Oscuro **en GY** para su aumento; sacar esa misma carta del GY puede cambiar el ATK.
- El motor de remoción **Ataque Mágico Oscuro / Mil Cuchillos** exige nombre y Campo, mientras que **Ráfaga** exige Tipo/Atributo/Nivel; no funcionan automáticamente con cualquier Lanzador.
- Las siete cartas Gaia del Extra se mantienen catalogadas pero **bloqueadas** con la lista recibida: ninguna guía debe inventar Maldición de Dragón, Fusión o materiales de otro deck.




#### Skill personalizada y motor — ILLUSION OF EXECUTION

![Skill ILLUSION OF EXECUTION](imagenes/skills/707_ILLUSION_OF_EXECUTION.jpeg)

- **Identidad y zona:** RD/SK01-002; habilidad separada de Main/Extra/Side/Reserva, no robable.
- **Requisito de la imagen:** Desde turno 2 revela un monstruo Nivel 5+ en mano; todos los monstruos del Deck son Lanzadores de Conjuros y los Nivel 5+ son Dark Magician, Dark Magician Girl o Dark Eradicator Sorcerer.
- **Efecto de la imagen:** Excava 3 cartas; puede añadir 1 Mágica excavada y manda las demás al GY; después puede enviar 1 Dark Magician del Deck al GY. Una vez por Duelo.
- **Sinergia:** Acceso condicional a Mágicas y preparación del GY para recuperación de Dark Magician.
- **Dependencias/riesgo:** No garantiza excavar una Mágica y no resuelve la ausencia de materiales Gaia del Extra.
- **Clasificación:** habilitador o extensión, no combo completo. Texto e imagen aportados por Miguel; no inferir límites por turno no escritos.





#### A06.1 — Arquitectura operativa de los motores (síntesis no redundante)

Las siguientes filas son **relaciones funcionales**, no secuencias certificadas ni garantía de mano inicial. La lista real y los límites están en A04/A05/A07.

| Tipo / motor | Starter o vía de acceso real | Recurso y destino | Cuello de botella |
|---|---|---|---|
| **Principal: Dark Magician Rush** | Mago Oscuro, Piedra, Orden Secreta, Sabio y Skill | Depositar/recuperar Mago Oscuro y habilitar magias nombradas | Skill desde turno 2 y una vez por duelo; presencia real de objetivo en GY |
| **Apoyo: presión y defensa** | Ataque Mágico Oscuro, Mil Cuchillos, Chica Maga Oscura, Trampas | Retirada/ataques solo con nombre y estado válidos | Un nombre temporal solo sirve tras resolver su efecto |
| **Extra registrado sin acceso** | Gaia Rápido, Gaia Campeón Dragón y Gaia Conquistador | No hay salida demostrable del Extra actual | Faltan Fusión y Maldición de Dragón: incompatibilidad operativa, no motor |

#### A06.2 — Estado funcional y justificación de TODAS las cartas

**Cómo leerlo:** un estado de sinergia describe el papel **de juego**, no el avance de una auditoría. No hay obligación de que cada carta tenga un enlace con otra: una defensa autónoma, una herramienta de Side o un recurso de descarte justificado también tiene propósito. Las relaciones directas descritas aquí se deben contrastar con los textos oficiales antes de representarlas como una ruta legal A09.

| Carta / CID y zona | Estado funcional de sinergia | Motivo de inclusión | Relación y condición concreta | Papel como coste, descarte o material | Límite o riesgo | Decisión táctica |
|---|---|---|---|---|---|---|
| **Ataque Mágico Oscuro** (CID 15451) — Main 2x | **Sinergia indirecta (soporte o recursos)** | Carta Mágica Normal — removal / apertura de campo | Destruye todas las cartas Mágicas y Trampas del campo rival | Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival | Controlar un Mago Oscuro boca arriba | Conservar; verificar coste y orden |
| **Distribuidor Maravilloso** (CID 16772) — Main 1x | **Sinergia directa descrita** | Monstruo de Efecto — consistencia / reciclaje | Enviar tres cartas de la mano al Cementerio y robar tres cartas | Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano | Tener hasta tres monstruos en el Cementerio y pagar 300 LP | Conservar; verificar coste y orden |
| **Maga Legendaria** (CID 18685) — Main 2x | **Sinergia directa descrita** | Monstruo de Efecto — monstruo de apoyo/material o recurso de Sacrificio | Revelar las tres cartas superiores; puede enviar un monstruo revelado al Cementerio y recuperar un monstruo Normal LEGEND del Cementerio | Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano | No tiene requisito de activación | Conservar; verificar coste y orden |
| **Mago Oscuro Sabio** (CID 19597) — Main 1x | **Sinergia directa descrita** | Monstruo de Efecto — extensión de campo y recuperación de recursos | Roba una carta; después puede Invocar de Modo Especial un Mago Oscuro del Cementerio | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo… | Enviar desde la mano al Cementerio un Lanzador de Conjuros/OSCURIDAD | Conservar; verificar coste y orden |
| **Grito de Monstruo** (CID 19329) — Main 2x | **Sinergia directa descrita** | Carta Mágica Normal — extensión de campo y recuperación de recursos | Roba una carta; después puede Invocar del Cementerio un monstruo sin efecto que tenga ATK 2000 o DEF 2100 | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo… | Enviar de la mano un monstruo al Cementerio | Conservar; verificar coste y orden |
| **Hechicero Eliminador Oscuro** (CID 19773) — Main 3x | **Sinergia indirecta (soporte o recursos)** | Monstruo de Efecto — apoyo situacional sujeto a condición escrita | Se llama Mago Oscuro ese turno; puede devolver diez Mágicas del Cementerio al Deck para destruir un monstruo rival boca arriba de Nivel 8 o inferior | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan… | Enviar la primera carta de tu Deck al Cementerio | Conservar; verificar coste y orden |
| **Ráfaga de Resonancia Oscura** (CID 17209) — Main 3x | **Sinergia indirecta (soporte o recursos)** | Carta Mágica Normal — presión de combate / modificación de estadísticas | Otorga 1000 ATK por el turno a un Lanzador de Conjuros OSCURIDAD propio de Nivel 6+; otorga otros 1000 si controlas Mago Oscuro o Chica Maga Oscura | Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto | Sin requisito de activación | Conservar; verificar coste y orden |
| **Brillo Sombrío** (CID 20151) — Main 2x | **Sinergia directa descrita** | Carta de Trampa Normal — consistencia / reciclaje | Pone hasta dos monstruos de Efecto boca arriba de cualquier Campo boca abajo en Defensa; si incluyó un monstruo rival con ATK original de al menos 2600, recupera 1500 LP | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución | Cuando el rival Invoca un monstruo en su turno; enviar una carta de la mano al Cementerio | Conservar; verificar coste y orden |
| **Piedra de los Magos Oscuros** (CID 19598) — Main 3x | **Sinergia directa descrita** | Carta Mágica Normal — extensor / habilitador de material | Invoca desde la mano y/o Cementerio hasta un Lanzador de Conjuros OSCURIDAD con 2500 ATK y hasta otro con 2000 ATK, boca arriba | Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto | Sin requisito de activación | Conservar; verificar coste y orden |
| **Mago Oscuro** (CID 15410) — Main 1x | **Sinergia indirecta (soporte o recursos)** | Monstruo Normal — material de Fusión/Sacrificio o presencia de combate; sin efecto activado | Monstruo Normal LEGEND | Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte | No tiene efecto | Conservar; verificar coste y orden |
| **Lily Aniquiladora** (CID 20305) — Main 1x | **Sinergia directa descrita** | Monstruo de Efecto — apoyo situacional sujeto a condición escrita | Envía la primera carta del Deck al Cementerio; si era Lanzador de Conjuros, esta carta cuenta por dos Sacrificios para un Lanzador de Conjuros/OSCURIDAD en Ataque este turno | Envío mencionado en la interacción; no equivale por sí mismo a descarte desde la mano | Haber sido Invocada de Modo Normal este turno | Conservar; verificar coste y orden |
| **Chica Maga Oscura** (CID 16371) — Main 3x | **Sinergia indirecta (soporte o recursos)** | Monstruo de Efecto — presión de combate / modificación de estadísticas | Gana 500 ATK por cada Mago Oscuro en ambos Cementerios | Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto | No necesita activación | Conservar; verificar coste y orden |
| **Mil Cuchillos** (CID 15450) — Main 2x | **Sinergia indirecta (soporte o recursos)** | Carta Mágica Normal — removal / apertura de campo | Destruye un monstruo del Campo rival | Coste o consumo descrito en A05: el resultado está sujeto a monstruos/cartas que puedan ser afectados y a respuestas del rival | Controlar un Mago Oscuro boca arriba | Conservar; verificar coste y orden |
| **¡Equitación Lindasesina!** (CID 19341) — Main 1x | **Sinergia directa descrita** | Carta de Trampa Normal — extensor / habilitador de material | Invoca del Cementerio en Ataque propio un monstruo cuyo ATK no supere el del recién invocado; después puede reducir en 1800 ATK hasta dos monstruos rivales boca arriba ese turno | Coste o consumo descrito en A05: comprobar zona, objetivos y ventana; el nombre de la carta no reemplaza su texto | Cuando el rival Invoca boca arriba un monstruo de Efecto | Conservar; verificar coste y orden |
| **Orden Secreta** (CID 17212) — Main 1x | **Sinergia directa descrita** | Carta Mágica Normal — recurso táctico cuya condición y resultado están descritos en su ficha | Invoca un monstruo Normal de Nivel 7 desde mano o Cementerio; le da 700 ATK ese turno y lo protege frente a destrucción por Trampas rivales | Coste o consumo descrito en A05: la condición de una Mágica/Trampa y sus blancos deben cumplirse antes de resolver. No confundir esta carta con un monstruo… | Sin requisito de activación | Conservar; verificar coste y orden |
| **Olla de la Codicia** (CID 16372) — Main 1x | **Sinergia indirecta de recursos** | Carta Mágica Normal — consistencia / reciclaje | Roba dos cartas. Aportación posible como material, coste o objetivo; verificar consumidor | Material o destino del Extra condicionado a los requisitos de invocación | Sin requisito de activación | Conservar si existe consumidor legal |
| **Maldición de la Luz Ascendente** (CID 21007) — Main 1x | **Sinergia indirecta (soporte o recursos)** | Carta Mágica Normal — consistencia / reciclaje | Cambia un monstruo rival a Ataque boca arriba o Defensa boca abajo | Coste o consumo descrito en A05: disponer de cartas suficientes en Deck y distinguir robo de búsqueda | El rival debe tener una o ninguna carta en mano | Conservar; verificar coste y orden |
| **Gaia el Campeón Dragón Rápido** (CID 19995) — Extra 3x | **Sin acceso demostrado con el inventario** | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre | Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. disponer de cartas suficientes en Deck y distinguir robo… | Fusionar un Guerrero con DEF 2100 y Maldición de Dragón; para el efecto, enviar la carta superior del Deck al Cementerio | Revisar zona/acceso; sustitución por validar |
| **Gaia el Campeón Dragón** (CID 18298) — Extra 3x | **Sin acceso demostrado con el inventario** | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre | Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada | Coste o consumo descrito en A05: no atribuirle un efecto activado inexistente; comprobar su función como material y las cartas de soporte. verificar en campo… | Materiales nombrados: Gaia el Caballero Feroz y Maldición de Dragón | Revisar zona/acceso; sustitución por validar |
| **Gaia, el Conquistador de Campeones** (CID 19323) — Extra 1x | **Sin acceso demostrado con el inventario** | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre | Extra Gaia sin Maldición de Dragón ni Fusión en Main: no hay ruta de acceso demostrada | Coste o consumo descrito en A05: pagar/cumplir el requisito escrito antes de prometer la resolución. el resultado está sujeto a monstruos/cartas que puedan… | Fusionar Gaia el Caballero Feroz y Maldición de Dragón; el turno que fue Invocado de Modo Especial, devolver al Deck un monstruo del Cementerio… | Revisar zona/acceso; sustitución por validar |

## INTERACCIONES Y CLASIFICACIÓN

| ID documental | Categoría provisional | Piezas | Resultado | Requisitos | Check |
|---|---|---|---|---|---|
| 707:A08:01 | INTERACCION | Skill ILLUSION OF EXECUTION → Mago Oscuro (15410) en GY | Preparar recuperación y buscar Mágica entre tres excavadas. | Desde turno 2, una vez por duelo, requisito de composición y revelado. | |
| 707:A08:02 | EXTENSION | Piedra (19598) → Mago Oscuro (15410) + Chica Maga Oscura (16371) | Recuperar hasta dos cuerpos con ATK original indicado. | Objetivos realmente disponibles en mano/GY y efectos propios. | |
| 707:A08:03 | EXTENSION | Mago Oscuro Sabio (19597) / Orden Secreta (17212) → Mago Oscuro | Reanimación por dos vías distintas. | Descarte Lanzador OSCURIDAD o Normal Nivel 7 disponible. | |
| 707:A08:04 | PLAN | Hechicero Eliminador (19773) → Ataque Mágico Oscuro (15451) / Mil Cuchillos (15450) | Habilitar Mágicas que exigen «Mago Oscuro» boca arriba. | Primero resolver el efecto de identidad temporal; duración solo ese turno. | |
| 707:A08:05 | NO_EJECUTABLE | Gaia Rápido (19995) / Gaia (18298) / Gaia Conquistador (19323) | **Sin relación operativa actualmente demostrada**. | Faltan material «Maldición de Dragón» y método «Fusión» registrado. | (no importable como jugada) |

#### Rol registrado por cada carta

| ID A08 | Carta registrada | Zona | Clasificación funcional | Rol documentado en A05 | Check de clasificación |
|---|---|---|---|---|---|
| 707:A08:C001 | Ataque Mágico Oscuro | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — removal / apertura de campo. | |
| 707:A08:C002 | Distribuidor Maravilloso | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Monstruo de Efecto — consistencia / reciclaje. | |
| 707:A08:C003 | Maga Legendaria | Main | RECURSO_MATERIAL | Monstruo de Efecto — monstruo de apoyo/material o recurso de Sacrificio. | |
| 707:A08:C004 | Mago Oscuro Sabio | Main | EXTENSOR_POTENCIAL | Monstruo de Efecto — extensión de campo y recuperación de recursos. | |
| 707:A08:C005 | Grito de Monstruo | Main | EXTENSOR_POTENCIAL | Carta Mágica Normal — extensión de campo y recuperación de recursos. | |
| 707:A08:C006 | Hechicero Eliminador Oscuro | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Monstruo de Efecto — apoyo situacional sujeto a condición escrita. | |
| 707:A08:C007 | Ráfaga de Resonancia Oscura | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — presión de combate / modificación de estadísticas. | |
| 707:A08:C008 | Brillo Sombrío | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta de Trampa Normal — consistencia / reciclaje. | |
| 707:A08:C009 | Piedra de los Magos Oscuros | Main | EXTENSOR_POTENCIAL | Carta Mágica Normal — extensor / habilitador de material. | |
| 707:A08:C010 | Mago Oscuro | Main | RECURSO_MATERIAL | Monstruo Normal — material de Fusión/Sacrificio o presencia de combate; sin efecto activado. | |
| 707:A08:C011 | Lily Aniquiladora | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Monstruo de Efecto — apoyo situacional sujeto a condición escrita. | |
| 707:A08:C012 | Chica Maga Oscura | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Monstruo de Efecto — presión de combate / modificación de estadísticas. | |
| 707:A08:C013 | Mil Cuchillos | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — removal / apertura de campo. | |
| 707:A08:C014 | ¡Equitación Lindasesina! | Main | EXTENSOR_POTENCIAL | Carta de Trampa Normal — extensor / habilitador de material. | |
| 707:A08:C015 | Orden Secreta | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — recurso táctico cuya condición y resultado están descritos en su ficha. | |
| 707:A08:C016 | Olla de la Codicia | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — consistencia / reciclaje. | |
| 707:A08:C017 | Maldición de la Luz Ascendente | Main | FUNCION_A05 (recurso jugable sujeto a condición) | Carta Mágica Normal — consistencia / reciclaje. | |
| 707:A08:C018 | Gaia el Campeón Dragón Rápido | Extra | DESTINO_EXTRA (materiales/procedimiento por comprobar) | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre. | |
| 707:A08:C019 | Gaia el Campeón Dragón | Extra | DESTINO_EXTRA (materiales/procedimiento por comprobar) | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre. | |
| 707:A08:C020 | Gaia, el Conquistador de Campeones | Extra | DESTINO_EXTRA (materiales/procedimiento por comprobar) | Monstruo de Fusión — objetivo de Fusión con materiales expresos y efecto de cierre. | |

## JUGADAS DOCUMENTADAS

> Requieren comprobación A11–A13 y validación de estado final. No publicar las rutas como combos certificados por tener fotografías.

#### A09 — Ruta contrastada `707:A09:ILLUSION:SAGE01` (Skill + recuperación + barrido M/T)

- **Objetivo verificable:** dejar **Mago Oscuro** (2500 ATK) y **Mago Oscuro Sabio** (900 ATK) boca arriba y destruir las Mágicas/Trampas del adversario mediante **Ataque Mágico Oscuro**. No prometer victoria, daño ni cartas excavadas concretas.
- **Mano inicial de este caso:** 1× **Chica Maga Oscura** (CID 16371), 1× **Mago Oscuro Sabio** (CID 19597), 1× **Ataque Mágico Oscuro** (CID 15451). **Mago Oscuro** (CID 15410, 1 copia LEGEND) está inicialmente **en el Deck**, no en mano ni GY; la Skill es externa a la mano. Campo propio vacío; rival con al menos una M/T; Deck con 3 o más cartas por excavar; turno **2 o posterior**. Skill no usada previamente. Sin interferencia del rival en la ruta base.
- **Compatibilidad de construcción:** los monstruos Main registrados son Lanzadores de Conjuros y sus Nivel 5+ son Mago Oscuro, Chica Maga Oscura o **Dark Eradicator Sorcerer (CID 19773, «Hechicero Eliminador Oscuro»)**. El CID 19773 figura en la base oficial japonesa bajo *Black Executor / 黒魔導の遂行者*, y *Dark Eradicator Sorcerer* es la localización inglesa de ese mismo CID; **no** son dos monstruos diferentes. El texto de la Skill personalizada es el de la foto aportada; su adopción sigue supeditada al reglamento local.

1. **Revelar Chica Maga Oscura de la mano** para cumplir el requisito de **ILLUSION OF EXECUTION**, a partir del turno 2.
2. **Excavar exactamente 3 cartas del Deck**. Si hay una Mágica entre ellas, se puede añadir **una** a la mano; las otras excavadas van al GY. Si no aparece Mágica, las tres van al GY. **No elegir ni inventar sus identidades.**
3. **Preparar Mago Oscuro en el Cementerio:** si fue una de las tres excavadas, se envía al GY en el paso anterior (es Monstruo Normal y no puede ser la Mágica añadida). Si no estaba en esas tres, sigue en el Deck y la Skill puede enviar esa **única copia** al GY. Ambas ramas concluyen con **Mago Oscuro en GY**. Skill consumida una vez por duelo.
4. **Invocar Normalmente Mago Oscuro Sabio** (Nivel 3, 900 ATK). Se conserva Chica Maga Oscura en mano hasta el coste del siguiente paso.
5. Activar el efecto de **Mago Oscuro Sabio**: **enviar Chica Maga Oscura** (Lanzador de Conjuros/OSCURIDAD) desde la mano al GY como requisito; **robar 1 carta** y después **Invocar Especialmente Mago Oscuro** desde el GY boca arriba. El robo no necesita revelar una carta específica para que la recuperación sea legal.
6. Ya con **Mago Oscuro boca arriba** en tu campo, activar **Ataque Mágico Oscuro** desde la mano y **destruir todas las M/T del rival**. La carta Mágica usada va al GY tras resolver.

**Traza A09 de zonas al terminar cada paso (Skill local con excavación aleatoria):** ninguna carta excavada o robada recibe un nombre inventado. El número de Mágicas añadidas por la excavación es 0 o 1 según contenido real; el único Mago Oscuro LEGEND acaba en GY al completar P3.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Chica Maga Oscura #16371 (revelada), Mago Oscuro Sabio #19597 y Ataque Mágico Oscuro #15451 | — | — | — | — | Rival conserva al menos una M/T de identidad desconocida | — | Skill ILLUSION OF EXECUTION activada, todavía procesando; Rush permite Normales posteriores; Extra sin uso |
| P2 | Chica Maga Oscura #16371, Mago Oscuro Sabio #19597, Ataque Mágico Oscuro #15451 y 0 o 1 Mágica excavada de identidad desconocida | — | — | Entre 2 y 3 cartas excavadas de identidad variable; Mago Oscuro podría estar entre ellas | — | Sin cambios rivales demostrados | — | Skill local en resolución, no se repite; Normal todavía libre |
| P3 | Chica Maga Oscura #16371, Mago Oscuro Sabio #19597, Ataque Mágico Oscuro #15451 y posible Mágica excavada desconocida | — | — | Mago Oscuro LEGEND #15410 en GY, más restantes de excavación de identidad variable | — | Rival mantiene al menos una M/T; ninguna destruida | — | Skill local usada una vez; Mago Oscuro llegó a GY por excavación o envío permitido; Normal posible |
| P4 | Chica Maga Oscura #16371, Ataque Mágico Oscuro #15451 y posible Mágica excavada desconocida | Mago Oscuro Sabio #19597 (Ataque, 900 ATK) | — | Mago Oscuro #15410 y otras excavadas en GY | — | Rival conserva M/T | — | Rush: Normal de Sabio realizada; Skill gastada; Extra sin usar |
| P5 | Ataque Mágico Oscuro #15451, 1 carta robada de identidad desconocida y 0 o 1 Mágica excavada desconocida | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Mago Oscuro #15410 (Ataque, 2500 ATK) | — | Chica Maga Oscura #16371 y cartas excavadas restantes de identidad variable en GY | — | M/T rival todavía presente; no se destruye en P5 | — | Rush: recuperación de Mago Oscuro desde GY por Sabio; Skill usada; Extra sin usar |
| P6 | 1 carta robada desconocida y 0 o 1 Mágica excavada desconocida | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Mago Oscuro #15410 (Ataque, 2500 ATK) | — | Chica Maga Oscura #16371, Ataque Mágico Oscuro #15451 y otras excavadas desconocidas en GY | — | Todas las M/T rivales presentes al resolver fueron destruidas; monstruos rivales no definidos | — | Rush: Skill usada; no se gastó Extra ni se aseguró ningún ataque |

**Estado final exacto de la rama base:** campo propio = Mago Oscuro (ATK 2500) + Mago Oscuro Sabio (ATK 900), ambos boca arriba; campo M/T del oponente = vacío tras la destrucción (si no hubo respuesta); **Chica Maga Oscura en GY**, **Ataque Mágico Oscuro en GY**, Skill ya utilizada. Mano propia = **1 carta robada** en paso 5 + **0 o 1 Mágica** seleccionada en paso 2, de identidad no determinada. El contenido de las otras cartas excavadas en GY es variable; no asignar probabilidades ni suponer que se excavó una carta útil. **Clasificación:**, publicación A09/A10 todavía no certificada.

**Fuentes primarias:** [Skill personalizada fotografiada](imagenes/skills/707_ILLUSION_OF_EXECUTION.jpeg), [Mago Oscuro](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15410&ope=2), [Chica Maga Oscura](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=16371&ope=2), [Mago Oscuro Sabio](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19597&ope=2), [Ataque Mágico Oscuro](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15451&ope=2), [CID 19773](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19773&ope=2).

#### A09 — Ruta contrastada `707:A09:SECRETORDER:DM01` (Invocación inmediata de Mago Oscuro)

- **Objetivo:** Invocar Mago Oscuro **sin Sacrificios** desde la mano y despejar las M/T rivales en el mismo turno. Es **una ruta independiente** de `ILLUSION:SAGE01`; no se suman dos habilidades ni se duplica la copia LEGEND.
- **Mano inicial:** 1× **Mago Oscuro** (CID 15410, Nivel 7 Normal), 1× **Orden Secreta** (CID 17212), 1× **Ataque Mágico Oscuro** (CID 15451). Campo propio vacío; rival con una o más M/T. Turno propio cualquiera; sin Skill ni efectos previos. No hay restricción de estar en turno 2 para esta ruta.

1. Activar **Orden Secreta** desde la mano, eligiendo **Mago Oscuro** (Monstruo Normal Nivel 7) en la mano. Invocarlo **Especialmente boca arriba** en el Campo. No realizar una Invocación por Sacrificio.
2. **Mago Oscuro gana 700 ATK temporalmente**: 2500 + 700 = **3200 ATK** hasta el final del turno; tampoco puede ser destruido por efectos de Trampa del oponente **este turno**. No prolongar ese bono/protección al turno siguiente.
3. Con **Mago Oscuro boca arriba**, activar **Ataque Mágico Oscuro** y destruir **todas** las cartas Mágicas/Trampa del rival. Ambas Mágicas utilizadas quedan en GY al terminar sus resoluciones.

**Traza A09 de zonas al terminar cada paso (sin Skill):** la bonificación de Orden Secreta comienza con la Invocación; P2 hace explícito el valor, no representa una segunda activación.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Ataque Mágico Oscuro #15451 | Mago Oscuro #15410 (Ataque, 3200 ATK temporal tras Orden Secreta) | — | Orden Secreta #17212 en GY | — | Rival conserva una o más M/T de identidad desconocida | — | Rush: Normal no usada; Skill intacta; Extra sin uso |
| P2 | Ataque Mágico Oscuro #15451 | Mago Oscuro #15410 (Ataque, 3200 ATK temporal; protección frente a destrucción por Trampas rivales este turno) | — | Orden Secreta en GY | — | M/T rivales sin cambios | — | No es una nueva Invocación ni coste adicional; Normal libre; Skill intacta |
| P3 | — | Mago Oscuro #15410 (Ataque, 3200 ATK este turno) | — | Orden Secreta #17212 y Ataque Mágico Oscuro #15451 en GY | — | Todas las M/T rivales destruidas al resolver; monstruos rivales no definidos | — | Normal libre; Skill intacta; bonus de Orden Secreta termina al cerrar el turno |

**Estado final sin interrupciones:** Mago Oscuro boca arriba en Campo con **3200 ATK este turno**; rival sin M/T; Orden Secreta y Ataque Mágico Oscuro en GY; Skill intacta, Invocación Normal del turno **no gastada**. Fuera del turno de Invocación, el ATK vuelve a **2500** y termina la protección específica de Orden Secreta. No inferir daño de batalla ni OTK., faltan tableros gráficos A10 y cobertura de adversario A12.

**Fuentes:** [Orden Secreta](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=17212&ope=2), [Mago Oscuro](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15410&ope=2), [Ataque Mágico Oscuro](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15451&ope=2).

#### A09 — `707:A09:JEWEL:PAIR01` (Piedra: dos Invocaciones Especiales sin Sacrificios)

- **Mano inicial y objetivo:** **Piedra de los Magos Oscuros** (CID 19598), **Mago Oscuro** (15410, OSCURIDAD/Lanzador ATK 2500) y **Chica Maga Oscura** (16371, OSCURIDAD/Lanzador ATK 2000), cada uno registrado en el Main. Mano = esas tres cartas; campo/GY propios vacíos; dos zonas de monstruo libres; turno propio Main Phase. Sin Skill ni cartas adversarias relevantes para la ruta base.

1. Activar **Piedra de los Magos Oscuros**, Mágica Normal sin requisito de activación y que se resuelve desde la mano. Elegir desde la **mano** a Mago Oscuro (2500 ATK original) y Chica Maga Oscura (2000 ATK original), **hasta una copia de cada categoría**.
2. **Invocar Especialmente ambos monstruos en Ataque boca arriba** en zonas disponibles. La Mágica termina en el GY tras resolver. No gastar Invocación Normal ni ofrecer Sacrificios.
3. **Estado final:** campo propio = Mago Oscuro boca arriba 2500 ATK + Chica Maga Oscura boca arriba 2000 ATK; mano de la apertura vacía; Piedra en GY; Skill intacta. No afirmar que Chica Maga gana ATK por estar Mago Oscuro **en campo**, porque su bonificación habitual exige verificar el estado del GY; tampoco presumir daño de batalla.

- **Variantes textuales, no secuencias adicionales contadas:** Piedra también permite elegir **hasta una** de esas categorías desde mano **o** Cementerio; puede traer solo una si solo una existe o si no hay segunda zona. Esa rama necesitará documentar los estados de GY y las zonas antes de declararse otra apertura. **Fuente:** [Piedra, CID 19598](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19598&ope=2).;.

#### A09 — `707:A09:EXECUTOR:KNIVES01` / `707:A09:EXECUTOR:DARKMAGIC01` (nombre temporal)

- **Manos alternativas de cuatro cartas:** (1) **Mago Oscuro Sabio** (CID 19597, Nivel 3 ATK 900), (2) **Lily Aniquiladora** (CID 20305, Nivel 4 ATK 1300), (3) **Hechicero Eliminador Oscuro / Black Executor** (CID 19773, Nivel 7 ATK 2500), (4) **Mil Cuchillos** (15450) *o* **Ataque Mágico Oscuro** (15451). Todos están en Main; **Mago Oscuro LEGEND no es requisito**. Campo y GY propios vacíos, al menos una carta en el Deck para el coste del Hechicero; oponente con 1 monstruo objetivo (versión Mil Cuchillos) o una M/T (versión Ataque Mágico). Turno propio Main Phase, sin respuestas en la ruta base.

1. **Invocar Normalmente Mago Oscuro Sabio y Lily Aniquiladora** en Ataque usando las reglas de Invocaciones Normales de Rush Duel. **No activar** sus efectos opcionales; por tanto, no enviar cartas adicionales ni robar por hipótesis.
2. **Sacrificar los dos Nivel 3/4** para Invocar Normalmente por Sacrificio a **Hechicero Eliminador Oscuro** (Nivel 7) en Ataque, 2500 ATK. Ambos materiales quedan en GY.
3. Activar el efecto del Hechicero **en esa Main Phase**, enviando la carta superior del Deck al GY como requisito. Su **nombre pasa a ser «Mago Oscuro» únicamente hasta el final del turno**. No aplicar el efecto adicional de devolver **10 Mágicas** del GY, porque esa condición no está demostrada en esta apertura.
4. **Salida `KNIVES01`:** activar **Mil Cuchillos**, ahora que se controla un «Mago Oscuro» boca arriba, y destruir **un monstruo rival elegido** (incluso boca abajo, si no existe otra prohibición aplicable). **Salida `DARKMAGIC01`:** activar **Ataque Mágico Oscuro** en la misma condición y destruir **todas las M/T rivales**. **Son versiones excluyentes**, no asumir que la mano contiene ambas Mágicas.
5. **Estado final de cualquiera de las dos:** propio = Hechicero Eliminador en Ataque **2500 ATK, con nombre temporal «Mago Oscuro» este turno**; GY = Mago Oscuro Sabio + Lily + Mágica usada + carta superior enviada de identidad desconocida; mano inicial vacía. El oponente pierde los blancos definidos de cada versión; **en el siguiente turno** el Hechicero recupera su **nombre impreso** y no habilita automáticamente estas Mágicas.

**Traza A09 de zonas al terminar cada paso de `707:A09:EXECUTOR:KNIVES01` (monstruo rival como objetivo):** la identificación temporal como Mago Oscuro solo dura el turno; ninguna M/T rival se destruye por esta salida.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Hechicero Eliminador Oscuro #19773 y Mil Cuchillos #15450 | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Lily Aniquiladora #20305 (Ataque, 1300 ATK) | — | — | — | Un monstruo rival elegible de identidad desconocida sigue en Campo | Dos cuerpos propios independientes | Rush: dos Normales realizadas; Skill no usada; Extra sin uso |
| P2 | Mil Cuchillos #15450 | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK) | — | Mago Oscuro Sabio #19597 y Lily #20305 en GY (Sacrificios) | — | Monstruo rival todavía presente | Dos monstruos propios tributados; no materiales Xyz | Rush: jefe Invocado por Sacrificio; Skill intacta; Extra sin uso |
| P3 | Mil Cuchillos #15450 | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre temporal Mago Oscuro) | — | Sabio, Lily y 1 carta superior del Deck de identidad desconocida en GY | — | Monstruo rival seleccionable sin cambios | No hay materiales Xyz; cambio de nombre por efecto temporal | Skill no usada; Extra sin uso; nombre cambia al terminar el turno |
| P4 | — | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre Mago Oscuro este turno) | — | Sabio, Lily, carta superior desconocida y Mil Cuchillos #15450 en GY | — | Un monstruo rival elegible destruido por Mil Cuchillos; M/T rivales no afectadas por esta línea | — | Skill intacta; Extra sin uso; requisito de nombre satisfecho solo este turno |
| P5 | — | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre Mago Oscuro solo este turno) | — | Sabio #19597, Lily #20305, Mil Cuchillos #15450 y carta superior desconocida en GY | — | El objetivo monstruo rival se perdió; sin barrido de M/T atribuido | Sin materiales acoplados | Rush: Skill intacta; Extra sin uso; se recupera nombre impreso al concluir turno |

**Traza A09 de zonas al terminar cada paso de `707:A09:EXECUTOR:DARKMAGIC01` (M/T rivales como objetivo):** se usa Ataque Mágico Oscuro en lugar de Mil Cuchillos; la salida no retira monstruos por efecto.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Hechicero Eliminador Oscuro #19773 y Ataque Mágico Oscuro #15451 | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Lily Aniquiladora #20305 (Ataque, 1300 ATK) | — | — | — | Una o más M/T rivales de identidad no especificada siguen presentes | Dos cuerpos independientes | Rush: dos Normales; Skill no usada; Extra sin uso |
| P2 | Ataque Mágico Oscuro #15451 | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK) | — | Sabio #19597 y Lily #20305 en GY (Sacrificios) | — | M/T rivales aún presentes | Dos monstruos tributados; no Xyz | Rush: jefe Invocado por Sacrificio; Skill intacta |
| P3 | Ataque Mágico Oscuro #15451 | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre temporal Mago Oscuro) | — | Sabio, Lily y carta superior desconocida del Deck en GY | — | M/T rivales aún presentes y sin destruir | Sin materiales Xyz | Skill intacta; Extra sin uso; nombre temporal válido este turno |
| P4 | — | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre Mago Oscuro este turno) | — | Sabio, Lily, carta superior desconocida y Ataque Mágico Oscuro #15451 en GY | — | Todas las M/T rivales destruidas por la Mágica; ningún monstruo rival destruido por esta línea | — | Skill intacta; Extra sin uso; nombre temporal vigente |
| P5 | — | Hechicero Eliminador Oscuro #19773 (Ataque, 2500 ATK; nombre Mago Oscuro este turno) | — | Sabio #19597, Lily #20305, Ataque Mágico Oscuro #15451 y carta superior desconocida en GY | — | M/T rivales destruidas; monstruos rivales no afectados por esta salida | Sin materiales Xyz | Rush: Skill intacta; Extra sin uso; nombre vuelve al impreso al terminar turno |

- **Fuentes oficiales:** [Hechicero CID 19773](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19773&ope=2), [Mago Sabio CID 19597](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=19597&ope=2), [Lily CID 20305](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=20305&ope=2), [Mil Cuchillos](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15450&ope=2), [Ataque Mágico](https://www.db.yugioh-card.com/rushdb/card_search.action?cid=15451&ope=2).;.

#### A09 — Tres alternativas completas para retirar monstruos o conservar dos cuerpos

**`707:A09:ILLUSION:SAGE:KNIVES02` — turno 2+, Skill + Mago Sabio + eliminar monstruo**

- **Apertura:** exactamente **Chica Maga Oscura + Mago Oscuro Sabio + Mil Cuchillos** en mano; Mago Oscuro LEGEND en Deck, Skill `ILLUSION OF EXECUTION` sin usar, Main Phase del **turno 2 o posterior**, Deck al menos 3 cartas, rival con **monstruo seleccionable**; Campo/GY propios vacíos. Sin respuestas. Es un destino diferente de `ILLUSION:SAGE01` que rompe M/T.
1. Activar la Skill, **revelar Chica Maga Oscura**, excavar tres cartas; añadir una Mágica excavada solo si existe y elegir hacerlo. Poner las otras en GY sin inventar identidad; si Mago Oscuro no fue excavado, enviarlo del Deck al GY como permite la Skill. Resultado necesario: **Mago Oscuro en GY**, Skill gastada.
2. Normal **Mago Oscuro Sabio**; enviar **Chica Maga Oscura desde la mano al GY** para su efecto, **robar 1** carta de identidad desconocida e **Invocar Especialmente Mago Oscuro desde GY**.
3. Activar **Mil Cuchillos** desde la mano, ahora que se controla Mago Oscuro; elegir un monstruo rival legal, **destruirlo por efecto**. Final: **Mago Oscuro 2500 + Mago Oscuro Sabio 900** boca arriba; objetivo rival destruido; Chica Maga y Mil Cuchillos al GY, 1 robo y posible Mágica excavada en mano. La Skill no garantiza qué fue robado ni una Mágica excavada.

- **Si el rival niega únicamente el efecto de Mago Oscuro Sabio después de enviar Chica Maga desde la mano al GY:** la Chica Maga pagada no regresa a mano, **Mago Oscuro permanece en GY** si no lo movieron, **Sabio 900 ATK** sigue en Campo y la Normal fue gastada. No se acredita robo, Invocación Especial ni destrucción con Mil Cuchillos, pues no se controla «Mago Oscuro». La Skill ya se utilizó y no se reinicia por esta negación.
- **Si el rival retira Mago Oscuro después de que Sabio lo Invocó, antes de activar Mil Cuchillos:** aunque se haya robado una carta y Sabio siga presente, **no se cumple el requisito de controlar Mago Oscuro** desde esa ruta; Mil Cuchillos sigue en mano sin ser activada, salvo que se demuestre otro Mago Oscuro propio. El robo aleatorio y la excavación de Skill no se convierten en cartas elegidas a voluntad.
- **Si el rival retira el objetivo de Mil Cuchillos después de su activación:** la destrucción de ese monstruo concreto no se acredita; Mago Oscuro y Sabio pueden permanecer como cuerpos si nada los afectó. El resultado exacto de la Mágica depende de la resolución legal y la carta que intervino, por lo que no se dibuja el objetivo como destruido automáticamente.

**Traza A09 de zonas al terminar cada paso de `707:A09:ILLUSION:SAGE:KNIVES02` (Skill y remoción de monstruo):** las cartas excavadas y robadas son variables; el LEGEND único está en GY al resolver la Skill sin asumir qué posición ocupaba entre las tres excavadas.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Chica Maga Oscura #16371, Mago Oscuro Sabio #19597, Mil Cuchillos #15450 y posible Mágica excavada desconocida | — | — | Mago Oscuro #15410 y entre 1 y 3 cartas excavadas adicionales de identidades variables (sin duplicar al LEGEND) | — | Un monstruo rival objetivo de identidad desconocida permanece en Campo | — | Skill ILLUSION OF EXECUTION usada; Rush permite Normal posterior; Extra sin uso |
| P2 | Mil Cuchillos #15450, 1 carta robada desconocida y posible Mágica excavada desconocida | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Mago Oscuro #15410 (Ataque, 2500 ATK) | — | Chica Maga Oscura #16371 y otras excavadas desconocidas en GY | — | Monstruo rival todavía presente, sin daño atribuido | — | Rush: Normal de Sabio realizada; Skill usada; Extra sin uso |
| P3 | 1 carta robada desconocida y posible Mágica excavada desconocida | Mago Oscuro Sabio #19597 (Ataque, 900 ATK), Mago Oscuro #15410 (Ataque, 2500 ATK) | — | Chica Maga Oscura #16371, Mil Cuchillos #15450 y otras excavadas desconocidas en GY | — | Monstruo rival seleccionado destruido por Mil Cuchillos si continuó siendo objetivo legal; no se adjudica barrido M/T | — | Skill ya usada; Normal de Sabio realizada; Extra sin uso |

**`707:A09:SECRETORDER:DM:KNIVES02` — turno cualquiera, 3200 ATK y quitar un monstruo**

- **Mano:** Mago Oscuro + Orden Secreta + Mil Cuchillos; Campo y GY propios vacíos, rival con monstruo seleccionable, propia Main Phase y sin respuestas.
1. Activar Orden Secreta, Invocar Especialmente **Mago Oscuro Normal Nivel 7 de la mano** sin Sacrificios; ATK **3200** este turno y resistencia temporal a destrucción por Trampa rival según Orden Secreta. Normal **libre**.
2. Activar Mil Cuchillos y destruir el monstruo rival elegido. **Endboard:** Mago Oscuro **ATK 3200 este turno / 2500 después**, Normal libre, ambas Mágicas al GY, rival pierde 1 monstruo. **No** afirmar retirada de todas las M/T: eso corresponde a `SECRETORDER:DM01` con otra Mágica en mano.

- **Si el rival niega Orden Secreta antes de que invoque Mago Oscuro:** desde esa mano mínima no existe un Mago Oscuro boca arriba que habilite Mil Cuchillos. La Normal sigue sin usar, pero **no hay un campo de 3200 ATK** ni un monstruo rival destruido por esta línea; las zonas de Orden Secreta/Mago Oscuro se registran según el efecto exacto de negación.
- **Si el rival retira Mago Oscuro después de la Invocación por Orden Secreta y antes de Mil Cuchillos:** se pierde el requisito de controlar Mago Oscuro; **Mil Cuchillos queda en mano** sin una activación legal por esta línea. No se conserva el refuerzo de 3200 ATK sobre un monstruo que ya no está en Campo. La Normal no se gastó al usar Orden Secreta.
- **Si el rival impide la destrucción del monstruo seleccionado con Mil Cuchillos sin retirar Mago Oscuro:** se conserva **Mago Oscuro en Campo**, con el refuerzo de 3200 solo hasta terminar ese turno y Normal disponible, pero **no se cuenta la retirada rival**; la Mágica ya fue usada. No se transforma la protección contra Trampas de Orden Secreta en inmunidad general.

**Traza A09 de zonas al terminar cada paso de `707:A09:SECRETORDER:DM:KNIVES02` (sin Skill):** la Invocación de Orden Secreta no gasta Normal, el ATK extra caduca al finalizar el turno y la retirada afecta únicamente al monstruo rival elegido.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Mil Cuchillos #15450 | Mago Oscuro #15410 (Ataque, 3200 ATK temporal; protección contra destrucción por Trampas este turno) | — | Orden Secreta #17212 en GY | — | Monstruo rival elegible de identidad variable sigue presente | — | Rush: Normal sin gastar; Skill intacta; Extra sin uso |
| P2 | — | Mago Oscuro #15410 (Ataque, 3200 ATK temporal) | — | Orden Secreta #17212 y Mil Cuchillos #15450 en GY | — | Monstruo rival seleccionado destruido por Mil Cuchillos; no se retiraron M/T por esta línea | — | Normal libre; Skill intacta; Extra sin uso; ATK vuelve a 2500 al finalizar el turno |

**`707:A09:JEWEL:PAIR:KNIVES03` — dos monstruos y retirada, sin Skill**

- **Mano:** Piedra de los Magos Oscuros + Mago Oscuro + Chica Maga Oscura + Mil Cuchillos; Campo/GY propios vacíos, dos zonas de monstruo libres, rival controla un monstruo seleccionable, Main Phase propia; sin respuestas.
1. Activar **Piedra de los Magos Oscuros**, Invocar Especialmente **Mago Oscuro + Chica Maga Oscura** desde mano en Ataque como dos monstruos independientes; Piedra va al GY, la Normal queda sin gastar.
2. Activar **Mil Cuchillos** mientras Mago Oscuro boca arriba permanece en Campo; destruir el monstruo rival legal seleccionado. **Endboard:** **Mago Oscuro 2500 + Chica Maga Oscura 2000**, Mágicas Piedra y Mil Cuchillos al GY, rival pierde 1 monstruo, Skill intacta, Normal libre. El ATK de Chica Maga **no** aumenta solo porque Mago Oscuro esté en Campo.

**Traza A09 de zonas al terminar cada paso de `707:A09:JEWEL:PAIR:KNIVES03` (dos cuerpos, sin Skill):** el efecto de Piedra trae los dos monstruos en el paso 1; ambos siguen presentes después de utilizar Mil Cuchillos y no se crea ningún aumento de ATK de Chica Maga por proximidad.

| Hito | Mano | Monstruos | M/T | Cementerio | Destierro propio | Estado rival | Materiales | Normal y Extra |
|---|---|---|---|---|---|---|---|---|
| P1 | Mil Cuchillos #15450 | Mago Oscuro #15410 (Ataque, 2500 ATK), Chica Maga Oscura #16371 (Ataque, 2000 ATK) | — | Piedra de los Magos Oscuros #19598 en GY | — | Monstruo rival seleccionable aún presente | Dos monstruos invocados de mano independientes, no materiales Xyz | Rush: Normal sin gastar; Skill intacta; Extra sin uso |
| P2 | — | Mago Oscuro #15410 (Ataque, 2500 ATK), Chica Maga Oscura #16371 (Ataque, 2000 ATK) | — | Piedra de los Magos Oscuros #19598 y Mil Cuchillos #15450 en GY | — | Monstruo rival elegido destruido si permaneció legal; M/T rivales sin cambios acreditados | No se usaron monstruos como material; ambos siguen en Campo | Normal libre; Skill intacta; Extra sin uso |

Son **tres aperturas de respuesta a monstruo** con distinta mano/Skill, cuerpo restante y coste de Normal, aparte de las rutas que eliminan M/T. **No** declarar una ruta a Gaia sin materiales ni convertir una única Piedra en combo de eliminación. Todas emplean cartas y CIDs ya citados en `ILLUSION:SAGE01`, `SECRETORDER:DM01` y `JEWEL:PAIR01`; legalidad dependiente de la Skill local únicamente en la primera..

#### A09 — Matriz de decisiones ofensivas y defensivas (Rush)

| Situación | Elección recomendada con mano real | Campo final / límite |
|---|---|---|
| **Primero, dejar dos cuerpos** | `JEWEL:PAIR01`, con Piedra + Mago Oscuro + Chica Maga, sin necesitar Skill. | 2500 + 2000 ATK en Campo; **sin negación garantizada**, y no existe Battle Phase propia en el primer turno. |
| **Segundo, rival tiene M/T** | `ILLUSION:SAGE01` desde turno 2, `SECRETORDER:DM01` en cualquier turno, o `EXECUTOR:DARKMAGIC01` si dispones de dos Sacrificios. | Destrucción de **M/T rivales** más el campo descrito en cada ruta; no sustituir automáticamente por Mil Cuchillos. |
| **Segundo, rival tiene un jefe/monstruo** | `ILLUSION:SAGE:KNIVES02`, `SECRETORDER:DM:KNIVES02`, `JEWEL:PAIR:KNIVES03` o `EXECUTOR:KNIVES01` según las cartas disponibles. | **Una** destrucción de monstruo elegible, y respectivamente 2, 1, 2 o 1 monstruos propios. No contar combate/doble ataque no ejecutados. |
| **Durante Battle Phase** | Si Mago Oscuro entró con Orden Secreta, usar su **ATK temporal 3200** en el turno de Invocación; con Piedra sin Orden, su ATK es 2500. | Solo calcular daño por ataques realmente legales, no atribuir al monstruo retirado daño de batalla extra ni conservar 3200 al siguiente turno. |
| **Turno rival** | Estas fichas no han demostrado Efecto Rápido ni Trampa ya activa que niegue un efecto rival. | **NO_APLICA** como combo de interrupción de estos starters. No confundir «protegido de destrucción por Trampa este turno» con negar Trampas. |
| **Recuperación** | Si el envío/excavación de Skill no deja Mago Oscuro en GY o se niega la reanimación de Sabio, detener `ILLUSION:SAGE` antes de cualquier Mágica que exija «Mago Oscuro». | Conservar solamente monstruos reales en Campo; **Mil Cuchillos/Ataque Mágico Oscuro no se pueden activar** sin el nombre exigido boca arriba. |

<!-- STATION_X_EJECUCION_A01_A10_20261116 -->
## EJECUCIÓN DOCUMENTAL A01–A10 Y MATRIZ CANÓNICA A06 — 16-11-2026

**Naturaleza de este corte:** comprobación automática y cruzada de fuentes ya incluidas en el paquete. **No** es replay, juicio de legalidad completo, ensayo físico, confirmación nueva del titular ni integración en producción. Los estados parciales se conservan, incluso cuando la presencia estructural es del 100 %. No se añadieron cartas, modificaron cantidades ni inventaron combos. La investigación restante es tarea de IA; no se incorporan pruebas del usuario a sus denominadores.

**Inventario base cotejado:** `707` · Dark Magician · Main 30 · Extra 7 · Side 0 · Reserva 0 · 20 identidades distintas.

### Estado de ejecución por apartado (contenido de este deck)

**Control individual de Dark Magician Rush (corte 16-11-2026):** las diez filas A01–A10 de abajo son el tablero **de este deck**, no un promedio de los trece. La cobertura documental allí expresada no acredita cierres totales: el porcentaje de **cierre de cada apartado sigue sin conciliación**, y ninguno debe etiquetarse 100 % por existir una fila. En la comprobación funcional A05 reciente se contrastaron **0/20** fichas con fuente oficial para su función principal (restan **20** sin ese contraste de la misma tanda; las 0 tampoco suponen cierre integral de A05). A06 conserva **4 relaciones condicionales** y **3 accesos Extra** sin acreditar. **Próxima ejecución local recomendada:** concluir A05 por identidad, después A06/A07 con las relaciones, materiales y fuentes de este mismo inventario; finalmente A08–A10. Solo actualizar la fila A01–A10 trabajada de este archivo y su reflejo en el registro único; no actualizar otros decks ni llevar porcentajes para los módulos 11–36.

| Apartado | Estado del corte | Resultado material comprobado | Pendiente específico para cerrar |
|---|---|---|---|
| **01** Rol y propósito | DOCUMENTADO; AUDITORÍA PARCIAL | Perfil y plan de juego anteriores conservados | Contrastar condiciones de victoria y sus cartas contra A09 y amenazas reales |
| **02** Recepción e identidad | IDENTIDAD COTEJADA; AUDITORÍA PARCIAL | Deck ID, formato y cantidades confrontadas con inventario confirmado | Corroborar datos de equipo/versión cuando no consten; no cambiar inventario |
| **03** Inventario | COINCIDE ESTRUCTURALMENTE; AUDITORÍA PARCIAL | 20/20 fichas visibles; zonas A05: Main 30/30, Extra 7/7, Side 0/0, Reserva 0/0 | Cotejar requisitos mecánicos individuales y excepciones de identidad sin revisión general de banlist |
| **04** Fuentes y fotografías | COINCIDENCIA DE ARCHIVOS; AUDITORÍA PARCIAL | 20/20 imágenes CID decodificables; 20/20 fichas con URL de fuente | Cotejar texto vigente completo y fotografía correcta en fuente oficial; existencia de archivo no equivale a identidad visual validada |
| **05** Cartas individuales | COBERTURA DOCUMENTAL 20/20; AUDITORÍA PARCIAL | 20 fichas A05 enlazadas a la matriz A06; funciones preexistentes preservadas | Verificar efecto, coste, restricción, utilidad y uso autónomo por identidad |
| **06** Sinergias y motores | MATRIZ CREADA 20/20; AUDITORÍA PARCIAL | 20 filas por identidad y copias desglosadas por zona según A05; etiquetas A06 originales sin promoción de evidencia | Confirmar relaciones causales, Extra sin acceso acreditado y enlaces A08/A09 en ambos sentidos |
| **07** Reglas | CONTRATOS EXISTENTES 20/20; AUDITORÍA PARCIAL | Identidad/CID cruzados con A05 en 20/20 identidades | Resolver ventanas, materiales, cadenas, restricciones y excepciones por efecto y formato |
| **08** Jugadas y decisiones | 7 DECISIONES DOCUMENTADAS; AUDITORÍA PARCIAL | 7 casos A08 y 0 planes Side documentales; IDs referenciados en la matriz cuando consta CID | Demostrar acción legal y resultado, y ampliar combinaciones 1/2/3/4+ sin inflar combos |
| **09** Combos y rutas | 7 EJERCICIOS DOCUMENTADOS; AUDITORÍA PARCIAL | 7 ejercicios y 10 manos registradas; fotos enlazadas solo como indicios, no como participantes certificados | Reconstruir pasos, comprobar todas las cartas/materiales y asignar participantes causales antes de declarar cualquier ruta legal |
| **10** Guías visuales | CONFORME EDITORIAL SEGÚN DECISIÓN V31; REVISIÓN TÉCNICA PARCIAL | Archivo de guía existente; se conserva diseño actual | Cotejar visualmente por paso las rutas A09 comprobadas; no confundir aceptación editorial con simulación |

### APARTADO_06 — Matriz única de trazabilidad por identidad de carta

Una fila por identidad (`deck_id:CARD:CID`), con el desglose íntegro de copias y zonas que proviene de A05; cuando el mapa A06 agrupa copias bajo una zona primaria, **prevalece este desglose**. Los IDs A08 provienen de `cartas_relevantes` y representan **vínculos documentales por comprobar**. Los IDs A09 proceden únicamente de fotografías de los ejercicios; indican **candidatas a contraste**, **no** participación causal acreditada ni combo válido. No omitir una carta si todavía carece de enlaces. Los planes Side son condicionales entre duelos; Reserva nunca se trata como disponible.

| ID / Carta | Zona y copias (A05) | Función A05 | Relación A06 | A08 documentado (sin validar) | A09 candidato por foto (sin validar) | Side / Reserva | Estado / acción siguiente |
|---|---|---|---|---|---|---|---|
| `707:CARD:15451` ブラック・マジック 黒・魔・導 | Main ×2 | INTERACCION_DESTRUCCION | SINERGIA_DE_ENGINE_DOCUMENTADA | A08:707:HABILIDAD_O_CONTINUIDAD; A08:707:MANO_IRREGULAR; A08:707:PRIMERO; A08:707:RECURSOS; A08:707:RESPUESTA_RIVAL; A08:707:SEGUNDO; A08:707:TURNO_TARDIO | 707:A09:EXECUTOR:DARKMAGIC01; 707:A09:ILLUSION:SAGE01; 707:A09:SECRETORDER:DM01 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:16772` アメイジング・ディーラー アメイジング・ディーラー | Main ×1 | CARGA_CEMENTERIO · RECUPERACION_MANO | SINERGIA_DE_ENGINE_DOCUMENTADA | A08:707:HABILIDAD_O_CONTINUIDAD; A08:707:MANO_IRREGULAR; A08:707:PRIMERO; A08:707:RECURSOS; A08:707:RESPUESTA_RIVAL; A08:707:SEGUNDO; A08:707:TURNO_TARDIO | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:18685` レジェンド・マジシャン レジェンド・マジシャン | Main ×2 | CONSISTENCIA · CARGA_CEMENTERIO | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:19597` えんじゅくのくろまじゅつし 円熟の黒魔術師 | Main ×1 | EXTENSOR_CONDICIONADO · CARGA_CEMENTERIO · RECUPERACION_MANO | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:EXECUTOR:DARKMAGIC01; 707:A09:EXECUTOR:KNIVES01; 707:A09:ILLUSION:SAGE01; 707:A09:ILLUSION:SAGE:KNIVES02 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:19329` モンスターしょうしゅう モンスター招集 | Main ×2 | EXTENSOR_CONDICIONADO · CARGA_CEMENTERIO · RECUPERACION_MANO · COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:ILLUSION:SAGE01; 707:A09:SECRETORDER:DM01; 707:A09:SECRETORDER:DM:KNIVES02 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:19773` ブラック・エグゼキューター 黒魔導の遂行者 | Main ×3 | CARGA_CEMENTERIO · INTERACCION_DESTRUCCION | CONDICIONAL_NO_VERIFICADA | A08:707:HABILIDAD_O_CONTINUIDAD; A08:707:MANO_IRREGULAR; A08:707:PRIMERO; A08:707:RECURSOS; A08:707:RESPUESTA_RIVAL; A08:707:SEGUNDO; A08:707:TURNO_TARDIO | 707:A09:EXECUTOR:DARKMAGIC01; 707:A09:EXECUTOR:KNIVES01 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:17209` ブラックレゾナンスバースト 黒・魔・導・響・弾 | Main ×3 | COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:20151` シャイニーシェイディー シャイニーシェイディー | Main ×2 | EXTENSOR_CONDICIONADO · CARGA_CEMENTERIO · COMBATE · INTERACCION_CADENA | CONDICIONAL_NO_VERIFICADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:19598` くろまじゅつしのほうせき 黒魔術師の宝石 | Main ×3 | EXTENSOR_CONDICIONADO · COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:JEWEL:PAIR:KNIVES03 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:15410` ブラック・マジシャン ブラック・マジシャン | Main ×1 | COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | A08:707:HABILIDAD_O_CONTINUIDAD; A08:707:MANO_IRREGULAR; A08:707:PRIMERO; A08:707:RECURSOS; A08:707:RESPUESTA_RIVAL; A08:707:SEGUNDO; A08:707:TURNO_TARDIO | 707:A09:EXECUTOR:DARKMAGIC01; 707:A09:EXECUTOR:KNIVES01; 707:A09:ILLUSION:SAGE01; 707:A09:ILLUSION:SAGE:KNIVES02; 707:A09:JEWEL:PAIR:KNIVES03; 707:A09:SECRETORDER:DM01; 707:A09:SECRETORDER:DM:KNIVES02 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:20305` リリースレイヤー リリースレイヤー | Main ×1 | ACCESO_NORMAL · CARGA_CEMENTERIO · TRIBUTO | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:EXECUTOR:DARKMAGIC01; 707:A09:EXECUTOR:KNIVES01 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:16371` ブラック・マジシャン・ガール ブラック・マジシャン・ガール | Main ×3 | COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:ILLUSION:SAGE01; 707:A09:ILLUSION:SAGE:KNIVES02; 707:A09:JEWEL:PAIR:KNIVES03 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:15450` サウザンドナイフ 千本ナイフ | Main ×2 | INTERACCION_DESTRUCCION | SINERGIA_DE_ENGINE_DOCUMENTADA | A08:707:HABILIDAD_O_CONTINUIDAD; A08:707:MANO_IRREGULAR; A08:707:PRIMERO; A08:707:RECURSOS; A08:707:RESPUESTA_RIVAL; A08:707:SEGUNDO; A08:707:TURNO_TARDIO | 707:A09:EXECUTOR:KNIVES01; 707:A09:ILLUSION:SAGE:KNIVES02; 707:A09:JEWEL:PAIR:KNIVES03; 707:A09:SECRETORDER:DM:KNIVES02 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:19341` エクスキューティー・ライディング！ エクスキューティー・ライディング！ | Main ×1 | EXTENSOR_CONDICIONADO · COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:17212` シークレットオーダー 潜入開始 | Main ×1 | EXTENSOR_CONDICIONADO · INTERACCION_DESTRUCCION · COMBATE | SINERGIA_DE_ENGINE_DOCUMENTADA | SIN_ENLACE_A08_CID | 707:A09:SECRETORDER:DM01; 707:A09:SECRETORDER:DM:KNIVES02 | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad |
| `707:CARD:16372` ごうよくなつぼ 強欲な壺 | Main ×1 | RECUPERACION_MANO | CONDICIONAL_NO_VERIFICADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:21007` こうこうのじゅばく 昂光の呪縛 | Main ×1 | RECUPERACION_MANO | CONDICIONAL_NO_VERIFICADA | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | PRECLASIFICACIÓN; comprobar acción concreta, enlace y legalidad; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:19995` しっぷうのりゅうきしガイア 疾風の竜騎士ガイア | Extra ×3 | CARGA_CEMENTERIO · RECUPERACION_MANO · COMBATE | ACCESO_EXTRA_NO_ACREDITADO | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | SIN_RUTA_EXTRA_ACREDITADA; verificar materiales o uso alternativo; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:18298` りゅうきしガイア 竜騎士ガイア | Extra ×3 | MATERIAL_DE_FUSION | ACCESO_EXTRA_NO_ACREDITADO | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | SIN_RUTA_EXTRA_ACREDITADA; verificar materiales o uso alternativo; sin referencia A08/A09 por CID/foto (no implica inutilidad) |
| `707:CARD:19323` ひゃくせんのはしゃガイア 百戦の覇者ガイア | Extra ×1 | EXTENSOR_CONDICIONADO · INTERACCION_DESTRUCCION | ACCESO_EXTRA_NO_ACREDITADO | SIN_ENLACE_A08_CID | SIN_ENLACE_A09_FOTO | Lista actual | SIN_RUTA_EXTRA_ACREDITADA; verificar materiales o uso alternativo; sin referencia A08/A09 por CID/foto (no implica inutilidad) |

### Balance de referencias y faltantes identificados

- Identidades analizadas como **datos de inventario**, no como legalidad: **20/20**. Main 30; Extra 7; Side 0; Reserva 0.
- Con referencia documental A08 mediante CID: **5/20** identidades. Sin referencia A08 por CID: **15**; ello no equivale a falta de utilidad.
- Con fotografía en algún ejercicio A09: **10/20** identidades. Sin tal indicio: **10**; las fotos no certifican pasos ni participación.
- Extra con acceso no acreditado según A06: **3** identidades; priorizar contraste de material, procedimiento, restricciones y usos alternativos.
- Decisiones A08 que mencionan CID fuera del inventario: **0**; fotos A09 con CID ajeno: **0**; rutas de fotografía ausentes: **0**. Los casos requieren revisión contextual antes de clasificarlos como error de juego.
- Hallazgos estructurales a tratar: **ninguno en los controles de existencia y conteo**.
- Próxima ejecución IA prioritaria: cotejar texto completo y materiales de cada enlace, cerrar condiciones A07/A09, separar rutas verdaderas de interacciones y actualizar estados individuales en el único registro global. No se autoriza modificar las listas ni publicar resultados en Station X.
