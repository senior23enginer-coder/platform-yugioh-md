# Cristron / Horus — estudio individual A01–A10, profundización v3 (17-11-2026)

> **CRITERIO DEL INVENTARIO FÍSICO (V41):** Las cartas y sus cantidades se conservan exactamente como fueron documentadas. El análisis A01–A10 se basa en sus efectos, materiales, ventanas, zonas, cadenas y recursos; no evalúa listas externas de prohibidas o limitadas. No se atribuyen partidas ni simulaciones ejecutadas a estos análisis documentales.

<a id="actualizacion-v37"></a>

> **CORTE IMPORTABLE V37 (17-11-2026).** Fotos reales 39/39 correspondientes al 100 % de las identidades identificadas físicamente. Los recuentos antiguos de `FOTO_PENDIENTE` dentro de análisis V35/V36 son históricos y quedan sustituidos por este control. A01–A10 documentados; **0 replays y sin certificación de simulación**. Inventario sin cambios. Guía visual: [abrir](guias/GUIA_VISUAL_A01_A10.html).


> **ACTUALIZACIÓN V36 — FOTOGRAFÍAS REALES 39/39 (100 % del inventario identificado)**. Las cifras de imágenes pendientes mencionadas en los apartados V35 son históricas. Ver [actualización](#actualizacion-v37), [galería visual](guias/GUIA_VISUAL_A01_A10.html) y [manifiesto](#actualizacion-v37). Los combos son análisis escritos, **no simulaciones comprobadas**; las cartas y cantidades siguen intactas.

> **Complemento V35 A01–A05:** [profundización A01–A05 integrada](#profundizacion-a01-a05). Preserva las 70 copias, 39 CIDs y 20 fotografías; no altera A06–A10 ni convierte trazas lógicas en replays.

## IDENTIDAD BÁSICA

- `deck_id` real de Station X: **PENDIENTE_DE_ASIGNACIÓN**. `NUEVO_13` es solo una referencia documental, nunca un ID de base de datos.
- Fuente de inventario: listado completo compartido por Miguel el **16-11-2026**; nombres y cantidades conservados exactamente como fueron proporcionados.
- **Main: 40** (27 monstruos, 12 mágicas, 1 trampa); **Extra: 15**; **Side: 15**; **Reserva: 0**; **total: 70 copias**.

## CONTROL INDIVIDUAL DE AVANCE A01–A10 — Cristron / Horus

**Alcance y corte:** primera iteración, ampliación v2 y **profundización v3 del 17-11-2026**. Este es el control **exclusivo de este deck**; `NUEVO_13` es referencia documental mientras falta el ID real de Station X. **Main 40, Extra 15, Side 15, Reserva 0; 70 copias y 39 identidades documentadas.** La v3 conserva las **siete rutas principales** C01–C07 y amplía de **cuatro a siete variantes V01–V07**; las trazas son lógicas **no simuladas** y sus campos dependen de supuestos explícitos. No se inventan porcentajes de victoria, fotografías ni replays. El control del maestro se sincronizará desde este archivo al incorporar la actualización; un ZIP individual no reemplaza por sí solo todo el registro maestro.

| Apartado | Estado propio del deck | Progreso o evidencia comprobable | Pendiente para cerrar |
|---|---|---|---|
| **A01** Rol y propósito | **PARCIAL AVANZADO** | Dos motores reales, tres ritmos de juego y matriz de fortalezas/riesgos por fase; salidas Sincronía/Xyz y Nova/Infinito | Medir resultados en partidas y confirmar formato |
| **A02** Planes y estilos | **PARCIAL AVANZADO** | Plan primero/segundo, curva de riesgos, árbol de decisiones y **20 manos H01–H20** | Ensayar interrupciones y manos reales |
| **A03** Inventario | **DOCUMENTADO; NO APROBADO** | Cantidad física preservada y documentada | Aprobación de Miguel; elección de reemplazos si ese es su formato |
| **A04** Identidad, CID y fotos | IMÁGENES CERRADAS V37 | 39/39 fotos auténticas por CID; inventario sin cambios | Aprobación de Miguel y prueba del importador real pendientes |
| **A05** Efectos y uso | **PARCIAL AVANZADO** | **39/39 roles funcionales resumidos** en la matriz; fuentes Konami por CID | Ampliar matices de todos los efectos y rulings raros |
| **A06** Sinergias y Extra | **PARCIAL AVANZADO** | **39/39 filas**, 21 vínculos R01–R21; 13/13 Extra con coste, materiales, ventana y función; variantes V05–V07 | Contrastar líneas condicionales y simulación; no todas las Extra son alcanzables desde cualquier apertura |
| **A07** Reglas y cadenas | **PARCIAL AVANZADO** | 21 reglas RGL01–RGL21 y 14 interrupciones INT01–INT14, con ventanas y materiales cotejados | Reproducir cadenas adversarias en prueba de mesa |
| **A08** Estrategia y Side | **PARCIAL AVANZADO** | 26 decisiones D01–D26 y seis planes Side S01–S06 con intercambio 1:1 | Medir utilidad real y ladrillos de apertura |
| **A09** Jugadas y manos | **PARCIAL AVANZADO** | **7 combos C01–C07**, **7 variantes V01–V07**, **20 manos H01–H20**, **0 replays** | Ensayar secuencias, ventanas, interrupciones y combos condicionales |
| **A10** Guías visuales | GUÍAS VISUALES V37 | Guía HTML local y 39/39 fotos disponibles | Combos y cadenas pendientes de contrastar en simulador |

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

## APARTADO_01 — Identidad y propósito de esta construcción

**Dictamen:** híbrido de **control reactivo por Sincronía Máquina (Cristron)** y **presencia autónoma de Nivel 8 / Xyz (Horus)**; las distintas cartas de interacción/respuestas no convierten por sí solas todas las manos en un tablero. Objetivo 1: sobrevivir e interrumpir desde **Tristaros/Citree**, obtener ventaja con **Elesqueletus** y convertir recursos en presión; objetivo 2: desarrollar **Amset + Hapi** a **Número 90** para negar efecto de monstruo o a **Vampiro Zombi** para moler y extender; objetivo 3: llegar a **Nova → Infinito con dos Nivel 5 Máquina** (C06) para negar la activación de cartas/efectos; objetivo 4: ganar tempo con **Gotas Prohibidas / Súper Polimerización** antes de aplicar bloqueos del Extra. Son **objetivos tácticos**, no victorias garantizadas.

**Conflictos estructurales reales:** (a) **Smiger/Thystvern en campo** restringen el resto del turno a **Sincronías Máquina** si usan su efecto de destruir; (b) **Sulfador al invocarse por su efecto propio** restringe a **Máquinas** del Extra por el resto del turno; (c) tras cualquiera de esas restricciones, **S:P, Número 90, Vampiro Zombi, Garura y Fangodragón** pueden quedar inaccesibles ese turno según el caso; (d) la segunda habilidad de **Hagoita** exige un Cantante «Velociroid» que esta lista no lleva. No declarar «puedo sacar cualquier Extra».

**Fortalezas:** dos motores que pueden trabajar en turnos distintos, recuperación de Cristron mediante Inclusión/Elesqueletus, descarte Horus que alimenta Cementerio, acceso alternativo a Infinito sin Normal (C06), sinergia Amset→Smiger de Cementerio (C07), salidas Máquina mediante las restricciones y cartas disruptivas genéricas. **Debilidades:** dependencia de Normal para algunos starters, escasez de Cantantes frente a 15 Extra, gastar Smiger en Campo impide usar su búsqueda de Cementerio ese mismo turno, C06 consume otra copia de Azufafnir del Deck y el Side puede bloquear nuestras propias búsquedas o destierros.

## APARTADO_02 — Identidad del inventario y planes

1. **Primero (línea Cristron):** priorizar la pieza que deja **Tristaros** o **Citree** operativa en turno rival; reservar la interrupción para el punto adecuado. C01/C02/C03 dependen del starter y las piezas disponibles.
2. **Primero (línea Horus):** con **Amset + Hapi** o **Sarcófago + Amset**, construir un Xyz de Rango 8 **antes** de activar efectos que cierren el Extra; C04/C05. Con **Amset + Smiger**, considerar la salida híbrida C07: un Horus 8 y Tristaros listo, sin bloquear el Extra en el turno propio.
3. **Segundo:** determinar primero si hay material compatible para Súper Polimerización, negar con Gotas o impedir una búsqueda; **después** desarrollar Smiger/Sulfador. No activar una restricción de Sincronía antes de decidir una Fusión, Link o Xyz no Máquina.
4. **Turno rival:** Tristaros responde a activación de carta/efecto y hace Sincronía Máquina con el monstruo que trae; Citree usa únicamente ella y un no Cantante revivido del Cementerio en Main/Battle rival.
5. **Recuperación:** Inclusión en Cementerio revive un Cristron, Elesqueletus recupera uno del Cementerio/destierro tras su Sincronía, **Thystvern se destierra desde el Cementerio para buscar un monstruo Cristron del Deck**; Sarcófago habilita Horus del Cementerio. No contabilizar recursos usados/desterrados como disponibles en mano. **Azufafnir destruido desde Campo** puede sustituirse por otra pieza del Deck (C06/V03), pero requiere que esa copia siga allí.

### A02.1 — Cómo conservar recursos de turno en turno

| Momento | Prioridad del jugador | Recurso que no debes dar por supuesto |
|---|---|---|
| Turno 1, mano corta | Si solo hay Smiger/Tristaros, preparar Citree o Tristaros reactivo **antes** de gastar herramientas para un tablero irreal | Que Hagoita/Elesqueletus ya está en Campo al pasar turno; sin respuesta rival aún no está |
| Turno 1, mano de tres piezas | Comparar C02 con C06: **recuperación + futuro Quarion** frente a **Infinito con negación inmediata** | Que Nova/Infinito sea legal después del efecto de Campo de Smiger: no lo es ese turno |
| Tras un efecto negado | Revisar cartas que realmente permanecen en Campo, GY y Deck; elegir Horus o segunda ruta del motor | Smiger destruido/buscado, Inclusión recuperada o robo opcional que jamás se resolvió |
| Turno rival | Guardar Citree para Main/Battle, Tristaros para activación; Agrupamiento solo si se colocó en turno anterior | Una cadena de negación que Tristaros o Elesqueletus **no** posee |
| Turno 3+ | Con Sarcófago sobreviviente, reutilizar Amset/Hapi que estén en GY; con Elesqueletus, recuperar Inclusión/Smiger del lugar real | Horus convertido en material Xyz **no** está en GY; primero debe desacoplarse o ir el Xyz al GY |
| Segundo contra campo amplio | Evaluar Gotas/Súper Polimerización **antes** de bloquear el Extra y conservar un starter Cristron viable | Que un par cualquiera de monstruos cumple Garura/Fangodragón o que la carta responda a todo |

### A02.2 — Frecuencia matemática de ver los starters, NO de ganar

**Supuesto reproducible:** 40 cartas Main y mano inicial de **5 cartas tomadas al azar sin reemplazo**, sin mulligan, búsquedas, robos ni efectos rivales. Cada fila mide **solamente** la probabilidad combinatoria de tener al menos una copia de **cada nombre solicitado**; **NO** mide que el combo pueda resolverse (puede haberse robado su único objetivo del Deck, faltar otra copia en Deck, ser negado o no existir la ventana rival). Fórmula para dos grupos: `1 − C(40−a,5)/C(40,5) − C(40−b,5)/C(40,5) + C(40−a−b,5)/C(40,5)`; para tres grupos, inclusión-exclusión análoga. `C(n,k)` es combinación.

| Apertura por nombres confirmados | Copias en Main | Frecuencia teórica de la coincidencia |
|---|---|---:|
| Al menos **Smiger** para C01 | 3 | **33,76 %** |
| **Inclusión + Sulfador** para C02 | 3 + 2 | **6,81 %** |
| **Inclusión + Sulfador + Azufafnir** para C06 | 3 + 2 + 3 | **1,58 %** |
| **Amset + Smiger** para C07 | 3 + 3 | **9,80 %** |
| **Amset + Hapi** para C04 | 3 + 1 | **3,55 %** |
| **Azufafnir + Smiger** para V03 | 3 + 3 | **9,80 %** |

**Lectura para jugar:** C06 produce la negación más general de estas aperturas, pero **su combinación exacta de tres nombres es poco frecuente en cinco cartas**; conviene practicar C01/C07/V03 también. **No sumar los porcentajes**: las manos se superponen. La probabilidad real de completar una ruta debe descontar objetivos fuera del Deck y estudiar interrupciones, sin extrapolar estas cifras a victoria/competitividad.

**Identidad:** híbrido Cristron/Horus según cartas transcritas; `deck_id` real pendiente de asignación. No se modifican cantidades, nombres ni zonas.

## APARTADO_03 y APARTADO_04 — Inventario y fuentes

La matriz A06 de abajo conserva **cada carta y copia** del inventario comunicado, con una sola fila por identidad y dos columnas de zona si una misma carta aparece en Main y Side.

**A03:** nombres y cantidades de Miguel inalterados: 40 Main (27 monstruos, 12 mágicas, 1 trampa), 15 Extra y 15 Side. Ninguna carta del Side se cuenta como inicial; el cotejo es numérico y de zonas.

**A04:** las 39 filas siguientes contienen ahora **CID y enlace a la ficha individual Konami oficial**. «Cristron» es el nombre español de **Crystron**; «Caballero Mecánico» es **Clockwork Knight Link-1**. Se copiaron **20 fotos reales existentes** del maestro a `imagenes/<CID>.jpg`; **19 fotos faltan** y quedan como `FOTO_PENDIENTE`. El CID documental no es el ID real del deck. No se usaron imágenes fabricadas. El texto Konami es la fuente de identidad/regla, no una prueba de simulación.

**Fotos locales útiles para esta iteración:** [Amset](imagenes/19153.jpg), [Hapi](imagenes/19155.jpg), [Sarcófago](imagenes/19200.jpg), [Flor de Ceniza](imagenes/12950.jpg), [Droll](imagenes/9279.jpg), [Fuwalos](imagenes/20500.jpg), [Purulia](imagenes/20206.jpg), [Gotas](imagenes/15299.jpg), [Súper Polimerización](imagenes/7445.jpg); [Número 90 — FOTO_PENDIENTE en fuente oficial](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13826&ope=2&request_locale=es). Los enlaces locales anteriores corresponden a imágenes efectivamente presentes.

## APARTADO_05 y APARTADO_06 — Matriz ÚNICA por identidad, función y sinergia

<a id="APARTADO_06"></a>

**APARTADO_06 — Matriz canónica de trazabilidad.** IDs `CRYH-###` son locales documentales; la columna CID identifica la ficha oficial Konami. **Rol preliminar** significa texto/finalidad estudiados, pero no resultado de simulación. Cada relación Rxx se explica inmediatamente después de esta matriz. `Cxx` y `Vxx` enlazan a las secuencias A09; cuando no existe una secuencia propia, la carta puede seguir siendo funcional (staple, interrupción o Side). **Se conserva una sola matriz, sin archivos paralelos por carta.**

| ID local | Carta del inventario original | Main | Extra | Side | Reserva | CID oficial | Función, condición y enlace causal (A05/A06/A08/A09) | Evidencia |
|---|---|---:|---:|---:|---:|---|---|---|
| CRYH-001 | Cristron Sulfador | 2 | 0 | 0 | 0 | [20759](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=es) | Nivel 5 no Cantante; destruye una carta Cristron propia para invocarse desde mano/GY y después manda hasta 2 Cristron distintos del Deck al GY; **bloqueo a Máquinas** Extra. R04/R07/R19; C02/C06/C07/V01. | Texto oficial; foto pendiente; combo lógico |
| CRYH-002 | Cristron Smiger | 3 | 0 | 0 | 0 | [12608](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=es) | Nivel 3 no Cantante; destruye boca arriba propia y trae Cantante del Deck; **bloqueo a Sincronías Máquina**. GY destierro busca M/T Cristron, pero **solo 1 de sus efectos por turno**. R02/R03; C01/C02/C06 como coste/C07 como GY/V03. | Texto oficial; foto pendiente; combo lógico |
| CRYH-003 | Cristron Tristaros | 2 | 0 | 0 | 0 | [20758](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=es) | Nivel 2 Cantante; al responder a activación rival trae Cristron del Deck y hace Sincronía Máquina **incluyéndolo**; GY destierro destruye Sincronía propia para traer 2 Cristron del Deck; bloqueo a Máquinas. R07/R08; C03/V01. | Texto oficial; foto pendiente; combo lógico |
| CRYH-004 | Cristron Azufafnir | 3 | 0 | 0 | 0 | [12756](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12756&ope=2&request_locale=es) | Nivel 5 no Cantante; descarta otro Cristron para invocarse en DEF, después destruye carta propia; si se destruye en Campo puede traer Cristron del Deck en DEF. R12/R19; C06 con segundo Azufafnir en Deck, V01/V03. | Texto oficial; foto pendiente; combo lógico condicional |
| CRYH-005 | Cristron Citree | 1 | 0 | 0 | 0 | [12606](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12606&ope=2&request_locale=es) | Nivel 2 Cantante; en Main/Battle rival revive **un no Cantante** del GY con efecto negado y hace Sincronía Máquina **solo con esos dos**, desterrándolos. R06; C01/C02/V01. | Texto oficial; foto pendiente; combo lógico |
| CRYH-006 | Cristron Thystvern | 1 | 0 | 0 | 0 | [12609](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12609&ope=2&request_locale=es) | Nivel 3 no Cantante; como Smiger desde Campo pero en GY destierra para **buscar monstruo Cristron**; solo uno de sus dos efectos por turno. R11; C02. | Texto oficial; foto pendiente; función comprobada |
| CRYH-007 | Amset, Gloria de Horus | 3 | 0 | 0 | 0 | [19153](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19153&ope=2&request_locale=es) | Nivel 8; manda de mano 2 cartas **incluyéndose** para buscar Sarcófago y opcionalmente robar 1; desde GY se invoca si controlas Sarcófago. R13/R14/R15; C04/C05/C07 (descarta Smiger). | Oficial; foto local; combo lógico |
| CRYH-008 | Hapi, Guía de Horus | 1 | 0 | 0 | 0 | [19155](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19155&ope=2&request_locale=es) | Nivel 8; reaparece de GY con Sarcófago; si carta propia deja Campo por efecto rival puede recuperar 2 cartas de GY/destierro, condicional. R14/R15; C04/C05. | Oficial; foto local; combo lógico |
| CRYH-009 | Flor de Ceniza & Primavera Feliz | 3 | 0 | 0 | 0 | [12950](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12950&ope=2&request_locale=es) | Handtrap; impide un efecto que añada del Deck, invoque del Deck o mande del Deck al GY; proteger puntos críticos, no es extender Crystron. D09. | Oficial; foto local; utilidad autónoma |
| CRYH-010 | El Bufón y el Pájaro del Candado | 3 | 0 | 0 | 0 | [9279](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=9279&ope=2&request_locale=es) | Handtrap tras una adición del Deck a mano; bloquea nuevas adiciones ese turno, **también propias** si se resuelve. D10. | Oficial; foto local; conflicto identificado |
| CRYH-011 | Fuwalos Multivadora | 3 | 0 | 0 | 0 | [20500](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20500&ope=2&request_locale=es) | Handtrap de robo condicionada por especiales del adversario desde Deck/Extra; sus requisitos de campo/turno se comprueban antes de usar. D09. | Oficial; foto local; autonomía |
| CRYH-012 | Purulia Multivadora | 2 | 0 | 1 | 0 | [20206](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20206&ope=2&request_locale=es) | Handtrap para determinadas invocaciones del adversario desde mano; **2 Main + 1 Side** sin duplicar el total. D09/S03. | Oficial; foto local; Side condicionado |
| CRYH-013 | Inclusión Cristron | 3 | 0 | 0 | 0 | [20798](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20798&ope=2&request_locale=es) | Mágica Continua: al activarla busca otra carta Cristron, protege primera destrucción por batalla de cada Cristron; desde GY se destierra para revivir Cristron. R01/R04/R05; C02/C06/C07/V04. | Oficial; foto pendiente; combo lógico |
| CRYH-014 | Sarcófago del Rey | 2 | 0 | 0 | 0 | [19200](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19200&ope=2&request_locale=es) | Mágica Continua; envía carta de mano al GY para mandar un Horus del Deck al GY hasta 4 usos/turno, protege y habilita revivir Amset/Hapi. R14; C04/C05. | Oficial; foto local; combo lógico |
| CRYH-015 | Súper Polimerización | 3 | 0 | 0 | 0 | [7445](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=7445&ope=2&request_locale=es) | Rompecampos de Fusión usando materiales válidos de cualquier Campo; descartar 1 carta, oponente no responde a activación; **usar antes de bloqueo a Sincronías/Máquinas**. R17/R18; A08-I03. | Oficial; foto local; materiales condicionales |
| CRYH-016 | Gotas Prohibidas | 3 | 0 | 0 | 0 | [15299](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=15299&ope=2&request_locale=es) | Negación/mitad de ATK de monstruos de efecto rivales mediante envío de otras cartas de mano/Campo; coste/ratio y tipos enviados importan. D08. | Oficial; foto local; autonomía |
| CRYH-017 | Entierro Insensato | 1 | 0 | 0 | 0 | [5236](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=5236&ope=2&request_locale=es) | Envía monstruo del Deck al GY; habilita Thystvern/Tristaros de Cementerio o Amset/Hapi si ya hay Sarcófago. D04. | Oficial; foto pendiente; utilidad causal |
| CRYH-018 | Agrupamiento Cristron | 1 | 0 | 0 | 0 | [20817](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20817&ope=2&request_locale=es) | Trampa Continua: protege Cristron de destierro por efectos rivales; recicla Cristron de GY/destierro al Deck para destruir 1–2 cartas boca arriba seleccionadas. R21; D06. | Oficial; foto pendiente; trampa requiere turno legal |
| CRYH-019 | F.A. Coche Trucado del Amanecer | 0 | 2 | 0 | 0 | [13710](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13710&ope=2&request_locale=es) | Nivel 7 **Máquina Sincronía** (1 Cantante+1 no Cantante), niega M/T bajando 2 Niveles; potencial Citree2+Sulfador5. **Ficha oficial consultada señalaba «Prohibida»; alerta puntual, sin auditoría global de lista.** | Oficial; foto local; acceso lógico condicionado |
| CRYH-020 | Cristron Elesqueletus | 0 | 2 | 0 | 0 | [20778](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20778&ope=2&request_locale=es) | Nivel 7 **Máquina Sincronía**, recupera Cristron GY/destierro al sincronizar; destruido después de ser sincronizado revive Cristron. R09/R10; C02/C03. | Oficial; foto pendiente; combo lógico |
| CRYH-021 | Cristron Quariongandrax | 0 | 1 | 0 | 0 | [12781](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12781&ope=2&request_locale=es) | Nivel 9 **Máquina Sincronía**, **2+ Cantantes + exactamente 1 no Cantante**; al sincronizar destierra hasta número de materiales de monstruos rivales Campo/GY. R07/V01. | Oficial; foto pendiente; variante condicionada |
| CRYH-022 | S:P Pequeña Caballera | 0 | 1 | 0 | 0 | [19188](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19188&ope=2&request_locale=es) | Link-2 de 2 Efectos; uso táctico de destierro, pero **no** se puede invocar tras bloqueo Smiger/Sulfador durante ese turno. D03. | Oficial; foto local; solo acceso potencial previo |
| CRYH-023 | Caballero Mecánico | 0 | 1 | 0 | 0 | [20787](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20787&ope=2&request_locale=es) | **Link-1 Clockwork Knight**, Máquina no Link ATK original ≤1000; buscaría «Noche Mecánica» que **NO figura** en lista; puede tributar Máquina para revivir otra Máquina pequeña del GY. R20. | Oficial; foto local; no asumir búsqueda |
| CRYH-024 | Ciber Dragón del Infinito | 0 | 1 | 0 | 0 | [11765](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11765&ope=2&request_locale=es) | Rango 6 Máquina Xyz; se superpone sobre Nova, absorbe monstruo en Ataque y niega carta/efecto desacoplando. R19/C06; **bloqueado por Smiger de Campo**, permitido por bloqueo Máquina de Sulfador. | Oficial; foto local; ruta C06 |
| CRYH-025 | Ciber Dragón Nova | 0 | 1 | 0 | 0 | [10870](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=10870&ope=2&request_locale=es) | Rango 5 Máquina Xyz: **2 Máquinas de Nivel 5**, Sulfador y segunda copia de Azufafnir en C06; plataforma de Infinito. R19/C06; no hay «Ciber Dragón» en Main para revivir. | Oficial; foto local; ruta C06 |
| CRYH-026 | Hagoita de Alta-Velociroid | 0 | 1 | 0 | 0 | [12157](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12157&ope=2&request_locale=es) | Nivel 5 Máquina Sincronía; Citree2+Smiger3; efecto rápido se sacrifica y aumenta 1 Nivel de monstruos en Campo; **su auto-revivir exige Cantante Velociroid inexistente en Main**. R06; C01. | Oficial; foto pendiente; combo lógico |
| CRYH-027 | Número 90: Señor Fotónico de Ojos Galácticos | 0 | 1 | 0 | 0 | [13826](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13826&ope=2&request_locale=es) | Rango 8, 2 Nivel 8 Horus; niega efecto de monstruo desacoplando, pero con Horus como material **no lo destruye por no ser Galaxia/Galáctico**; sin Fotónico de material no obtiene inmunidad. R15; C04. | Oficial; foto pendiente; combo lógico |
| CRYH-028 | El Vampiro Zombi | 0 | 1 | 0 | 0 | [16850](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=16850&ope=2&request_locale=es) | Rango 8 Zombi Xyz, 2 Nivel 8; desacopla para mandar **4 cartas de cada Deck al GY** y si cae algún monstruo puede revivir uno de los enviados; incertidumbre del resultado. R16; C05. | Oficial; foto local; combo lógico |
| CRYH-029 | Destructor Samurái | 0 | 1 | 0 | 0 | [13360](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13360&ope=2&request_locale=es) | Nivel 7 Máquina Sincronía, opción de batalla tras Citree2+Sulfador5; no confundir control de batalla con negación general. D05. | Oficial; foto pendiente; acceso lógico |
| CRYH-030 | Garura, Alas de Vida Resonante | 0 | 1 | 0 | 0 | [17746](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=17746&ope=2&request_locale=es) | Fusión exige **2 monstruos de mismo Tipo/Atributo y distintos nombres**; objetivo posible Súper Polimerización sin bloqueo previo; al ir GY puede robar. R17; A08-I03. | Oficial; foto local; material rival condicionado |
| CRYH-031 | Fangodragón del Pantano | 0 | 1 | 0 | 0 | [13454](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13454&ope=2&request_locale=es) | Fusión exige **2 monstruos mismo Atributo y distinto Tipo**; opción Super Poly si rival aporta materiales; imposible tras bloqueo a Sincronías/Máquinas. R18; A08-I03. | Oficial; foto local; material rival condicionado |
| CRYH-032 | Cazadora del Caos | 0 | 0 | 2 | 0 | [9454](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=9454&ope=2&request_locale=es) | Side: puede invocarse desde mano ante especial del rival descartando carta; impide **al adversario** desterrar; usar solo tras entrada Side. S01. | Oficial; foto pendiente; condicional |
| CRYH-033 | Artefacto Lancea | 0 | 0 | 2 | 0 | [11243](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11243&ope=2&request_locale=es) | Side: tributar desde mano/Campo en turno rival; **ningún jugador** destierra ese turno; puede bloquear nuestros efectos de Smiger/Tristaros/Citree. S01. | Oficial; foto pendiente; conflicto |
| CRYH-034 | Regaño Solemne | 0 | 0 | 1 | 0 | [11411](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11411&ope=2&request_locale=es) | Side: contra trampa de negación fuerte, exige **ninguna otra carta Colocada** por ti y pago de LP; problema si quieres Colocar Agrupamiento/Juicio. S04. | Oficial; foto pendiente; conflicto |
| CRYH-035 | Llamado por la Tumba | 0 | 0 | 1 | 0 | [13619](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13619&ope=2&request_locale=es) | Side: destierra monstruo en GY rival y niega su nombre hasta el final del próximo turno; proteger starter ante Ash en contexto legal. S02. | Oficial; foto local; condicional |
| CRYH-036 | Talento de Tácticas Triples | 0 | 0 | 1 | 0 | [15296](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=15296&ope=2&request_locale=es) | Side: únicamente en Main Phase si rival activó efecto de monstruo **en tu Main Phase** ese turno; robo, control o mirar mano según condición. S02. | Oficial; foto local; condicional |
| CRYH-037 | Prohibida la Venta | 0 | 0 | 2 | 0 | [16868](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=16868&ope=2&request_locale=es) | Side: declara nombre; rival no activa ese nombre por el turno; **tú no podrás activarlo el resto del duelo**. S03. | Oficial; foto pendiente; riesgo largo plazo |
| CRYH-038 | Arresto Erróneo | 0 | 0 | 2 | 0 | [11849](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11849&ope=2&request_locale=es) | Side: impide **a ambos** añadir Deck→mano salvo robando hasta final de tu próximo turno; niega tus búsquedas Inclusión, Imsety, Thystvern, Smiger. S03. | Oficial; foto pendiente; conflicto fuerte |
| CRYH-039 | Juicio Solemne | 0 | 0 | 3 | 0 | [4861](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=4861&ope=2&request_locale=es) | Side: contratrampa pagar mitad LP para negar invocación o activación M/T; **no niega libremente todo efecto de monstruo**. S04. | Oficial; foto local; primer turno defensivo |

**Cotejo de cantidades:** Main 40 / Extra 15 / Side 15 / Reserva 0 = **70 copias en 39 identidades de este deck**. La identidad CRYH-012 tiene 2 Main + 1 Side; no sumar esa copia Side a la mano inicial ni inventar una cuarta.

### A06.0 — Cómo cooperan las cartas en 30 segundos

1. **Dictamen:** Cristron prepara materiales y Sincronías en turno rival; Horus convierte Cementerio en Nivel 8 para Xyz. Además, la destrucción de Azufafnir permite usar Máquinas Nivel 5 para Nova/Infinito. Son salidas alternativas, no una cadena automática única.
2. **Motor:** Smiger/Tristaros, Inclusión y Sulfador transforman destruir/enviar/recuperar en Citree, Elesqueletus y Quariongandrax.
3. **Puentes:** Sarcófago e Imsety dan recursos Horus y descartan cartas, lo que puede cargar el Cementerio Cristron; **no** les quitan sus restricciones.
4. **Sinergia indirecta:** Entierro Insensato puede enviar Thystvern o Tristaros para sus efectos de GY; Súper Polimerización puede usar monstruos del adversario con atributos/tipos compatibles.
5. **Conflicto decisivo:** tras Smiger/Thystvern (efecto Campo) **no** salen Xyz/Link/Fusiones ese turno; tras Sulfador (efecto propio) solo salen Máquinas.
6. **Decisión concreta:** si la mano permite un Rango 8, hacerlo **antes** del bloqueo Cristron; si interesa Súper Polimerización, resolverla antes de restringirse el Extra.
7. **Qué aprender:** C01/C03/V03 para turno rival, C02/V01 para secuencia Cristron, C04/C05 para Horus, C06 para Infinito y C07 como puente entre motores; revisar el material exacto y el estado de la cadena en cada paso.

### Motores y 21 relaciones causales (no confundir relaciones con combos)

| Relación | Cartas por ID | Causa → resultado | Condición y evidencia |
|---|---|---|---|
| R01 | 013→002/001/003 | Inclusión activada **BUSCA** otra carta Cristron del Deck | 1 activación de Inclusión/turno; oficial |
| R02 | 002→005 | Smiger **DESTRUYE** carta propia boca arriba y **INVOCA** Cantante Cristron del Deck | Smiger elige ese efecto, bloquea Extra a Sincronías Máquina; oficial/C01/C02 |
| R03 | 002→013/018 | Smiger desde GY **SE DESTIERRA Y BUSCA** M/T Cristron | No puede usar este y su efecto de Campo el mismo turno; oficial |
| R04 | 001+013→003/006 | Sulfador destruye Inclusión propia y se invoca, luego **ENVÍA** hasta 2 nombres Cristron del Deck al GY | Requiere Inclusión boca arriba y Sulfador en mano/GY; solo Máquinas Extra; oficial/C02 |
| R05 | 013→002/005/001 | Inclusión en GY se destierra para **REVIVIR** un Cristron en GY | Efecto propio una vez/turno; revive Smiger en C02; oficial |
| R06 | 005+002→026 | Citree **REVIVE** Smiger no Cantante y hace Sincronía Máquina Nivel 5 | Solo Main/Battle rival, materiales desterrados; oficial/C01 |
| R07 | 003+001→020 | Tristaros responde a activación rival, **TRAE** Sulfador y hace Sincronía Máquina Nivel 7 | Debe incluir recién invocado Sulfador; oficial/C03 |
| R08 | 003+020→003/004 | Tristaros del GY se destierra, destruye Sincronía propia y **TRAE** 2 Cristron del Deck | Sincronía existente, espacio en Campo y objetivos en Deck; oficial/V01 |
| R09 | 020→005 | Elesqueletus previamente sincronizado y destruido **REVIVE** 1 Cristron de GY/destierro | Destrucción por batalla/efecto; oficial/V01 |
| R10 | 020→013 | Elesqueletus al ser sincronizado **RECUPERA** 1 carta Cristron de GY/destierro | Recupera Inclusión desterrada en C02; no autoriza reactivarla el mismo turno; oficial |
| R11 | 006→001/003 | Thystvern en GY se destierra para **BUSCAR** otro monstruo Cristron | Exclusión de su propio nombre y solo 1 de sus dos efectos/turno; oficial |
| R12 | 004→001/003/005/004 | Azufafnir se invoca descartando Cristron y destruye carta propia; si él es destruido en Campo **TRAE** Cristron de Deck, incluso **otra copia de Azufafnir** si está disponible | Coste real, autodestrucción y segundo disparador en **C06/V03**; no confundir con extender gratis |
| R13 | 007+008→014 | Amset envía de mano él mismo y Hapi, **BUSCA** Sarcófago y opcionalmente roba | Dos cartas en mano; oficial/C04 |
| R14 | 014→007/008 | Sarcófago manda Horus del Deck a GY y **HABILITA** invocar Amset/Hapi del GY | Enviar otra carta de mano como coste; hasta 4 usos/turno del envío; oficial/C05 |
| R15 | 007+008→027 | Dos Horus Nivel 8 **SON MATERIALES** de Número 90 | No gana beneficios propios de material Fotónico/Galaxia; oficial/C04 |
| R16 | 007+008→028 | Dos Horus Nivel 8 **SON MATERIALES** de Vampiro Zombi | Muele 4 por jugador solo si se paga desacoplamiento; resultado aleatorio; oficial/C05 |
| R17 | 015→030 | Súper Polimerización usa 2 monstruos de igual Tipo/Atributo y distinto nombre para Garura | Material exacto en campo de uno/ambos jugadores; no después de bloqueos; oficial; **interacción**, no combo |
| R18 | 015→031 | Súper Polimerización usa 2 monstruos de mismo Atributo y distinto Tipo para Fangodragón | Material rival o propio compatible; no después de bloqueos; oficial; **interacción** |
| R19 | 013+001+004+002→025→024 | Inclusión **BUSCA** Smiger para descarte; Sulfador5 se conserva; Azufafnir descarta Smiger, se destruye y **TRAE segunda copia** Nivel5; ambos **HACEN** Nova, luego Infinito | C06 con **mano inicial y 2 copias de Azufafnir demostradas**, sigue documental/condicional; bloqueo «solo Máquina» sí permite Xyz Máquina, «solo Sincronía Máquina» de Smiger no |
| R20 | 005/003/002→023 | Máquina no Link ATK original ≤1000 puede **HACER** Caballero Mecánico; luego puede revivir una Máquina pequeña a coste de sacrificar otra | Acceso Link **antes** de bloqueos; «Noche Mecánica» ausente del Main, no adjudicar búsqueda; oficial |
| R21 | 018+020→carta rival | Agrupamiento **RECICLA** carta Cristron de GY/destierro al Deck y **DESTRUYE** 1 boca arriba o 2 con Sincronía Cristron propia | Requiere objetivo(s) boca arriba, recurso Cristron y Trampa legalmente activa; oficial |

**Mapa causal para enseñar:** `Inclusión → BUSCA Smiger → DESTRUYE Smiger → INVOCA Citree` (R01/R02); `Inclusión destruida → REVIVE Smiger` (R04/R05); `Citree + Sulfador → SINCRONIZA Elesqueletus → RECUPERA Inclusión` (R10); `Imsety + Hapi → BUSCA Sarcófago → REVIVE ambos → Xyz Número 90 / Vampiro Zombi` (R13–R16). Las cartas sin foto quedan como `[FOTO_PENDIENTE]` en estos nodos.

**Cartas sin ruta A09 propia:** las 11 herramientas Main/Side de respuesta y los monstruos de Extra meramente condicionales se conservan como **AUTÓNOMA_ÚTIL**, **ACCESO_POTENCIAL** o **DEPENDIENTE_DE_MATCHUP**, nunca `CERO_SINERGIA` por falta de una cadena. Los 21 enlaces anteriores no equivalen a 21 combos ni 21 victorias.

### A06.2 — Los 13 accesos del Extra de esta lista (sin añadir cartas)

| Extra | Acceso o uso concreto | Diagnóstico |
|---|---|---|
| F.A. Coche Trucado del Amanecer ×2 | Citree Nivel 2 + no Cantante Máquina Nivel 5 → Sincronía 7; negar M/T bajando dos Niveles | Verificar si se resolvió previamente un efecto Crystron que limita los tipos del Extra |
| Elesqueletus ×2 | Citree 2 + Sulfador 5, o Tristaros 2 + Sulfador 5 | **Ruta C02/C03**; recuperar y revivir según disparadores |
| Quariongandrax ×1 | Tristaros 2 + Citree 2 + Sulfador/Azufafnir 5 = 9; requiere 2 Cantantes + 1 no Cantante | **Variante V01** en turno rival; destierro al finalizar cadena |
| S:P Pequeña Caballera ×1 | 2 monstruos de Efecto, **antes** de bloqueos; revisar uso de material de Extra para efecto de invocación | Potencial; no tiene apertura completa en C01–C07 |
| Caballero Mecánico ×1 | 1 Máquina no Link ATK original ≤1000, p. ej. Tristaros/Citree/Smiger | Acceso aislado, sin búsqueda «Noche Mecánica» (no está incluida) |
| Ciber Dragón del Infinito ×1 | Superponer sobre Nova que controles | **C06 detallado**: Nova + 2 materiales heredados, Infinito con 3; **no** tras bloqueo Smiger |
| Ciber Dragón Nova ×1 | 2 Máquinas Nivel 5 simultáneas: Sulfador/Azufafnir | **C06 detallado** con segunda copia Azufafnir del Deck y Sulfador en Campo; R19 |
| Hagoita de Alta-Velociroid ×1 | Citree 2 + Smiger 3 en turno rival | **C01**; resurrección propia no disponible sin Cantante Velociroid |
| Número 90 ×1 | Amset 8 + Hapi 8 desde GY con Sarcófago | **C04**; niega pero no destruye por desprender Horus |
| El Vampiro Zombi ×1 | Amset 8 + Hapi 8 | **C05**; 8 cartas combinadas enviadas de ambos Decks, monstruo revivido solo si cae |
| Destructor Samurái ×1 | Citree 2 + Sulfador 5 como alternativa de Elesqueletus | **V04**: ruta condicional de combate; pierde recuperación de Inclusión |
| Garura ×1 | Súper Polimerización + 2 materiales de igual Tipo/Atributo y distinto nombre | **Condicional** a Campo/matchup; Fusión prohibida tras bloqueos mencionados |
| Fangodragón del Pantano ×1 | Súper Polimerización + 2 monstruos mismo Atributo y distinto Tipo | **Condicional** al Campo; no prometer materiales rivales |

**Cobertura A06:** 39/39 identidades clasificadas; 21 relaciones de alcance explícito, no todas cerradas como secuencia. 13/13 Extra evaluadas por requisitos; **8 identidades tienen acceso trazado en C01–C07/V01–V04** (Hagoita, Elesqueletus, Quariongandrax, Número 90, Vampiro Zombi, Nova, Infinito y Destructor Samurái). Las demás conservan acceso **potencial, dependiente de rival o condicionado al formato**. No hay dictamen `COMPLETA` ni acreditación de simulador.

## APARTADO_07 — Reglas, cadenas y materiales: 15 controles

| Regla | Dictamen comprobado con textos oficiales | Impacto práctico / casos |
|---|---|---|
| RGL01 | **Smiger** en Campo destruye boca arriba propia y, si lo logra, trae Cantante; por el resto de **ese turno** solo puede invocarse desde Extra **Sincronías Máquina**. | C01/C02; impide Nova, Infinity, Link, Garura, Fangodragón después del efecto. |
| RGL02 | **Thystvern** tiene idéntico bloqueo Extra en su efecto de Campo. | No usarlo antes de Xyz Horus o Súper Polimerización del mismo turno. |
| RGL03 | Smiger y Thystvern permiten usar **solo uno de sus dos efectos por turno**; no activar el de Campo y luego desterrar por búsqueda ese turno. | Evita buscar Inclusión después de haber invocado Citree con el mismo Smiger. |
| RGL04 | **Sulfador** desde mano/GY destruye Cristron propio para invocarse; el resto del turno solo Máquinas desde Extra; su envío de hasta dos nombres distintos del Deck es otro efecto una vez/turno. | C02; la restricción permite Xyz Máquina, pero no Número 90 ni Vampiro Zombi. |
| RGL05 | **Tristaros** es Cantante 2; su Efecto Rápido solo al activarse una carta/efecto del rival: trae Cristron y **de inmediato** sincroniza Máquina **incluyendo al recién traído**. | C03/V01; no elegir arbitrariamente otro material ni sincronizar fuera de niveles. |
| RGL06 | **Tristaros** desde GY se destierra, destruye una Sincronía propia y si logra destruirla trae 2 Cristron del Deck; bloquea luego a Máquinas del Extra. | V01; requiere Sincronía controlada y al menos 2 objetivos invocables. |
| RGL07 | **Citree** solo en Main/Battle del rival; revive exactamente 1 no Cantante del GY (efectos negados) y sincroniza usando solo ella + ese monstruo. Ambos materiales quedan **desterrados**. | C01; Citree no puede hacer esta Sincronía por su efecto en tu propio Main Phase. |
| RGL08 | **Elesqueletus** necesita Cantante + no Cantante sumando Nivel 7; recuperación al sincronizar y resurrección al destruirse **tras ser Invocada por Sincronía**. | C02/C03/V01; revivir no equivale a invocar desde Extra. |
| RGL09 | **Quariongandrax** exige Nivel 9 con **2 o más Cantantes + 1 no Cantante**; destierra monstruos rivales Campo/GY hasta número de materiales usados. | V01; Cantante2+Cantante2+NoCantante5 = 9. No puede desterrar cartas mágicas. |
| RGL10 | **Imsety** envía dos cartas de mano incluyéndose para buscar Sarcófago, luego puede robar; Horus reviven desde GY solo si controlas Sarcófago. | C04/C05; no tratar Sarcófago como invocación desde Deck. |
| RGL11 | **Nova** usa **dos Máquinas Nivel 5**; **Infinito** puede Xyz sobre Nova; **Número 90** usa dos Nivel 8, pero Horus no satisface beneficios de materiales Fotónicos/Galaxia. | R19/C04; ningún Xyz después del bloqueo Smiger de ese turno. |
| RGL12 | **Caballero Mecánico = Link-1** requiere 1 Máquina no Link de ATK original ≤1000; su búsqueda es de «Noche Mecánica», **ausente** del inventario. | Solo acceso potencial antes de bloqueos; no se puede buscar una carta inexistente. |
| RGL13 | **Súper Polimerización** descarta y fusiona usando monstruos de uno o ambos Campos, pero **Garura/Mudragon** necesitan materiales exactamente compatibles. | No fusionar por asumir que todos los monstruos rivales sirven; R17/R18. |
| RGL14 | **Agrupamiento, Regaño y Juicio** son Trampas; salvo efecto que permita lo contrario, no se activan en el turno en que se Colocan. Regaño requiere no tener otras cartas Colocadas. | Side S04/S05; no Colocar Regaño junto a otros backrows y anunciar que está listo. |
| RGL15 | Si **Tristaros** sincroniza durante una cadena rival, los efectos de «si es Invocado por Sincronía» que tengan condición válida se activan **en una cadena posterior a que la cadena actual termine**. | En V01, Quariongandrax no destierra en mitad de la resolución de la activación rival; puede perderse la ventana/objetivo si el estado cambia. |

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

**Pruebas todavía pendientes:** interacciones finas con negación en la misma cadena, sustitución de destierro bajo Lancea, efectos de monstruo que cambian de zona mientras se resuelve la cadena y cualquier ruling no explícito en el texto. No marcar `VALIDADO_SIMULADOR`.

### A07.1 — Ocho interrupciones reales: qué pierde cada ruta y qué queda

| Escenario | Corte exacto | Recursos que sí se gastan / resultado que falla | Continuación honesta |
|---|---|---|---|
| **INT01 — Ash contra Amset** | Amset activa en mano y envía 2 cartas, rival encadena Ash a la búsqueda de Sarcófago | **Amset y segunda carta ya están en GY**; no se añade Sarcófago ni se roba por ese efecto negado | Si no controlabas otro Sarcófago, **C04 y C07 se detienen** en el punto previsto; no revivir Horus ficticios |
| **INT02 — Ash contra Inclusión** | Inclusión se activa y su búsqueda del Deck es negada | **Inclusión queda boca arriba** si solo se negó el efecto y no su activación; **Smiger no llegó a mano** | C02/C06 requieren Smiger para su continuación exacta: **no siguen igual**; Sulfador puede usar esa Inclusión como carta a destruir si todavía la controlas |
| **INT03 — Ash al envío de Sulfador** | Sulfador ya fue Invocado, activa su efecto separado de enviar hasta 2 Cristron del Deck, rival responde Ash | **Sulfador permanece en Campo** si no hay otra remoción; los 2 nombres **no llegaron al GY** por ese envío negado | El Nivel 5 puede seguir siendo material de C02/C06, pero **V01** pierde los recursos Tristaros/Thystvern si ese era su único envío |
| **INT04 — Droll después de Amset** | Amset resolvió su búsqueda; el rival aplica Droll antes de que Smiger busque Inclusión | Sarcófago **sí** llegó a mano, pero el **siguiente** añadir Deck→mano queda prohibido ese turno | C07 puede dejar Sarcófago + Amset, **no** se adjudica Inclusión ni Tristaros; reservar Smiger GY para turno posterior si sigue disponible |
| **INT05 — Droll después de Inclusión** | Inclusión ya añadió Smiger; Droll aplica antes del siguiente buscador | Smiger **sí** se conserva en mano; **nuevas** adiciones desde Deck quedan prohibidas | La línea Citree/Smiger puede continuar; **Elesqueletus recuperando de GY/destierro a mano** no es añadir desde Deck y no se prohíbe por esa razón |
| **INT06 — Bloqueo del Extra mal ordenado** | Se usa el efecto de **Campo** de Smiger antes de empezar Nova/Infinito | Por resto de turno solo **Sincronías Máquina** del Extra; Nova e Infinito son Xyz, aunque Máquina | **C06 BLOQUEADO ese turno**. Sulfador por sí mismo permite Máquina Xyz; elegir primero qué línea se está construyendo |
| **INT07 — Riesgo Nibiru en C06** | Al completar Sulfador (1), Azufafnir propio (2), segundo Azufafnir (3), Nova (4), Infinito (5), el rival puede tener ventana legal para Nibiru | La quinta Invocación ya hace relevante la condición habitual de Nibiru; **no** declarar inmunidad absoluta | Si Infinito ya está Invocado, con material y efecto rápido disponible puede **responder negando su activación**, si se cumplen las condiciones de cadena; pendiente contraste en partida |
| **INT08 — Sarcófago retirado** | Oponente elimina Sarcófago **antes** de revivir Amset/Hapi desde GY | Sin Sarcófago controlado, no se habilita esa Invocación Horus por sus procedimientos | Regresar a Cristron/handtraps disponibles; **si Horus ya fue Invocado, quitar Sarcófago no lo devuelve automáticamente al GY** |

**Nota de costes:** negar **un efecto** no devuelve cartas ya enviadas de mano como coste; negar **la activación** y negar **el efecto** no son sinónimos. En efectos con destrucción que ocurre **al resolver**, no registrar esa destrucción cuando toda la resolución fue negada. Cada caso supone únicamente la respuesta indicada, sin inventar cadenas adicionales del rival.

## APARTADO_08 — Estrategia, selección de jugadas y Side

### 20 decisiones situacionales D01–D20

| Decisión | Situación inicial → qué hacer y por qué | Evitar |
|---|---|---|
| D01 | **Solo Smiger** y vamos primero: Normal Smiger → destruirse → Citree; reservar Citree para sincronizar con Smiger del GY en turno rival (C01). | Gastar Smiger GY para buscar inmediatamente: ese turno ya usó su otro efecto. |
| D02 | **Inclusión + Sulfador** primero: buscar Smiger y aprovechar que Sulfador destruye la Inclusión para usar su efecto de GY (C02). | Mandar inclusiones a GY sin una carta Cristron válida que revivir. |
| D03 | **Necesito S:P, Clockwork Knight, Fusión o Xyz no Máquina**: resolver esas invocaciones antes de activar Smiger/Thystvern de Campo o Sulfador. | Asumir que un bloqueo solo obliga a usar Máquinas cuando Smiger exige **Sincronía Máquina**. |
| D04 | **Entierro Insensato** con starter y sin GY: elegir Thystvern para buscar monstruo, Tristaros si ya hay Sincronía propia por destruir, o Horus con Sarcófago presente. | Enviar a GY monstruo sin efecto útil disponible todavía. |
| D05 | **Citree + Nivel 5 no Cantante en GY rival Main/Battle:** elegir Elesqueletus para recuperar, o Samurái/F.A. para utilidad situacional y condición legal de formato. | Decir que Citree usa más de 2 materiales o ignorar el destierro. |
| D06 | **Agrupamiento Colocado turno anterior:** si hay Cristron GY/destierro y objetivo boca arriba, reciclar para destruir; si hay Sincronía Cristron, comprobar opción de 2 objetivos. | Destruir boca abajo con este efecto que pide cartas boca arriba. |
| D07 | **Amset + Hapi/Sarcófago** primero: seleccionar N.º 90 para negación de monstruo o Vampiro Zombi para molinos/extendidos aleatorios (C04/C05). | Querer convocar a la vez ambos Xyz usando los mismos dos Horus. |
| D08 | **Segundo con monstruos rivales de efecto:** Gotas Prohibidas antes de intentar una línea expuesta; calcular exactamente cartas enviadas y objetivos. | Suponer que una sola Gotas niega cualquier cantidad de monstruos sin coste. |
| D09 | **Oponente añade/invoca del Deck o mano:** elegir Ash/Droll/Fuwalos/Purulia por texto y ventana, conservando roles autónomos. | Activar Droll antes de producirse la primera adición o Fuwalos sin cumplir su requisito. |
| D10 | **Droll o Arresto Erróneo ya resolvieron:** cambiar a efectos que invocan desde GY/Deck o remueven; Inclusión/Imsety **no pueden añadir** del Deck a mano bajo restricción. | Continuar un paso de búsqueda fallido como si la carta hubiese llegado a mano. |
| D11 | **C02 ha llegado a Elesqueletus y Tristaros está en GY:** evaluar si convertirlo en 2 Cristron + revivir Citree para preparar Quarion V01, o conservar Eles + Smiger. | Destruir tu única Sincronía sin suficientes objetivos y espacio. |
| D12 | **Rival usa destierro:** Side S01 con Cazadora del Caos o Lancea según turno; Lancea te impide desterrar también, así que ajustar plan Cristron. | Afirmar que Lancea solo perjudica al oponente. |
| D13 | **Rival cierra búsquedas:** conservar cartas ya en Campo/GY, usar Sarcófago para enviar monstruos, no inflar recursos inexistentes. | Contar una búsqueda como resultado cuando fue negada. |
| D14 | **Rival posee 2 materiales para Garura/Fangodragón:** usar Súper Polimerización **antes de restringir** el Extra y elegir la Fusión cuyo requisito coincide. | Inventar que cualquier par de monstruos fusiona o que Super Poly equivale a combo completo. |
| D15 | **Tengo Inclusión + Sulfador + Azufafnir** y segundo Azufafnir todavía en Deck: ejecutar **C06 → Nova → Infinito** si se necesita negar activación de cualquier tipo. | Usar Smiger desde Campo antes de los Xyz. El Smiger de C06 es **buscado para ser descartado**, no invocado. |
| D16 | **Tengo Amset + Smiger:** enviar ambos a GY por Amset, revivir Amset con Sarcófago, buscar Inclusión con Smiger desterrado y traer Tristaros con la búsqueda de Inclusión (**C07**). | Tratar «Smiger descartado» como Smiger que ya usó su efecto de Campo; no son lo mismo. |
| D17 | **Tengo Azufafnir + Smiger, sin Normal adicional que invertir:** la variante **V03** prepara Tristaros + Agrupamiento colocado. | Intentar activar Agrupamiento en el mismo turno en que se colocó; destruir también a Tristaros por error al resolver Azufafnir. |
| D18 | **C02 va segundo y el oponente tiene un monstruo de efecto difícil de combatir:** elegir **V04/Destructor Samurái** en lugar de Elesqueletus si el combate es la prioridad. | Contar Inclusión en mano: sin Elesqueletus, quedó desterrada. |
| D19 | **Comparo final de turno:** C02 ofrece Elesqueletus + Smiger y recuperación; C06 ofrece Infinito con negación; C07 ofrece Horus 8 + Tristaros y dos Continuas. Elegir **un objetivo** según mano real, sin sumarlos. | Afirmar que C02 y C06 se hacen juntos con las mismas copias/zonas o que Nova sigue legal tras Smiger. |
| D20 | **Tengo dos Horus en mesa y necesito seguir jugando Cristron:** hacer Número90/Vampiro antes de activar Smiger Campo; reservar Normal o un buscador Cristron para la siguiente decisión. | Gastar los dos Horus en Xyz y seguir contándolos como Nivel 8 libres para otra Xyz. |

### A08.1 — Árbol breve de selección de apertura por objetivo, no por popularidad

| ¿Qué cartas tengo realmente? | ¿Qué necesito conseguir? | Ruta preferente | ¿Qué sacrifico? |
|---|---|---|---|
| Inclusión + Sulfador + Azufafnir | **Negar una activación** con un monstruo ya preparado en mi turno | **C06 → Infinito** | Tres piezas de mano y segunda copia Azufafnir del Deck; no hago la línea de Smiger Campo |
| Inclusión + Sulfador | **Recuperar mano y preparar continuación** | **C02 → Elesqueletus**, opcional V01 | Restringe Extra a Sincronías Máquina; no tiene negación genérica inmediata |
| Amset + Smiger | **Usar ambos motores sin romper el Extra** | **C07 → Amset + Tristaros**, luego Elesqueletus | Dos búsquedas vulnerables a Droll y activación rival necesaria |
| Amset + Hapi | **Negar efecto de monstruo** | **C04 → Número 90** | Los Horus pasan a ser materiales Xyz; la negación con Horus no destruye |
| Sarcófago + Amset, Hapi aún en Deck | **Ganar recursos de GY con molino** | **C05 → Vampiro Zombi** | Resultado de ocho cartas enviadas es variable; no produce negación automática |
| Solo Smiger o Inclusión | **No perder turno y preparar respuesta** | **C01 o V02 → Citree**, luego Hagoita | Queda expuesta Citree en Campo; Hagoita solo existe si se resuelve turno rival |
| Azufafnir + Smiger | **Preparar retirada con Trampa** | **V03 → Tristaros + Agrupamiento** | Dos cartas de mano; Trampa espera turno rival |

**Lectura competitiva honesta:** el mazo puede inclinarse hacia **control reactivo**, **negación inmediata** o **presión Horus**, pero la mejor ruta depende de cartas ya robadas, objetivos vivos y restricciones; ninguna de estas tablas representa porcentajes de victoria o clasificación de metajuego acreditada.

### Side Deck: 6 planes concretos, uno a la vez entre duelos

**Base:** Side original 15 copias: Cazadora x2, Lancea x2, Regaño x1, Llamado x1, Talento x1, Prohibida la Venta x2, Arresto Erróneo x2, Juicio x3 y Purulia x1. **Nunca** está disponible en duelo 1 sin intercambio. Cada plan conserva Main **40** y Side **15** tras intercambiar; los planes son independientes, no entradas acumulativas.

| Plan | Contexto | Entran desde Side → Main | Salen Main → Side | Riesgo/condición |
|---|---|---|---|---|
| S01 | Contra destierro fuerte | +2 Cazadora del Caos, +2 Lancea (**4**) | −2 Purulia, −2 Fuwalos (**4**) | Lancea bloquea también tus destierros Cristron; Cazadora requiere descarte y condición de invocación rival. |
| S02 | Contra handtraps/efectos rivales en tu turno | +1 Llamado por la Tumba, +1 Talento de Tácticas Triples (**2**) | −2 Purulia (**2**) | Talento exige efecto de monstruo rival durante tu Main Phase; Llamado necesita objetivo GY. |
| S03 | Contra búsqueda excesiva rival tras establecer tu propio motor | +2 Arresto Erróneo, +2 Prohibida la Venta (**4**) | −2 Droll, −2 Purulia (**4**) | Arresto bloquea **tus** búsquedas; Venta te restringe el nombre declarado **el resto del duelo**. |
| S04 | Ir primero con control de activaciones/invocaciones | +3 Juicio Solemne (**3**) | −3 Súper Polimerización (**3**) | Juicio paga mitad LP y no niega cualquier efecto monstruo; debe estar Colocado en turno legal. |
| S05 | Solo Regaño cuando quieres dejar **una** Trampa Colocada | +1 Regaño Solemne (**1**) | −1 Súper Polimerización (**1**) | Evitar otras cartas Colocadas; no mezclar como «plan listo» con S04 o Agrupamiento Colocado. |
| S06 | Rival invoca reiteradamente desde mano | +1 Purulia (**1**: quedaría 3 Main) | −1 Droll (**1**) | La tercera Purulia proviene del Side, no se agrega mágicamente; vigilar requisitos actuales. |

**No se recomienda cambiar cartas permanentemente** aquí: estos son mapas de Side, no sustituciones aprobadas del deck maestro. La Reserva sigue 0.

### A08.2 — Tres errores al usar el Side y corrección

1. **Contra destierro con Lancea:** si eliges S01, **Lancea detiene también tus destierros durante ese turno**; puede bloquear la búsqueda de Smiger desde GY, revivir con Inclusión desterrándose y la gestión de materiales de Citree. Usarla con un plan que no dependa de desterrar, por ejemplo proteger Horus ya establecido.
2. **Contra búsquedas con Arresto Erróneo:** S03 es simétrico; **primero** asegura tu Inclusión/Amset/Sarcófago y **luego**, en ventana legal, considera detener búsquedas de ambos. No colocarla como si solo afectara al rival.
3. **Contra un rival lento, agregando Juicio y Regaño:** S04 y S05 son **alternativas**, no «meto las cuatro y las activo a la vez». Regaño requiere que no controles otras cartas Colocadas; Juicio y Agrupamiento compiten por las mismas condiciones de colocación y timing.

## APARTADO_09 — Siete combos, cuatro variantes y doce manos de prueba

**Estado real tras segunda iteración:** **7 rutas principales construidas documentalmente (C01–C07), 4 variantes (V01–V04), 12 manos de estudio (H01–H12), 0 ejecuciones acreditadas en simulador**. «Construida» quiere decir que se describieron materiales, zonas, disparadores y restricciones a partir de textos oficiales; **NO** equivale a `VALIDADO_SIMULADOR`. No contar los 21 enlaces R01–R21 como combos. Las manos son supuestos de ensayo, no resultados de robo aleatorio. Todos los monstruos y mágicas citados figuran en el inventario real A03. C06 y C07 son familias **nuevas por objetivo final**, mientras V03/V04 son sustituciones que comparten una familia anterior.

### C01 — Smiger solo: preparar Hagoita en el turno rival

- **Objetivo:** convertir una sola Normal en una Sincronía Máquina Nivel 5 con uso defensivo, conservando las demás cartas de la mano. **Dificultad:** básica; **starter:** Smiger ×1; **recurso:** Normal Summon; **turno:** propio para preparar, adversario para sincronizar.
- **Estado inicial exacto:** nuestro Campo y Cementerio vacíos; Smiger en mano, Citree en Deck, Hagoita en Extra; sin restricciones previas ni efectos rivales.
1. En tu Main Phase, **Invoca de Modo Normal Smiger** (Nivel 3, no Cantante).
2. Activa **el efecto de Smiger en Campo**, seleccionándolo **a él mismo** como carta boca arriba propia. Al resolver, **destruye a Smiger** (queda en GY) e **Invoca de Modo Especial Citree** (Cantante Nivel 2) desde Deck. **Restricción:** por el resto de tu turno solo Sincronías Máquina desde Extra. **No** puedes desterrar ahora ese Smiger para buscar una M/T, porque Smiger permite solo **uno** de sus efectos por turno.
3. Termina tu turno con **Citree en Campo**, Smiger en GY y Hagoita todavía en Extra. No declares Hagoita ya Invocada: **Citree espera turno adversario**.
4. Durante Main Phase o Battle Phase del rival, activa **Efecto Rápido de Citree**, seleccionando **Smiger no Cantante de tu GY**. Si se resuelve, Invoca a Smiger con efectos negados y, **inmediatamente**, realiza Sincronía usando **solo Citree (2) + Smiger (3)** → **Hagoita de Alta-Velociroid (Nivel 5, Máquina)**.
- **Campo final verificable bajo esos supuestos:** Hagoita ×1; Citree y Smiger **desterrados** como materiales por el efecto de Citree; otros recursos de mano desconocidos y no contados. Hagoita **no es una negación universal**: su Efecto Rápido tributa a sí misma para aumentar Nivel en Campo; su autorresurrección requiere un Cantante «Velociroid» ausente de esta lista.
- **Puntos de fallo/ramas:** si el rival niega Smiger antes de resolver, no aparece Citree; si destierra Smiger del GY antes de Citree, falta objetivo; si evita la Sincronía al resolver Citree, no afirmar tablero final. **R01/R02/R06; RGL01/03/07.**

### C02 — Inclusión + Sulfador: Elesqueletus y recuperación

- **Objetivo:** una Sincronía de Nivel 7 con recuperación concreta de Inclusión y Smiger en Campo. **Dificultad:** media; **starter mínimo:** Inclusión Cristron ×1 + Sulfador ×1 en mano; **Normal disponible**. **No** requiere cartas imaginarias en el Extra.
- **Estado inicial:** Campo/GY vacíos; en Deck hay Smiger, Citree, Tristaros y Thystvern; Extra contiene Elesqueletus; no rival interviene.
1. **Activa Inclusión Cristron** (Mágica Continua). En su activación **busca Smiger** de Deck a mano. La carta permanece boca arriba en Campo.
2. **Normal Summon Smiger (3)**. Activa su efecto apuntando **a sí mismo**; destrúyelo → GY; **Invoca Citree (2)** del Deck. Queda activo bloqueo de Extra **solo Sincronía Máquina** por resto del turno.
3. Activa el efecto propio de **Sulfador desde mano**, seleccionando la **Inclusión Cristron** boca arriba que controlas. Destruye Inclusión → GY e **Invoca Sulfador (5)**; su efecto de invocación manda desde Deck **Tristaros (2)** y **Thystvern (3)** al GY (nombres distintos). Sulfador establece bloqueo a **Máquinas** desde Extra: **sigue prevaleciendo** el de Smiger, más restrictivo.
4. **Destierra Inclusión del GY** para activar su efecto y seleccionar el **Smiger** de tu GY; **Invoca Smiger (3)**. Inclusión queda desterrada temporalmente.
5. **Sincroniza Citree Cantante (2) + Sulfador no Cantante (5)** → **Elesqueletus (7, Máquina Sincronía)**. Citree/Sulfador van al GY como materiales de una Sincronía regular de tu turno; **no** se aplica aquí el destierro del efecto de Citree, porque no lo usamos.
6. Al ser Invocada por Sincronía, **Elesqueletus recupera una carta Cristron** de tu GY/destierro: selecciona **Inclusión desterrada** y añádela a mano. **No** intentes activarla de nuevo en este turno; Inclusión solo permite una activación por turno.
- **Campo final con la ruta sin interrupciones:** Elesqueletus ×1 + Smiger ×1; mano incluye Inclusión recuperada; GY contiene Citree, Sulfador, Tristaros y Thystvern; Inclusión ya **no** está desterrada; Normal agotada. Este es un tablero de recursos, **no** una negación universal ni OTK garantizado.
- **Variantes/fallos:** si Ash niega la búsqueda de Inclusión, no aparece el Smiger asumido; si Sulfador no puede destruir la Inclusión, no se habilita su invocación; si Tristaros o Thystvern ya no están en Deck, ajusta objetivos en vez de afirmar envío exacto. **R01/R02/R04/R05/R08/R10/R11; RGL01/04/08.**

### C03 — Tristaros solo: Sincronía reactiva a una activación rival

- **Objetivo:** poner Elesqueletus mediante la cadena del oponente sin gastar un segundo starter de mano. **Dificultad:** media por ventanas; **starter:** Tristaros ×1.
- **Estado inicial:** tu Campo/GY vacíos, Tristaros en mano, Sulfador en Deck, Elesqueletus disponible en Extra; sin efecto de bloqueo previo.
1. En tu turno **Normal Summon Tristaros** (Nivel 2, Cantante). Concluye turno; Tristaros debe **sobrevivir** en Campo.
2. En el turno rival, **cuando el oponente activa una carta o efecto**, responde en la cadena con el **Efecto Rápido de Tristaros**.
3. Si resuelve, **Invoca Sulfador (Nivel 5) desde Deck** e **inmediatamente Sincroniza Tristaros (2) + Sulfador (5)** → **Elesqueletus (7)**. La Sincronía incluye al monstruo traído por Tristaros, como exige su texto. El efecto rival inicial todavía se resuelve en su orden de cadena; **no** lo declares negado por Elesqueletus.
4. **Tras resolverse íntegramente esa cadena**, si Elesqueletus permanece y su efecto puede activarse, abre la cadena correspondiente para recuperar una carta Cristron del GY/destierro (por ejemplo, Tristaros que acaba de ser material), de acuerdo con los disparadores legales.
- **Final condicional:** Elesqueletus en Campo; Tristaros y Sulfador pasaron al GY como materiales normales, salvo otro efecto; una carta Cristron elegible puede regresar a mano tras la cadena posterior. **No se cuenta automáticamente** el envío de dos Cristron de Sulfador en el mismo eslabón: requiere revisar la activación real y la ventana del efecto.
- **Fallo:** sin activación rival no hay Efecto Rápido de Tristaros; si se retira antes de responder, la ruta desaparece; si el oponente controla una interrupción, la cadena cambia. **R07/R10; RGL05/08/15.**

### C04 — Amset + Hapi: acceso real a Número 90

- **Objetivo:** obtener **negación de efecto de monstruo** de Rango 8. **Dificultad:** básica-media; **starter:** Amset + Hapi en mano; **requisito:** Sarcófago todavía en Deck; sin bloqueo previo del Extra.
- **Estado inicial:** Campo/GY vacíos, Amset y Hapi en mano, Sarcófago en Deck y Número 90 en Extra.
1. Activa el efecto de **Amset en mano** y envía **Amset + Hapi** de la mano al GY como coste. Busca **Sarcófago del Rey** de Deck a mano; si el texto lo permite y lo decides, **roba 1** (carta desconocida: no inferir su nombre).
2. **Activa Sarcófago del Rey** como Mágica Continua boca arriba.
3. Con Sarcófago boca arriba, **Invoca de Modo Especial Amset desde tu GY** usando su capacidad de retorno; después **Hapi desde GY** mediante su propio efecto, respetando límites de uso.
4. Superpón los dos monstruos **Nivel 8** → **Número 90: Señor Fotónico de Ojos Galácticos (Rango 8)**, con **Amset y Hapi como exactamente dos materiales Xyz**.
- **Final:** Número 90 en Campo con dos materiales Horus; Sarcófago boca arriba; ninguna de estas piezas sigue en GY hasta que se desacople una. En ventana legal, Número 90 puede **desacoplar un material para negar efecto de monstruo**; **no destruye al monstruo negado** si el desacoplado es Amset/Hapi, porque no es material «Galaxia/Galáctico». Tampoco adjudicar inmunidad por material «Fotónico» inexistente.
- **Fallo:** Ash/Droll contra búsqueda, remoción de Sarcófago antes de las invocaciones o bloqueo previo Smiger/Sulfador. **R13/R14/R15; RGL10/11.**

### C05 — Sarcófago + Amset: Vampiro Zombi y molino incierto

- **Objetivo:** extender o llenar Cementerio mediante Xyz de Rango 8, **sin inventar lo que se muele**. **Dificultad:** media; **starter:** Sarcófago + Amset en mano; **requisito crítico:** Hapi permanece en Deck.
- **Estado inicial:** Campo/GY vacíos; Sarcófago y Amset en mano; Hapi en Deck; Vampiro Zombi en Extra; sin restricciones previas.
1. **Activa Sarcófago del Rey**. Activa su efecto: envía **Amset de mano al GY** para mandar **Hapi del Deck al GY** (dos movimientos de zonas diferentes). El envío de la mano y del Deck deben distinguirse.
2. Mientras controles Sarcófago, **Invoca Amset desde GY**; luego **Invoca Hapi desde GY**. Son dos Horus Nivel 8 diferentes.
3. Superpón Amset (8) + Hapi (8) → **El Vampiro Zombi, Rango 8** con dos materiales, mientras Sarcófago sigue en tu Campo.
4. Si decides activar su efecto, **desacopla un material Xyz** y manda al GY **las 4 cartas superiores de cada Deck** (4 propias + 4 rivales). **Solo si hay un monstruo entre esas cartas enviadas**, puedes Invocar de Modo Especial uno apropiado de esos monstruos, sujeto a condiciones/restricciones. No se presupone cuál cayó, ni que es Cristron, ni que necesariamente obtuviste otra invocación.
- **Final garantizado antes del molino:** Vampiro Zombi con 2 materiales y Sarcófago en Campo. **Después:** un material en GY; cartas molidas desconocidas; posible monstruo adicional **no garantizado**. El Vampiro es Zombi, **no Máquina**: resulta incompatible si ya activaste bloqueo de Sulfador y, con mayor razón, el de Smiger.
- **Fallo:** si Hapi fue robado y no está en Deck, no se manda con ese efecto; si no cae monstruo en molienda, no hay objetivo para invocación. **R14/R16; RGL10/11.**

### C06 — Inclusión + Sulfador + Azufafnir → Nova → Infinito

- **Objetivo propio:** producir **una negación de activación de carta/efecto mediante Ciber Dragón del Infinito**, no simplemente otro Sincronía. **Dificultad:** media-alta por administración del bloqueo. **Starter mínimo:** Inclusión + Sulfador + Azufafnir **en mano**; Campo/GY vacíos; Smiger y un **segundo Azufafnir** siguen en Deck; Nova + Infinito disponibles en Extra; no hay negación del adversario. **No requiere Normal Summon.**
1. **Activa Inclusión Cristron**; al activarse, **busca Smiger** del Deck y llévalo a tu mano. Ahora tienes Sulfador, Azufafnir y Smiger; Inclusión boca arriba.
2. Activa **Sulfador desde mano**, seleccionando tu Inclusión boca arriba; **destruye Inclusión** y, si lo logras, **Invoca Sulfador Nivel 5**. Por el resto del turno, desde Extra **solo Máquinas**; esto **sí** permite Xyz Máquina. Como efecto distinto al ser Invocado, Sulfador puede enviar hasta dos cartas Cristron de nombres diferentes desde Deck a GY; si eliges Tristaros/Thystvern, anota esos envíos en tu estado. No son requisitos de Nova.
3. Activa **Azufafnir/Sulfefnir desde mano**, **descartando Smiger** (una carta «Cristron» distinta de sí mismo). **Invoca Azufafnir en DEF**, y su efecto obliga a destruir una carta que controlas: **elige a ese mismo Azufafnir**. Va al GY. Esta elección **conserva Sulfador Nivel 5 en Campo**.
4. Como Azufafnir fue destruido en el Campo por efecto, activa **su segundo efecto** en una cadena posterior y **Invoca el segundo Azufafnir del Deck en DEF**. Sus dos efectos son una vez por turno **cada uno**; el segundo Azufafnir no usa sus propios efectos aquí. En Campo ahora están exactamente **Sulfador Nivel 5 + segundo Azufafnir Nivel 5**.
5. **Superpone los dos Máquinas Nivel 5** → **Ciber Dragón Nova**, con Sulfador + segundo Azufafnir acoplados como **2 materiales Xyz**. **No** actives un efecto de Smiger en Campo: bloquearía este Xyz.
6. Superpone **Ciber Dragón del Infinito** sobre el Nova que controlas; Nova y sus dos materiales pasan debajo de Infinito: **3 materiales Xyz** (Nova + Sulfador + segundo Azufafnir). Reserva al menos uno para su **Efecto Rápido** de negar activación y destruir si se resuelve legalmente.
- **Final comprobable si se resuelve todo:** **Infinito con 3 materiales**, Campo sin Inclusión (destruida); GY contiene Inclusión, **Smiger descartado** y **primer Azufafnir destruido**; Normal aún disponible. Si elegiste envíos opcionales de Sulfador, registra sus nombres en GY. Infinito es Máquina, por lo que el bloqueo de Sulfador **no** lo impide. **No** se produjo Sincronía ni hay Hagoita/Quariongandrax en ese Campo.
- **Fallos críticos:** si negaron la búsqueda, faltaría Smiger para pagar descarte de Azufafnir; si retiran Sulfador antes de superponer, falta el segundo Nivel 5; si se agota el segundo Azufafnir del Deck, falla el acceso descrito. **Requiere dos copias de Azufafnir físicamente disponibles** (hay tres en Main). **Fuentes:** [Azufafnir 12756](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12756&ope=2&request_locale=es), [Sulfador 20759](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=es), [Nova 10870](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=10870&ope=2&request_locale=es), [Infinito 11765](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11765&ope=2&request_locale=es). **R12/R19; RGL04/11.**

### C07 — Amset + Smiger: puente Horus/Cristron sin bloqueo del Extra

- **Objetivo propio:** conseguir **presencia Horus Nivel 8 + Tristaros para Sincronía reactiva**, con dos motores activos y Smiger recuperable. **Dificultad:** media; **mano mínima:** Amset + Smiger. **Estado inicial:** Campo/GY vacíos; Sarcófago, Inclusión y Tristaros en Deck; Sulfador en Deck y Elesqueletus en Extra; ninguna restricción previa. **Una Normal disponible.**
1. Usa el efecto de **Amset en mano**: envía **Amset + Smiger** desde mano al GY; **busca Sarcófago del Rey** del Deck y **opcionalmente** roba una carta desconocida (no contar su identidad para este combo).
2. **Activa Sarcófago** boca arriba. Con él en Campo, **Invoca Amset desde GY** mediante su condición especial; ya tienes **un Horus Nivel 8** en Campo. Esto no crea un segundo Horus sin otra fuente.
3. Como **Smiger llegó al GY por descarte y NO activó su efecto de Campo**, puedes **desterrarlo desde GY para buscar Inclusión Cristron** del Deck. Esta activación **no** impone bloqueo de Sincronía Máquina: es el otro efecto de Smiger.
4. **Activa Inclusión** y busca **Tristaros Nivel 2** del Deck; luego **Normal Summon Tristaros**. Resultado al cerrar tu turno: **Amset 8 + Tristaros 2** en Zona de Monstruos, **Sarcófago + Inclusión** boca arriba en M/T; Smiger **desterrado**, no en GY, y ninguna Sincronía realizada aún.
5. En el turno rival, si **activa una carta/efecto**, encadena **Tristaros** para traer **Sulfador 5 del Deck** y Sincronizar **Tristaros2 + Sulfador5 → Elesqueletus7**. **Amset queda en Campo**, no se utiliza como material. La cadena original rival resuelve según su efecto; **Elesqueletus NO niega esa activación**.
6. Después de la cadena, **Elesqueletus** puede recuperar **Smiger desterrado** a tu mano (si sigue siendo legal) mediante su disparador de haber sido sincronizada. Esa recuperación no autoriza un segundo uso de Smiger en el mismo turno si ya había usado efecto ese turno.
- **Estado final condicional:** Elesqueletus 7 + Amset 8 en Campo, Sarcófago + Inclusión boca arriba; Smiger recuperado a mano; Tristaros y Sulfador en GY como materiales. **Ventaja:** no se activó el efecto de Smiger de Campo, así que **no** bloqueamos el Extra el turno propio; **desventaja:** usa dos búsquedas encadenadas vulnerables a Droll/negación y depende de una activación rival para hacer la Sincronía.
- **Si niegan:** si Amset no añade Sarcófago, no puedes asegurar su invocación GY; si se prohíben búsquedas después de Sarcófago, la ruta Smiger/Inclusión pierde esta extensión; si Tristaros es retirado antes de la activación rival, no hay Elesqueletus. **R03/R01/R07/R10/R13; RGL03/05/08/10/15.**

### V01 — Extensión condicional de C02 a Quariongandrax (dos turnos)

**No es combo autónomo de una carta** ni se cuenta como nuevo combo principal: parte **exactamente después del campo final de C02**, con Elesqueletus 7 y Smiger 3 en tu Campo; Tristaros 2 y Citree 2 en GY; segundo Tristaros 2, Azufafnir 5 y segundo Sulfador 5 todavía en Deck; Quariongandrax en Extra. Requiere supervivencia y espacio de monstruos. **Dificultad alta, no simulada.**

1. En tu mismo turno, destierra del GY el **primer Tristaros** para activar su efecto: selecciona y **destruye tu Elesqueletus** previamente Invocada por Sincronía y **trae dos Cristron desde Deck**, el **segundo Tristaros (Cantante 2)** y **Azufafnir (no Cantante 5)**. La restricción Extra de Tristaros es a Máquinas; también sigue la más estricta de Smiger este turno.
2. Al haber sido destruida Elesqueletus que sí fue sincronizada, puede activar su efecto para **revivir Citree (Cantante 2) de tu GY**, según la ventana posterior de disparador. Resultado aproximado al cierre de tu turno: **Smiger 3, Tristaros 2, Azufafnir 5 y Citree 2** en Campo (cuatro zonas ocupadas). Elesqueletus ahora GY; el primer Tristaros desterrado. **No hagas una Sincronía aún**: estamos preparando reacción rival.
3. En el turno rival, ante una **activación de carta/efecto del oponente**, encadena el Efecto Rápido del **segundo Tristaros**; trae el **segundo Sulfador Nivel 5 del Deck** y de inmediato Sincroniza usando **Tristaros 2 + Citree 2 (2 Cantantes) + Sulfador 5 (1 no Cantante)** → **Cristron Quariongandrax Nivel 9**. El recién invocado Sulfador está incluido, requisito de Tristaros.
4. **Después de resolverse toda la cadena** de esa activación rival, si la Invocación por Sincronía ocurrió legalmente y el disparador se puede activar, usa el efecto de **Quariongandrax** para seleccionar hasta **3 monstruos del adversario** válidos en Campo/GY y **desterrarlos** (el máximo se basa en sus 3 materiales). Si no existen 3 objetivos, el resultado es menor; no se destierran Mágicas/Trampas.
- **Final condicional:** Quariongandrax en Campo, Smiger 3 y Azufafnir 5 permanecen si nada adicional los movió; materiales de esa Sincronía en GY; hasta 3 monstruos rivales desterrados **solo si hubo objetivos y cadena válida**. Sin activar la cadena rival, o si no sobrevive el tablero previo, **V01 no ocurre**. **R07–R10; RGL05/06/08/09/15.**

### V02 — Inclusión sola como acceso alterno a C01

1. Mano inicial **solo Inclusión** como starter; Campo/GY vacíos, Smiger y Citree disponibles en Deck.
2. Activa Inclusión y **busca Smiger**. Haz Normal Smiger, destrúyelo por su efecto y **trae Citree** del Deck; Inclusión sigue boca arriba.
3. En turno rival, Citree selecciona Smiger del GY y sincroniza **Hagoita 5** como en C01, desterrando ambos materiales.
- **Diferencia real con C01:** se consume una búsqueda; **Inclusión permanece en Campo**. Si la búsqueda fue negada o prohibida por Droll/Arresto, no asumir que se creó Smiger. **No** aumentar conteo de combos principales.

### V03 — Azufafnir + Smiger: versión defensiva de Tristaros/C03

- **Inicio distinto, mismo motor reactivo de C03:** **Azufafnir + Smiger en mano**, Tristaros y Sulfador disponibles en Deck, Agrupamiento Cristron en Deck y Elesqueletus en Extra; Campo/GY vacíos. **No usa Normal Summon** y necesita que el rival active algo en su turno para llegar a Elesqueletus. **No sumarlo como un octavo combo principal.**
1. Descarta **Smiger** para activar **Azufafnir en mano**; Invócalo en DEF y destruye **ese mismo Azufafnir** con su efecto. El Azufafnir destruido activa en la nueva cadena su **otro** efecto y trae **Tristaros** del Deck en DEF.
2. **Destierra Smiger desde GY** (no usó el efecto de Campo) y busca **Agrupamiento Cristron** del Deck. **Coloca Agrupamiento** en tu Zona M/T. Final del turno propio: **Tristaros** en Campo + **Agrupamiento Colocado**; Smiger desterrado, Azufafnir GY, Normal intacta. **La Trampa NO se activa en el turno en que fue Colocada.**
3. En turno rival ante activación de carta/efecto, Tristaros puede traer **Sulfador 5 del Deck** y sincronizar **Elesqueletus 7** con su Nivel 2. Al terminar la cadena, Elesqueletus puede recuperar Smiger desterrado a mano.
4. **Agrupamiento ya está activable en turno rival**: cuando tengas Elesqueletus (Sincronía Cristron) y un Cristron elegible en GY/destierro para barajar, puedes activar la Trampa y su efecto contra hasta **dos cartas boca arriba** que selecciones, barajando por ejemplo **Tristaros** del GY. Si los objetivos desaparecen antes de resolver, no atribuyas destrucción.
- **Resultado diferencial:** frente a C03, añades una **Trampa de eliminación** y la búsqueda GY de Smiger; pagas Azufafnir + Smiger y dependes de tener Agrupamiento en Deck y de ventanas correctas. El efecto de Agrupamiento **no** es una negación de activación.

### V04 — Cambio de destino en C02: Destructor Samurái, no Elesqueletus

1. Sigue los **pasos 1–4 de C02**: Inclusión busca Smiger, Smiger trae Citree, Sulfador destruye Inclusión y se Invoca, Inclusión del GY se destierra para revivir Smiger. En ese punto tienes **Citree 2 + Sulfador 5 + Smiger 3**.
2. En el paso 5, **en vez de Elesqueletus**, sincroniza **Citree 2 + Sulfador 5 → Destructor Samurái 7 (Máquina Sincronía)**. Es legal pese al bloqueo de Smiger, porque sigue siendo **Sincronía Máquina**.
3. **Fin:** Destructor Samurái 7 + Smiger 3 en Campo; Inclusión **permanece desterrada** (no hubo Elesqueletus que la recuperara); Citree y Sulfador van al GY; Tristaros y Thystvern ya enviados en C02 pueden seguir allí. Tu campo gana opción para atacar: al **combatir contra un monstruo**, el rival no activa cartas/efectos hasta fin de Damage Step, y los efectos del monstruo combatido se niegan durante esa Battle Phase, según el texto de la carta. **No** equivale a negación general fuera de batalla.
- **Decisión:** elige esta salida **si vas segundo** y el objetivo es combatir un monstruo problemático; elige **Elesqueletus** si necesitas recuperar Inclusión y conservar recursos. **Mismo starter y materiales, distinto cierre: variante, no nuevo combo.**

### Doce manos/casos de entrenamiento, SIN probabilidad simulada

| Caso | Mano inicial supuesta (otras cartas no contadas) | Plan más razonable | Tablero/desenlace comprobable y control |
|---|---|---|---|
| **H01** | Smiger | **C01** | Citree turno propio → Hagoita turno rival si Smiger sigue en GY y Citree resuelve. |
| **H02** | Inclusión Cristron | **V02** | Inclusión busca Smiger; luego misma conversión C01, salvo bloqueo de búsqueda. |
| **H03** | Inclusión + Sulfador | **C02**, considerar V01 únicamente si quedan piezas | Elesqueletus 7 + Smiger 3; Inclusión recuperada; riesgo de interrupción en búsqueda/destrucción. |
| **H04** | Tristaros | **C03** | Tristaros espera en Campo; requiere que rival active carta/efecto y que exista Sulfador en Deck. |
| **H05** | Amset + Hapi | **C04** | Sarcófago + Número 90 con 2 materiales, salvo interrupciones. |
| **H06** | Sarcófago + Amset | **C05** | Vampiro Zombi con 2 materiales; molienda no predeterminada; Hapi **debe** seguir en Deck. |
| **H07** | 2× Flor de Ceniza + Súper Polimerización + Citree | **Control/interacción**, **sin combo de motor certificado** | No existe no Cantante Cristron GY inicial para Citree; no prometer Sincronía ni Fusión sin materiales concretos. |
| **H08** | Amset + Sulfador + Súper Polimerización | **Elección de ruta y orden**, no combo completo acreditado | Si rival ofrece Fusión válida, resolver Súper Polimerización **antes** de bloqueo de Sulfador; Amset no busca Sarcófago sin segunda carta de mano que se envíe con ella, que aquí sí puede ser otra de las dos, pero el coste puede desarmar el plan. |
| **H09** | Inclusión + Sulfador + Azufafnir | **C06** | Infinito con **3 materiales Xyz** sin Normal; pide segundo Azufafnir en Deck y descartar Smiger buscado. |
| **H10** | Amset + Smiger | **C07** | Amset8 + Tristaros2 + dos Continuas; en turno rival Elesqueletus7 + Amset8 **si** hay activación. |
| **H11** | Azufafnir + Smiger | **V03** | Tristaros y Agrupamiento Colocado; turno rival podría llegar a Eles7 y destruir objetivos boca arriba con Trampa legal. |
| **H12** | Inclusión + Sulfador, rival presenta monstruo difícil en Battle | **V04** | Destructor Samurái7 + Smiger3; **no** recupera Inclusión, a diferencia de C02. |

### A09.1 — Registro corto de ocho dimensiones del campo final (una fila por ruta principal)

En todas las filas se presupone **rival sin intervención**, salvo que las líneas reactivas necesitan **una activación rival**. El Campo adversario y daño son **DESCONOCIDOS**, nunca «0» implícito. Ninguna carta usada como material Xyz se cuenta simultáneamente como monstruo libre. Los efectos opcionales no elegidos y cartas de mano no nombradas son **desconocidos**, no inventados.

| Ruta y momento de corte | Monstruos propios | M/T propia | Mano recuperada conocida | Cementerio relevante | Destierro / material Xyz | Normal y restricción Extra |
|---|---|---|---|---|---|---|
| **C01**, después de respuesta en turno rival | Hagoita 5 | Ninguna fijada | Ninguna asegurada | Smiger/Citree **ya no están** | Smiger + Citree **desterrados**; sin materiales Xyz | Normal usada turno previo; bloqueo Smiger ya terminó al pasar turno |
| **C02**, cierre turno propio | Elesqueletus7 + Smiger3 | Inclusión **ya no en Campo** | **Inclusión en mano** | Citree, Sulfador, Tristaros, Thystvern | Inclusión recuperada, no desterrada; sin materiales Xyz | Normal usada; solo **Sincronía Máquina** ese turno |
| **C03**, tras cadena rival y recuperar Tristaros | Elesqueletus7 | Ninguna fijada | **Tristaros** a mano desde GY si recuperado | Sulfador GY; Tristaros recuperado | Sin Xyz | Normal turno previo; no adjudicar bloqueo propio de Sulfador si fue invocado del Deck |
| **C04**, antes de usar negación | Número90 Rango8 | Sarcófago boca arriba | Robo opcional no identificado | Amset/Hapi **no en GY** | **Amset + Hapi como 2 materiales**; sin destierro de esas piezas | Normal no requerida; sin bloqueo Cristron |
| **C05**, antes de activar molino | Vampiro Zombi Rango8 | Sarcófago boca arriba | Ninguna asegurada | Horus usados **no en GY** | **Amset + Hapi como 2 materiales**; resultados del molino aún inexistentes | Normal no requerida; sin bloqueo Cristron |
| **C06**, Infinito recién Invocado, sin envíos opcionales | Infinito Rango6 | Inclusión destruida, ya no en M/T | Ninguna asegurada | Inclusión, Smiger, primer Azufafnir | **Nova + Sulfador + segundo Azufafnir = 3 materiales bajo Infinito** | Normal **intacta**; solo **Máquinas** desde Extra este turno |
| **C07**, tras respuesta rival y recuperación | Elesqueletus7 + Amset8 | Sarcófago + Inclusión boca arriba | **Smiger** recuperado del destierro | Sulfador y Tristaros como materiales de Sincronía enviados GY | Smiger ya **no** desterrado; sin Xyz | Normal usada turno previo; Smiger solo usó efecto GY, sin bloqueo «solo Sincronía» de su efecto de Campo |

**Prueba de coherencia:** C06 y C04/C05 usan **Xyz con monstruos convertidos en material**; C01 destierra los materiales **solo** por efecto de Citree; C02/C03/C07 emplean **Sincronías ordinarias** cuyos materiales se envían al GY, salvo sustitución específica. En V03, **Agrupamiento colocado** del turno propio solo pasa a activable en turno posterior. Estas distinciones tienen prioridad sobre cualquier dibujo que represente erróneamente las zonas.

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

## APARTADO_10 — Siete guías numeradas con referencia visual auténtica

**Criterio visual:** paneles en texto breve, orden de acciones y zonas verificables. Se insertan **solo** imágenes de los 20 CIDs auténticos presentes en esta carpeta; cada carta Cristron y Número 90 sin imagen real se muestra como **`[FOTO_PENDIENTE — CID]`**, no como dibujo sustituto. Por eso este apartado permanece **PARCIAL / NO PUBLICABLE**: se necesitan 19 fotografías y ejecución en simulador para guías finales completas. La ausencia de imagen **no** borra el texto del combo.

### G01 — Smiger → Citree → Hagoita (C01; primero/reactivo)

**Objetivo:** colocar un Nivel 5 Máquina en turno rival. **Piezas:** `![Cristron Smiger](imagenes/12608.png)` → `![Cristron Citree](imagenes/12606.png)` → `![Hagoita de Alta-Velociroid](imagenes/12157.png)`.

1. **Normal Smiger**, seleccionarlo y destruirlo por su propio efecto. **Smiger → GY**.
2. **Citree del Deck → Campo**, fin del turno propio; ¡aún NO hay Hagoita!
3. **Main/Battle del rival:** Citree revive Smiger 3 del GY y sincroniza **2 + 3 = Hagoita 5**.
4. **Tablero:** Hagoita en Campo, **Citree/Smiger desterrados**. **Decisión:** activar Efecto Rápido de Hagoita solo si interesa subir los niveles, no llamar «negación» a su efecto.

### G02 — Inclusión + Sulfador → Elesqueletus (C02; recuperación)

**Objetivo:** Sincronía 7 que recupera recurso. **Piezas:** `![Inclusión Cristron](imagenes/20798.png)`, `![Cristron Sulfador](imagenes/20759.png)`, `![Cristron Smiger](imagenes/12608.png)`, `![Cristron Citree](imagenes/12606.png)`, `![Cristron Elesqueletus](imagenes/20778.png)`.

1. **Inclusión activa → busca Smiger**; Normal Smiger → se destruye → **Citree del Deck**.
2. **Sulfador desde mano** destruye Inclusión y se Invoca; **manda Tristaros + Thystvern del Deck al GY**.
3. **Inclusión desde GY:** se destierra → revive **Smiger desde GY**.
4. **Citree 2 + Sulfador 5 → Elesqueletus 7**; recuperar **Inclusión desterrada** a la mano.
5. **Tablero final:** Elesqueletus + Smiger; Inclusión en mano; Citree/Sulfador/Tristaros/Thystvern en GY; **bloqueo Sincronía Máquina este turno**. **Rama:** si niegan búsqueda, revisar starter y detener, sin inventar recursos.

### G03 — Tristaros reacciona → Elesqueletus (C03; cadena)

**Piezas:** `![Cristron Tristaros](imagenes/20758.png)` → `![Cristron Sulfador](imagenes/20759.png)` → `![Cristron Elesqueletus](imagenes/20778.png)`.

1. **Normal Tristaros** y conserva en Campo al pasar turno.
2. **Cadena rival:** rival activa carta/efecto (CL1) → **Tristaros responde (CL2)**.
3. Al resolver CL2 trae **Sulfador 5** del Deck y sincroniza **Tristaros 2 + Sulfador 5 = Elesqueletus 7**; después resuelve CL1 si sigue siendo aplicable.
4. **Nueva cadena después:** Elesqueletus recupera Cristron del GY/destierro, si sigue siendo legal. **No** llamar a esta Sincronía una negación del CL1.

### G04 — Dos Horus → Número 90 (C04; negar monstruo)

![Amset, Gloria de Horus](imagenes/19153.jpg)

![Hapi, Guía de Horus](imagenes/19155.jpg)

![Sarcófago del Rey](imagenes/19200.jpg)

**Última carta:** `![Número 90: Señor Fotónico de Ojos Galácticos](imagenes/13826.png)`.

1. En mano **Amset + Hapi** → ambos al GY; **buscar Sarcófago**, robar solo si eliges y puedes.
2. **Activar Sarcófago** → **revivir Amset y Hapi** como Nivel 8.
3. **Xyz 8 + 8 = Número 90** (2 materiales Horus).
4. **Final:** Número 90 + Sarcófago; **negación de monstruo al desacoplar**, pero **sin destrucción por material Horus**. No decir que el tablero también tiene Vampiro Zombi: comparten materiales.

### G05 — Sarcófago + Amset → Vampiro Zombi (C05; molino)

![Sarcófago del Rey](imagenes/19200.jpg)

![Amset, Gloria de Horus](imagenes/19153.jpg)

![Hapi, Guía de Horus](imagenes/19155.jpg)

![El Vampiro Zombi](imagenes/16850.jpg)

1. **Sarcófago boca arriba:** descartar **Amset** de la mano para mandar **Hapi** del Deck al GY.
2. **Revive Amset + Hapi** desde GY con Sarcófago presente.
3. **Xyz 8 + 8 → Vampiro Zombi**; antes de gastar materiales tiene 2.
4. **Desacopla 1** → manda **4 cartas de tu Deck + 4 del Deck rival** al GY. **¿Hay monstruo entre las ocho?** Si sí, evalúa un monstruo elegible para revivir; si no, **no inventes invocación**.
5. **Final fijo:** Vampiro Zombi + Sarcófago; **final variable:** las cartas enviadas y una posible invocación adicional. Restricción: jugarlo **antes** de efectos que limiten Extra a Máquinas/Sincronías Máquina.

### G06 — Sulfador + Azufafnir → Nova → Infinito (C06; negación)

**Objetivo:** poner una **negación de activación** usando solo cartas del Extra que ya tienes. **Mano:** `![Inclusión Cristron](imagenes/20798.png)`, `![Cristron Sulfador](imagenes/20759.png)`, `![Cristron Azufafnir](imagenes/12756.png)`; segundo Azufafnir en Deck.

![Ciber Dragón Nova](imagenes/10870.jpg)

![Ciber Dragón del Infinito](imagenes/11765.jpg)

1. **Inclusión busca Smiger** → **Sulfador destruye Inclusión** y se invoca **Nivel 5**.
2. **Azufafnir descarta Smiger**, se invoca en DEF y **se destruye a sí mismo** → su segundo efecto trae **otro Azufafnir Nivel 5** del Deck. **No destruyas Sulfador**: lo necesitas como material.
3. **Sulfador 5 + segundo Azufafnir 5 = Nova Rango 5** (2 materiales).
4. **Nova → Infinito Rango 6** por superposición, ahora **3 materiales Xyz**. Infinito puede desacoplar 1 para negar una activación en ventana legal.
5. **Estado:** Infinito (3 materiales), Normal sin usar; Smiger + primer Azufafnir + Inclusión en GY. **Aclaración:** los dos Nivel 5 ya no son monstruos independientes, están bajo Infinito. Los 2 posibles envíos de Sulfador son opcionales y, si los hiciste, quedan anotados aparte.

### G07 — Amset + Smiger → Tristaros reactivo (C07; puente entre motores)

**Objetivo:** conservar **Amset** en Campo mientras Cristron prepara **Elesqueletus** en turno rival. **Piezas:** `![Cristron Smiger](imagenes/12608.png)`, `![Inclusión Cristron](imagenes/20798.png)`, `![Cristron Tristaros](imagenes/20758.png)`, `![Cristron Elesqueletus](imagenes/20778.png)`.

![Amset, Gloria de Horus](imagenes/19153.jpg)

![Sarcófago del Rey](imagenes/19200.jpg)

1. **Amset + Smiger** de mano a GY → **busca Sarcófago**, robo opcional desconocido.
2. **Sarcófago al Campo**, **revive Amset** (8). **Smiger GY se destierra para buscar Inclusión**; no se activó su efecto de Campo.
3. **Activa Inclusión**, busca **Tristaros** → Normal Tristaros (2). Fin de turno: **Amset8 + Tristaros2 + Sarcófago + Inclusión**; Smiger desterrado.
4. **Si el rival activa carta/efecto**, Tristaros trae Sulfador5 del Deck y hace **Elesqueletus7** con 2+5. **Amset8 permanece**.
5. **Tras la cadena**, Elesqueletus puede devolver **Smiger desterrado a mano**. Campo final condicionado: **Elesqueletus7 + Amset8**, dos Continuas boca arriba. **No** atribuir negación de activación a Elesqueletus.

**Guías de variantes dentro del mismo archivo:** V01 aporta Quariongandrax en dos turnos; V02 vuelve a G01 desde Inclusión; V03 prepara Agrupamiento **Colocado** y Tristaros, y V04 cambia G02 por Destructor Samurái sin recuperar Inclusión. Se leen vinculadas a su ficha canónica A09: **no** son cuatro guías fotográficas adicionales ni se cuentan como combos nuevos.

### Cierre A10 — Lo que faltaría para declarar guía completa

1. Reemplazar las **19 marcas FOTO_PENDIENTE** con **imágenes reales del CID correcto** y cotejar la presencia de las 20 actuales; sin fuentes, no generar dibujos ni pedir a la plataforma que muestre una carta distinta.
2. Capturar 11 replays legales **C01–C07 + V01–V04**, con mano inicial, cadena, zona de cada carta, material, restricciones y campo final, distinguiendo las rutas que fracasen.
3. Comprobar en simulador la sincronización dentro de la cadena de **Tristaros**, el disparador posterior de **Elesqueletus** y la construcción condicionada **V01**; ajustar las rutas si una interacción falla.
4. Medir manos reales, puntos de interrupción por **Ash, Droll, Nibiru y efectos de destierro** sin atribuir porcentajes sin datos; cotejar compatibilidad de **F.A. Coche Trucado del Amanecer** con el formato acordado.

---

## PROFUNDIZACIÓN V3 · Cruce de todos los apartados A01–A10 (17-11-2026)

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

### A01 · Tres estilos y una identidad híbrida sin sobreextensión

| Estilo | Cuándo elegirlo | Amenaza real | Coste / punto ciego |
|---|---|---|---|
| **Cristron reactivo** | Primero y con Smiger, Tristaros, Inclusión o Entierro | Preparar Citree/Tristaros para Sincronía **en turno rival** | No crea una negación por el mero hecho de sincronizar; depende de ventana/objetivo |
| **Horus autónomo** | Primero con dos Horus accesibles a GY y Sarcófago | N.º 90 niega efecto de monstruo; Vampiro Zombi da molienda variable | Los dos Horus quedan como **materiales Xyz**, no continúan sueltos en Campo |
| **Máquina Xyz / contraataque** | Inclusión + Sulfador + Azufafnir o rival ofrece Super Poly | Nova→Infinito con negación, o fusión puntual de campo rival | Smiger usado **en Campo** impide Xyz ese turno; falta conocer material rival para Fusión |

**Objetivo de turno 1:** acabar con **una amenaza efectiva y una continuación posible**, no “hacer todas las líneas”. **Turno 2/3:** recuperar Inclu­sión/Smiger con Elesqueletus o conservar Horus en GY con Sarcófago; no usar un monstruo ya desterrado como si siguiera en GY. **Plan de victoria:** desgaste de recursos e interrupciones concretas, ataques posteriores o control de monstruos; sin porcentajes de éxito asumidos. **Fortaleza diferencial**: dos motores permiten escoger tipo de Extra antes de bloquearlo. **Debilidad diferencial**: el mismo Extra mezcla Sincronías Máquina, Xyz Máquina, Xyz no Máquina, Link y Fusiones; su orden importa más que en una lista de un solo tipo.

### A02 · Árbol de decisiones de apertura y secuencia

1. **Antes de activar nada:** contar qué cartas siguen **en el Deck**, en particular **Hapi ×1**, **Citree ×1**, **Thystvern ×1**, segundo Azufafnir, segundo Tristaros y objetivos de Inclusión. Una carta que ya robaste no puede traerse **del Deck**.
2. **¿Necesitas Xyz Horus/Link/Súper Polimerización?** Ejecutarlos **antes** de resolver el efecto en Campo de Smiger/Thystvern. Tras **Sulfador** aún es posible **Nova/Infinito** porque son Máquinas, pero ya no Número 90, Vampiro Zombi, S:P, Garura ni Fangodragón ese turno.
3. **¿Necesitas una reacción turno rival sin más cartas?** Con **Smiger**, comparar **C01** (Citree→Hagoita) frente a **V05** (Tristaros→Elesqueletus). Son dos elecciones distintas con **la misma Normal y el mismo efecto de Smiger**, no dos salidas simultáneas.
4. **¿Tienes Entierro Insensato pero no Smiger?** Comprobar V06: enviar Smiger al GY, desterrarlo para buscar Inclusión, buscar Tristaros y usar Normal. **No** buscar si Droll o Arresto Erróneo ya lo impiden.
5. **¿Sarcófago+Hapi en vez de Sarcófago+Amset?** Comprobar **V07**, no dar por perdido el Horus único de la mano. Sarcófago descarta Hapi de mano y envía **Amset del Deck**; comprobar que otra copia permanezca en Deck.
6. **¿Hay Ash/Droll o negación rival?** Marcar exactamente qué efecto se niega: una negación a búsqueda de Inclusión deja la Mágica boca arriba si la **activación** no fue negada; otra a envío de Sulfador deja Sulfador en Campo pero no da materiales de GY. Recalcular, no “continuar por memoria”.
7. **¿Rival juega destierro?** Si usaste Lancea desde Side, también queda suspendido **tu** destierro de Smiger, Inclusión y materiales de Citree mientras dure. El plan de Horus puede ser más estable si ya tienes Sarcófago.

**Plan de riesgo Nibiru:** C06 alcanza cinco Invocaciones incluyendo Nova e Infinito; si Infinito ya está en Campo con material, su negación podría responder a una activación legal de Nibiru. **No** afirmar inmunidad previa a tener Infinito disponible, ni ignorar otra interrupción en el mismo punto.

### A03 · Inventario y zonas
Main 40, Extra 15 y Side 15. Las 70 cartas se estudian tal cual, sin trasladarlas ni sustituirlas. El Side se considera solo cuando se realiza un intercambio físico 1:1 entre duelos.

### A04 · Cobertura fotográfica reproducible

- **20 imágenes locales auténticas:** `7445`, `13454`, `17746`, `19153`, `12950`, `4861`, `13619`, `20787`, `10870`, `13710`, `16850`, `11765`, `19200`, `9279`, `15296`, `15299`, `19188`, `19155`, `20206`, `20500`.
- **19 CIDs pendientes (sin imagen inventada):** `11243`, `11411`, `11849`, `12157`, `12606`, `12608`, `12609`, `12756`, `12781`, `13360`, `13826`, `16868`, `20758`, `20759`, `20778`, `20798`, `20817`, `5236`, `9454`.
- **Prioridad visual:** primero los seis cuerpos Cristron necesarios para C01–C03/C06/V05/V06 (Smiger, Tristaros, Citree, Sulfador, Inclusión, Elesqueletus), luego Azufafnir/Quariongandrax/Hagoita, después el Side. El nombre del archivo es su **CID oficial**, no el orden de copia en el deck.
- **No confundir:** enlace a ficha Konami permite consultar la imagen externamente; **no equivale a tener el JPG local**. Las 20 existentes se conservan sin modificar.

### A05 · Propósito, debilidades y condiciones de diez piezas determinantes

| Carta | Aporta al plan | Cuándo conviene | Error frecuente |
|---|---|---|---|
| **Smiger** | Campo: Cantante desde Deck; GY: buscar M/T | C01/V05 desde Campo; V06/C07 desde GY | Intentar usar **ambos** efectos en el mismo turno |
| **Tristaros** | Sincronía dentro de respuesta a activación rival; GY rompe Sincronía propia para extender | C03, V01, V05/V06 | Contarlo como negación del CL1 rival |
| **Citree** | Revivir no Cantante y Sincronizar en turno rival | C01 y C02; calcular Nivel | Olvidar que **ambos materiales quedan desterrados** por su efecto |
| **Sulfador** | Destruir carta Cristron propia, invocarse y mandar 2 nombres | C02/C06; separar sus dos efectos | Declarar Número 90 tras su bloqueo **solo Máquinas** |
| **Azufafnir** | Extensor descartando Cristron y reemplazo del destruido | C06/V03 | No llevar otro ejemplar disponible en Deck para C06 |
| **Inclusión** | Buscar carta Crystron en activación y revivir Cristron desde GY | C02/C06/V06 | Activar **segunda** Inclusión el mismo turno tras recuperar la primera |
| **Amset** | Enviar 2 de mano, buscar Sarcófago y reanimarse | C04/C07; valora costo de mano | Creer que el robo opcional dio exactamente la carta deseada |
| **Hapi** | Segundo Nivel 8 accesible desde mano o Deck vía Sarcófago | C04/C05/V07 | Asumir que Hapi sigue en Deck cuando ya lo robaste |
| **Agrupamiento** | Proteger de destierro rival y destruir boca arriba reciclando | V03, respuesta del rival después de Colocarse | Usar en el turno de colocación o sobre cartas boca abajo |
| **Súper Polimerización** | Romper campo usando materiales compatibles | Ir segundo, **antes de bloquear Extra** | Usar Garura/Mudragon sin Tipo/Atributo válidos |

**Nota de utilidad:** una handtrap del Main o carta del Side cumple un propósito propio aunque no forme parte de un combo. Cada identidad mantiene su fila funcional A05–A06; las propuestas no cambian el inventario.

### A06 · Las 13 identidades del Extra: acceso, decisión y contraprestación

| Extra, copias | Origen legal de materiales | Propósito | Dictamen v3 |
|---|---|---|---|
| **F.A. Dawn Dragster ×2** | Citree2 + no Cantante Máquina5 → Sincronía Máquina7 | Negar M/T por Niveles | Condiciones de Invocación y efectos del texto oficial |
| **Elesqueletus ×2** | Citree2+Sulfador5 / Tristaros2+Sulfador5 | Recupera carta Crystron, puede revivir si destruida luego | **Prioridad alta**, C02/C03/V05/V06 |
| **Quariongandrax ×1** | Dos Cantantes Nivel2 + no Cantante Nivel5 | Desterrar hasta tres monstruos rivales | **Techo condicionado**, V01, no final universal |
| **S:P ×1** | Dos monstruos de efecto antes de bloqueos | Destierro temporal en respuesta rival | **Potencial**, evitar activarla sin objetivos |
| **Caballero Mecánico ×1** | Una Máquina no Link de ATK original ≤1000 | Cuerpo Link1 y efecto pequeño de Máquina | **Sin objetivo de búsqueda «Noche Mecánica» en esta lista** |
| **Ciber Dragón del Infinito ×1** | Superponer sobre Nova controlado | Negar activación con material; absorción de monstruo en ataque | **Alta utilidad**, solo si Nova fue accesible: C06 |
| **Ciber Dragón Nova ×1** | Dos Máquinas de Nivel5 (Sulfador + Azufafnir) | Puente Xyz hacia Infinito | **C06 documentado**; no hacerlo tras Smiger de Campo |
| **Hagoita ×1** | Citree2 + Smiger3 en turno rival | Manipular Niveles con Sacrificio | **Reacción de nivel**, no negación; C01 |
| **N.º 90 ×1** | Amset8 + Hapi8 | Negar efecto monstruo | **Interacción Horus**, C04/V07; material Horus no activa destrucción extra |
| **Vampiro Zombi ×1** | Dos Horus Nivel8 | Molienda variable, eventual Especial | **Motor de valor variable**, C05/V07 |
| **Destructor Samurái ×1** | Citree2+Sulfador5 | Ventaja al combatir | **Plan de batalla** V04; no recuperación de Inclusión |
| **Garura ×1** | Dos monstruos de mismo Tipo y Atributo, distintos nombres | Fusión por Super Poly / robo si acaba en GY | **Condicional a campo válido**, no equiparar con negación |
| **Fangodragón ×1** | Dos monstruos de mismo Atributo y distinto Tipo | Fusión por Super Poly | **Condicional al rival** y al orden respecto a bloqueos |

**Chequeo de slots:** Dawn2 + Eles2 + 11 identidades de una copia = **15 slots / 13 identidades**. El Extra tiene **dos copias físicamente prohibidas** bajo el formato auditado; su presencia no cambia el estudio de su efecto, pero sí invalida inscripción de torneo. Nunca usar a Nova e Infinito **simultáneamente como dos monstruos en Campo** tras el paso de superposición.

### A07 · Nuevas reglas RGL16–RGL21 y seis interrupciones INT09–INT14

| ID | Requisito exacto o incompatibilidad | Aplicación |
|---|---|---|
| **RGL16** | El límite de Droll a **1** se aplica al **conjunto Main+Side**, no a cada zona por separado. | Cantidad física preservada y documentada |
| **RGL17** | Dawn Dragster exige Cantante + no Cantantes y Nivel total 7. | Cotejar si la ruta preserva la restricción de Invocación del motor Crystron |
| **RGL18** | Llamado por la Tumba del Side requiere objetivo en Cementerio y ventana válida. | S02 es un cambio físico 1:1 entre duelos y su activación no es automática |
| **RGL19** | Talento de Tácticas Triples requiere activación de monstruo rival en Main Phase propia. | S02 solo la usa si se cumplen condición y ventana |
| **RGL20** | Azufafnir **puede** invocar otra copia de su mismo nombre desde el Deck si la primera **fue destruida en Campo**, porque su segundo efecto no excluye su propio nombre. | C06 necesita otra copia en Deck, no una ficticia; texto oficial CID 12756 |
| **RGL21** | Inclusión permite buscar al activarse **una carta Crystron excepto Inclusión**; tras usar su efecto desde GY para revivir, esa copia queda desterrada. | V06 usa **Smiger GY → Inclusión → Tristaros**, no búsqueda directa de Inclusión por Inclusión |

| Caso adversario | Paso que se altera | Estado residual comprobable | Desvío correcto |
|---|---|---|---|
| **INT09 — Ash a Smiger (V05)** | Smiger intenta destruirse e Invocar Tristaros desde Deck | La destrucción e Invocación no se producen por ese efecto negado; Smiger sigue en Campo salvo otros cambios | No declarar Tristaros/Eles; pasar con recursos reales |
| **INT10 — Ash a Inclusión (V06)** | Tras buscar Inclusión con Smiger GY, activas Inclusión y rival niega su búsqueda de Tristaros | Smiger está **desterrado**; Inclusión en Campo si solo se negó efecto; Tristaros no llegó a mano | No anunciar Normal de Tristaros inexistente |
| **INT11 — Droll después de Smiger GY (V06)** | Smiger ya buscó Inclusión; Droll resuelve antes de activar Inclusión | Inclusión **sí está en mano**, pero no puede añadir Tristaros desde Deck a mano ese turno | Conservar Inclusión para uso continuo, no forzar V06 |
| **INT12 — Retirada de Sarcófago (V07)** | Hapi y Amset están en GY, rival retira Sarcófago antes de que se Invocaran | Ambos monstruos continúan GY; ninguna Invocación Horus garantizada | Cambiar a cartas Cristron realmente disponibles |
| **INT13 — Lancea propia frente a Citree** | Lancea ya resolvió en turno rival, Citree quiere sincronizar usando materiales que deberían desterrarse | **No se presume posible** la sincronización por el efecto de Citree bajo prohibición de destierros | Registrar cadena y buscar interacción que no exija desterrar; requiere prueba específica en simulador |
| **INT14 — Súper Poli después de Smiger** | Smiger resolvió en Campo y restringe Extra a Sincronía Máquina | Garura/Mudragon son Fusión; no es legal Invocarlos desde Extra ese turno por tu Súper Poli | Planear la Fusión **antes** de usar Smiger de Campo |

**Advertencia de prueba:** en INT13 se adopta la lectura conservadora `NO_AFIRMAR_SINCRONIA` hasta verificar la interacción exacta con una simulación/ruling oficial; no es una resolución observada. Cada caso requiere fecha, mano, cadena y zonas para pasar de `CASO_DOCUMENTAL` a `PRUEBA_SIMULADOR`.

### A08 · Seis decisiones nuevas D21–D26 y Side por rival

| Decisión | ¿Cuándo? | Elegir y justificar | No asumir |
|---|---|---|---|
| **D21** | Smiger único, sin más motor | **C01** Hagoita para alteración de nivel **o V05** Elesqueletus para recuperación | Que se tienen ambos Synchro en un solo turno con una Normal |
| **D22** | Entierro Insensato + Normal disponible | **V06** para recuperar pieza Crystron desde el Deck por búsquedas encadenadas | Que Entierro invoca por sí solo |
| **D23** | Sarcófago + Hapi, Amset en Deck | **V07** para acceder a Nivel8+8 sin necesitar Amset de mano | Que Hapi único esté en Deck a pesar de haberlo robado |
| **D24** | Rival retira cartas del GY/destierro | Valorar ruta Horus establecida o Tristaros Campo y conservar amenazas | Que Smiger GY y Citree puedan operar sin sus objetivos |
| **D25** | Vas segundo, rival presenta dos monstruos compatibles con una Fusión | Super Poly hacia Garura/Fangodragón **antes** del primer bloqueo | Que la identidad de los monstruos rivales sea irrelevante |
| **D26** | Condiciones de Invocación y efectos del texto oficial | **Detener registro de la lista** hasta resolver A03 y revisar sustituciones | Que cambiar Droll al Side o alternar S02 valide el mazo |

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

**Para medir mejora real:** registrar en 20 manos la línea elegida, primer cuello de botella, número de interrupciones que sigue tolerando, invocaciones desde Extra, recursos que quedaron en GY/destierro, cartas de Side útiles y resultado; no crear porcentajes competitivos sin esos datos. Antes de reducir o aumentar monstruos, comparar si siguen existiendo los objetivos **uno-de** (Hapi, Citree, Thystvern) que las rutas suponen en Deck.

### A09 · Tres variantes nuevas con pasos V05–V07 y ocho casos H13–H20

Las **rutas principales siguen siendo C01–C07 (7)**. Las **variantes V01–V04** siguen disponibles; se añaden **V05, V06 y V07 (3)** por acceso/decisión, no tres familias tácticas nuevas. **Total de variantes: 7**; **14 secuencias documentales C+V**; **0 replays simulados**.

#### V05 · «Smiger solo → Tristaros → Elesqueletus»: alternativa a Hagoita

**Objetivo:** ante mano con **Smiger**, elegir una Sincronía Nivel7 de recuperación en lugar de la Hagoita Nivel5 de C01. **Inicio:** Smiger en mano; Campo/GY propios vacíos; Tristaros y Sulfador en Deck; Elesqueletus en Extra; Normal disponible y el rival debe activar una carta/efecto al turno siguiente.

1. En tu Main, **Normal Smiger (Nivel3)**. Activa su efecto de Campo seleccionándose **a sí mismo**; al resolver se **destruye** y llega al GY. Trae **Tristaros Cantante Nivel2** desde Deck en lugar de Citree. Se aplica restricción de Extra a **Sincronía Máquina** el resto de tu turno.
2. **Pasa turno con Tristaros en Campo**, Smiger en GY y Elesqueletus todavía en Extra. No destierres Smiger para buscar Inclusión en el mismo turno: su cláusula permite **solo uno de los dos efectos** por nombre.
3. En el turno rival, cuando éste activa una carta/efecto, encadena **Tristaros**. Si resuelve, trae **Sulfador Nivel5 desde Deck** y **justo después** Sincroniza **Tristaros2 + Sulfador5 → Elesqueletus Nivel7**, Máquina Sincronía. El monstruo recién Invocado fue usado como material obligatorio.
4. Después de que termine la cadena rival, activa el efecto de Elesqueletus **si corresponde** y recupera **Smiger del GY a mano**. **Resultado:** Elesqueletus Campo; Smiger mano; Tristaros+Sulfador GY; la activación original rival **no fue negada**.

**Diferencia frente a C01:** mismo starter de una carta, **otro Cantante, otro Synchro, otro beneficio**. C01 destierra materiales por efecto de Citree; V05 utiliza materiales de Sincronía **normales** que van al GY. **Fallo:** sin Tristaros/Sulfador restantes en Deck, sin activación rival o si efecto de Smiger no resuelve, no se acredita ese final.

#### V06 · «Entierro Insensato → Smiger GY → Inclusión → Tristaros»

**Objetivo:** darle uso de starter **condicional de una carta** a Entierro Insensato, sin inventar una Invocación inmediata. **Inicio:** Entierro Insensato en mano; Smiger, Inclusión y Tristaros en Deck, Sulfador en Deck, Elesqueletus en Extra; Campo/GY vacíos y Normal disponible; sin Droll ni Ash que bloquee las búsquedas.

1. **Activa Entierro Insensato** y **envía Smiger del Deck al GY**; esto no es destrucción ni Invocación.
2. Desde GY **destierra Smiger** para usar **su efecto de búsqueda de Mágica/Trampa Cristron**; añade **Inclusión** del Deck a mano. Smiger queda en zona desterrada.
3. Activa **Inclusión Cristron** en tu zona M/T; al activarse busca **Tristaros (otro nombre)** del Deck y lo añade a mano. Normal **Tristaros**. **Fin de tu turno propio:** Tristaros Campo, Inclusión boca arriba, Smiger desterrado; ninguna Sincronía todavía.
4. En turno rival, tras activación rival, Tristaros trae **Sulfador** del Deck y de inmediato sincroniza **2+5=Elesqueletus7**. Después de terminar toda la cadena, si el efecto de Elesqueletus puede activarse, **recupera Smiger desterrado a mano**.

**Final condicional:** Elesqueletus Campo + Inclusión boca arriba + Smiger mano; Entierro, Tristaros y Sulfador al GY. **Riesgo:** dos búsquedas secuenciales (Smiger→Inclusión→Tristaros) expuestas a **Droll/Ash**; si el rival no activa una carta/efecto, no aparece Elesqueletus. Se conserva la condición del **único Tristaros restante en Deck**, no se inventa copia.

#### V07 · «Sarcófago + Hapi en mano → dos Nivel8 → Xyz»

**Objetivo:** rescatar C05/C04 cuando **Hapi (copia única)** vino en mano y ya no puede enviarse desde el Deck. **Inicio:** **Sarcófago del Rey + Hapi** en mano; Campo/GY vacíos; **al menos una copia de Amset** en Deck; Número90/Vampiro Zombi disponibles en Extra; no hay bloqueos a Xyz.

1. **Activa Sarcófago**; usa su efecto **enviando Hapi desde mano al GY** para **mandar Amset desde Deck al GY**. No se buscó nada ni se atribuye robo.
2. Mientras controles Sarcófago, **Invoca Especial Hapi** desde GY y **Amset** desde GY por sus condiciones independientes. **Campo:** Hapi8 + Amset8; Sarcófago boca arriba.
3. **Elige UNO:** superponer ambos a **Número90** si necesitas negación de efecto de monstruo, o a **Vampiro Zombi** si priorizas molienda/valor variable. En los dos casos los Horus pasan a ser materiales Xyz.
4. **Resultado fijo:** Sarcófago + un Xyz Rango8 con dos materiales; **no** ambos Xyz simultáneamente. Con Vampiro, la molienda posterior sigue siendo de cartas **desconocidas**; con Número90, desacoplar Horus no añade destrucción por nombres Galaxia/Fotónicos.

**Lección de consistencia:** si Hapi está en mano, **C05 literal se bloquea en su paso de enviarlo desde Deck**, pero V07 reemplaza el orden de envío con cartas que **sí están disponibles**. No requiere que Hapi vuelva mágicamente al Deck.

#### H13–H20 · Ejercicios prácticos sin inventar cartas

| Caso | Mano conocida / condición rival | Secuencia recomendada | Resultado comprobable o causa de freno |
|---|---|---|---|
| **H13** | **Smiger** solo, primero; Tristaros/Sulfador en Deck | **V05**: Normal Smiger → destruye propio → SS Tristaros → esperar cadena rival | Elesqueletus y recuperar Smiger solo **si** hay activación rival y se resuelve |
| **H14** | **Entierro Insensato** solo, primero | **V06**: enviar Smiger → desterrar/traer Inclusión → buscar Tristaros/Normal | Tristaros + Inclusión preparados; Elesqueletus **no** existe hasta respuesta turno rival |
| **H15** | **Sarcófago + Hapi** en mano, Amset queda en Deck | **V07**: Hapi mano→GY, Amset Deck→GY, revivir ambos, elegir Rango8 | N.º90 **o** Vampiro, no los dos; ninguna carta inventada de molino |
| **H16** | **Smiger + Súper Polimerización**, segundo; rival exhibe 2 monstruos de mismo Tipo/Atributo y distintos nombres | **1.** Resolver Súper Poli hacia Garura si materiales válidos; **2.** después Normal Smiger y desarrollar motor | Garura **antes** del bloqueo; no Fusionar después del Smiger de Campo |
| **H17** | **Inclusión + Sulfador + Azufafnir**, pero segundo Azufafnir **no** queda en Deck | Comenzar C06 solo tras verificar objetivos; si falta segunda copia, escoger C02/recuperación si es accesible | **No** anunciar Nova/Infinito: C06 literal falla por material Nivel5 faltante |
| **H18** | **Sarcófago + Amset**, pero Hapi **ya está en GY** de una jugada anterior | No usar C05 literal de enviar Hapi desde Deck. Si Sarcófago está legalmente activo, evaluar revivir Hapi GY y enviar un Horus que sí quede en Deck | Corregir zonas antes de elegir Xyz; no activar envío sin carta en mano válida |
| **H19** | **Smiger** solo; Ash rival niega el efecto de Smiger en Campo | Normal Smiger, anunciar efecto; si es negado, **no** destruir ni traer Cantante | Smiger permanece si ningún otro efecto lo mueve; **no** C01/V05 |
| **H20** | **Amset + Smiger**; después de que Amset buscó Sarcófago, rival aplica **Droll** | **1.** Sarcófago queda en mano; **2.** puedes revivir Amset si lo activas; **3.** Smiger GY no puede completar búsqueda a mano de Inclusión este turno | C07 se detiene antes de Inclusión/Tristaros; no inventar segunda búsqueda |

**Censo A09 v3:** **7 familias C01–C07**, **7 variantes V01–V07** (incluida V05 de otro final con Smiger, V06 de otro starter y V07 de otro recurso Horus), **20 manos H01–H20**. Son **14 fichas de ruta**, no 14 replays ni 14 victorias. Una ruta se marca `PROBADA_EN_SIMULADOR` solo con mano, orden de cadena, estado por zonas y captura verificable de su resultado.

### A10 · Tres paneles didácticos nuevos (enlaces a fotos auténticas)

**P08 → V05 | «Smiger: elige Elesqueletus, no Hagoita»**

1. **Carta inicial:** Smiger `[FOTO_PENDIENTE CID12608]`, Normal en Campo. **Objetivo:** respuesta de Nivel7 y recuperar Smiger.
2. **Campo→GY:** Smiger se destruye por su efecto y trae **Tristaros** `[FOTO_PENDIENTE CID20758]` del Deck. **No** declarar el efecto de Smiger en GY este turno.
3. **Turno rival:** rival activa carta/efecto (CL1), Tristaros CL2; éste trae **Sulfador** `[FOTO_PENDIENTE CID20759]` y sincroniza **2+5** a Elesqueletus `[FOTO_PENDIENTE CID20778]`.
4. **Nueva cadena:** recuperar Smiger GY a mano si procede. **Marcador visual final:** `CAMPO[Elesqueletus7] MANO[Smiger] GY[Tristaros,Sulfador]`, rival CL1 **no negado**.

**P09 → V06 | «Entierro solo, dos búsquedas, defensa reactiva»**

1. **Entierro Insensato** `[FOTO_PENDIENTE CID5236]` envía Smiger del Deck al GY. **Sin Invocación**.
2. **Smiger GY → destierro**, añade Inclusión `[FOTO_PENDIENTE CID20798]` a mano; activa Inclusión y añade Tristaros `[FOTO_PENDIENTE CID20758]` a mano.
3. **Normal Tristaros**, pasa turno: `CAMPO[Tristaros2,Inclusión] DESTIERRO[Smiger]`.
4. En activación rival, Tristaros trae Sulfador y Sincroniza Elesqueletus; tras cadena puede recuperar Smiger desterrado. **Rama roja:** Ash/Droll entre dos búsquedas detiene el plan exacto; no aparece Elesqueletus si rival no activa.

**P10 → V07 | «Hapi en mano sí sirve»**

![Sarcófago del Rey](imagenes/19200.jpg)

![Hapi, Guía de Horus](imagenes/19155.jpg)

![Amset, Gloria de Horus](imagenes/19153.jpg)

1. **Mano:** Sarcófago+Hapi; **Amset en Deck**. Activa Sarcófago y manda Hapi **de mano a GY**, Amset **de Deck a GY**.
2. Invoca ambos del GY bajo Sarcófago: `CAMPO[Hapi8,Amset8,Sarcófago]`.
3. **Elección de final:** N.º90 `[FOTO_PENDIENTE CID13826]` para negación, o Vampiro Zombi `[imagenes/16850.jpg]` para molienda. **No dos Xyz simultáneos**.
4. **Campo final:** `Sarcófago + Xyz8[dos materiales Horus]`; ninguna identidad de carta molida está predeterminada.

**Cierre A10 v3:** 7 guías principales + 3 paneles adicionales de variantes; las otras cuatro variantes siguen enlazadas en A09. **20/39 imágenes auténticas** (19 pendientes), **0 replays de simulador**. Estado `DOCUMENTACIÓN_AVANZADA / NO_PUBLICABLE_COMO_GUIA_FOTOGRAFICA_COMPLETA`. Las referencias de CID y el texto no sustituyen fotografías ni partidas ejecutadas.

### Certificado de integridad de la iteración v3

- **Conservado sin alterar:** 70 cartas (40/15/15); 39 identidades y CIDs; todas las filas Main/Extra/Side; siete combos C01–C07; variantes V01–V04; 12 manos H01–H12; siete guías G01–G07; 20 fotos existentes; seis planes de Side.
**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.
**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.
5. Mostrar entonces endboards con **Campo / Mano / GY / Desterradas / Material Xyz** por paso y el propósito explícito de cada línea, conservando estos IDs de trazabilidad.

**Fuentes oficiales de efectos y materiales principales:** [Smiger, CID 12608](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=es); [Citree, CID 12606](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12606&ope=2&request_locale=es); [Tristaros, CID 20758](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=es); [Sulfador, CID 20759](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=es); [Azufafnir, CID 12756](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12756&ope=2&request_locale=es); [Inclusión, CID 20798](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20798&ope=2&request_locale=es); [Elesqueletus, CID 20778](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20778&ope=2&request_locale=es); [Quariongandrax, CID 12781](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12781&ope=2&request_locale=es); [Nova, CID 10870](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=10870&ope=2&request_locale=es); [Infinito, CID 11765](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11765&ope=2&request_locale=es); [Número 90, CID 13826](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13826&ope=2&request_locale=es); [El Vampiro Zombi, CID 16850](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=16850&ope=2&request_locale=es). Los 39 CIDs figuran en la única matriz A05/A06.

---

<a id="profundizacion-a01-a05"></a>

## PROFUNDIZACIÓN A01–A05 INTEGRADA (sin archivo paralelo)


> Fecha 17-11-2026. Complemento de `DECK_NUEVO_13_CRISTRON_HORUS_CONTENIDO_CURADO.md`; preserva sus **70 cartas**, incluidos Main, Extra y Side. `NUEVO_13` no es ID de producción. El estudio no equivale a partida comprobada y no modifica A06–A10.

## A01. Dos motores, tres planes y restricciones incompatibles

**Identidad:** un motor **Cristron/Crystron** de Sincronía reactiva Máquina en turno rival y otro **Horus** para presencia de Nivel 8 y Xyz. Hay además la opción **2 Nivel5 Máquina → Nova → Infinito**. Se estudian como **rutas alternativas**, nunca como todo simultáneamente accesible.

- **Plan 1, control:** Smiger y Tristaros preparan un turno rival con Citree y Sincronías adecuadas. El momento de activación de Tristaros/Citree exige el evento o fase correcta.
- **Plan 2, presencia:** Sarcófago del Rey, Amset y Hapi pueden alimentar dos Nivel8 y abrir **Número 90** o **Vampiro Zombi**, si esas piezas están realmente en Campo antes del bloqueo.
- **Plan 3, negación general:** Sulfador y Azufafnir construyen dos Nivel5 Máquina para **Nova→Infinito**, conservando los requisitos y una segunda copia de Azufafnir en el Deck cuando el efecto la presupone.
- **Bloqueo 1:** el efecto de Campo de **Smiger/Thystvern** puede restringir el resto del turno a **Sincronías Máquina**; entonces Nova/Infinito Xyz, Número 90 Xyz, S:P Link y Fusiones de Súper Polimerización quedan fuera de esa secuencia.
- **Bloqueo 2:** **Sulfador** invocado por su efecto propio impone límite de **Máquinas** desde el Extra; Nova/Infinito Máquina sí pueden ser compatibles, Número 90 no. No intercambiar ambos bloqueos como si fueran iguales.

**Fortaleza:** líneas reactivas y autónomas; **punto ciego:** escasez relativa de Cantantes, necesidad de reservar materiales y cierre del Extra por decisiones de orden. Una mano de Horus no garantiza automáticamente ruta Cristron, y viceversa.

## A02. Árbol de turno con coste, orden y alternativa

| Mano / campo observado | Elegir primero | Lo que hay que demostrar | Si falla el plan… |
|---|---|---|---|
| Smiger solo en Campo | Preparar recurso para Citree/Tristaros al turno rival | La carta buscada/enviada permanece disponible; qué efecto de Smiger se usa | No usar en el mismo turno otros efectos de Smiger prohibidos por su texto |
| Inclusión + Sulfador | Recuperación mediante Elesqueletus o extensión según otra pieza | Al activar Inclusión, la búsqueda tiene destino válido; conteo de niveles y Cantante | Si se niega la búsqueda, no aparece el monstruo de la mano ficticiamente |
| Inclusión + Sulfador + Azufafnir | Evaluar C06 Nova→Infinito | Dos Máquinas Nivel5 presentes y Nova disponible; bloqueo de Sulfador no prohíbe Máquina | Después de bloqueo Sincronía Máquina de Smiger, C06 no existe ese turno |
| Amset + Hapi | Evaluar Número 90 antes de Cristron | Dos Nivel8 reales en Campo; materiales de Número 90 no son Galaxia/Fotónico | Negar el efecto de monstruo no equivale a destruirlo en esta construcción |
| Sarcófago + Amset | Evaluar Vampiro Zombi | Registrar cartas enviadas a GY, sin predecir los molinos | No asegurar qué monstruo llega de los 4+4 enviados |
| Amset + Smiger | Valorar salida híbrida C07 | Amset descartando Smiger no activa por sí solo todos los efectos de Smiger | Si el envío se niega o no hay objetivo GY, mantener recurso real |
| Súper Polimerización + rival con materiales compatibles | Resolver Fusión antes de cierres incompatibles | Dos materiales válidos para Garura/Fangodragón del Pantano | No usar el efecto si Campo rival no tiene materiales exactos |
| Citree/Tristaros preparadas, turno del rival | Responder en la fase/activación prevista | Citree opera con no Cantante revivido; Tristaros responde a activación y exige material legal | Si no hay evento u objetivo, no simular Sincronía en turno rival |

**Filtro obligatorio:** `¿Horus Nivel8 o Máquina Sincronía? → ¿Qué efecto impone bloqueo de Extra? → ¿Se activó antes o después? → ¿Hay Cantante correcto? → ¿Se conserva recurso al pasar turno?`. Los campos finales A09 son salidas documentales sujetas a estos cinco chequeos.

## A03. Inventario y zonas auditadas

| Zona | Composición | Copias | Observación |
|---|---|---:|---|
| Main | 27 monstruos + 12 mágicas + 1 trampa | **40** | Motor Cristron + Horus; una trampa Agrupamiento |
| Extra | 15 cartas, 13 identidades | **15** | Incluye 2 F.A. Coche Trucado del Amanecer físicas |
| Side | 15 cartas | **15** | Purulia cuenta 2 Main + 1 Side en una sola identidad |
| Reserva | No registrada | **0** | No agregar opciones hipotéticas |
| **Total** | 39 identidades únicas | **70** | Transcripción sin editar |

El estudio preserva el inventario registrado y evalúa el efecto y los materiales de las cartas, no listas externas.

## A04. Evidencia y fotografía por identificador

- **39/39 CIDs** cotejados con ficha oficial Konami Neuron, cruzados con la tabla del documento principal.
- **20/39 imágenes auténticas** disponibles en `imagenes/<CID>.jpg` desde el maestro de V34; **19/39 `FOTO_PENDIENTE`**.
- Muestras reproducibles: `19153.jpg` Amset; `19155.jpg` Hapi; `19200.jpg` Sarcófago; `12950.jpg` Ash; `9279.jpg` Droll; `20500.jpg` Fuwalos; `20206.jpg` Purulia; `7445.jpg` Súper Polimerización; `15299.jpg` Gotas.
- Para las otras identidades, el enlace Konami CID sigue sirviendo como evidencia de **identidad y texto**, no como sustituto de imagen local ni de un replay.
- El estado de A04 es `IDENTIDAD_OFICIAL_COTEJADA` para 39, `FOTO_LOCAL_DISPONIBLE` para 20, `FOTO_PENDIENTE` para 19 y `SIMULADOR_NO_EJECUTADO` para todas las rutas A09.

## A05. Uso concreto y restricciones de cartas decisivas

Las **39/39 fichas originales** enumeran cada identidad con CID, Main/Extra/Side, papel y condiciones. Para profundizar la elección, se separan estas funciones:

| Cartas de la lista | Para qué sirven aquí | Error que el sistema debe impedir |
|---|---|---|
| Smiger / Thystvern / Tristaros | Acceso, reciclaje o preparar Sincronía Máquina reactiva | Usar efecto de Campo que cierre el Extra y después anunciar Xyz/Link/Fusión |
| Citree / Sulfador / Azufafnir | Cantantes y dos cuerpos Nivel5 de la ruta de Nova | Olvidar Cantante en Citree o asumir segunda copia en Deck ya robada |
| Inclusión / Elesqueletus / Agrupamiento | Buscar, recuperar recursos y control en turnos sucesivos | Activar trampa recién colocada, o gastar dos veces el mismo efecto |
| Sarcófago, Amset, Hapi | Llenar GY Horus y convertir dos Nivel8 en Xyz | Contar material Xyz como monstruo todavía en GY |
| Número 90 / Vampiro Zombi | Negación de efecto de monstruo o molino incierto | Destruir con Número 90 sin material Galaxia; elegir cartas futuras del molino |
| Nova / Infinito | Ruta Máquina a negación y absorción | Proclamar Nova luego de restricción a Sincronías Máquina |
| Garura / Fangodragón / Súper Polimerización | Remoción por Fusión bajo materiales rivales exactos | Confundir condiciones de mismo Tipo/Atributo y distinto Tipo |
| Hagoita / Quariongandrax | Sincronías por niveles y cantidades de Cantantes | Hagoita no puede auto-revivir sin Cantante Velociroid inexistente; Quarion exige ≥2 Cantantes |
| S:P / Caballero Mecánico | Salidas Link específicas | Caballero no busca «Noche Mecánica» ausente en Main; no invocar Link tras lock |
| Droll, Purulia, Fuwalos, Ash y Side | Interacción y adaptación fuera del motor | No equiparar disparadores ni colocar Side en mano del duelo 1 |

**Cierre A01–A05:** tres planes examinados, ocho casos de decisión, **70/70 copias** documentadas, **39/39 CIDs**, **20/39 fotos** y **39/39 roles** registrados. Persisten comprobaciones finas de rulings, formato y fotografías; **no hay simulaciones ni sustituciones aplicadas**.


---

<a id="auditoria-ampliada-v38"></a>
## CORTE V38 · Profundización de todos los apartados A01–A10 (17-11-2026)
**Inventario inmutable:** Main 40, Extra 15, Side 15; **39/39 identidades** con fotografía real, CID y nombre oficial cotejados.
**Estado técnico:** 14 fichas/rutas/variantes observables en A09, **0 replays de simulador aportados**, importación real sin ejecutar. Los enlaces a imágenes de cada carta están contenidos en esta misma carpeta. Las declaraciones de fotos pendientes de V35/V36 son históricas y quedan sustituidas por este corte.
**No se han cambiado ni agregado cartas.** Los análisis de efectos y requisitos no implican que el deck físico, en su estado actual, sea inscribible en un torneo.

### A01–A02 · Aperturas cuantificadas y decisiones con una finalidad
**Estas son probabilidades EXACTAS de coincidencia en una mano aleatoria de cinco, sin reemplazo; no tasas de victoria ni de resolución de combos.**
| Evento de extracción | Frecuencia exacta en cinco | Interpretación técnica |
|---|---:|---|
| Smiger o Inclusión en cinco cartas | **57.71 %** | Cálculo hipergeométrico sobre N=40, k=6 |
| Inclusión + Sulfador (coincidencia) | **6.81 %** | Dos grupos disjuntos de 3 y 2 copias; no significa efecto garantizado |
| Amset + Smiger para C07 | **9.80 %** | Dos grupos disjuntos de 3 y 3 copias; no significa efecto garantizado |

**Matriz nueva de decisiones; cada fila es una necesidad diferente, no otro combo inventado:**
| Estado de partida | Ruta/referencia | Qué conseguir y por qué | Fallo y cambio de decisión |
|---|---|---|---|
| Primero solo Smiger | C01 o V05 | Elegir Citree→Hagoita o Tristaros→Elesqueletus, NO ambas salidas | La Sincronía ocurre turno rival con un disparador |
| Primero Inclusión + Sulfador | C02 | Elesqueletus + Smiger, recuperando Inclusión desterrada | Al usar Smiger en Campo solo Sincronía Máquina ese turno |
| Primero Inclusión + Sulfador + Azufafnir | C06 | Nova→Infinito (Máquina Xyz), sin activar Smiger en Campo | Falta segunda Azufafnir en Deck o niegan búsqueda |
| Primero Amset + Hapi | C04 | Dos Horus Nivel 8 pasan a materiales del Número 90 | No son dos cuerpos libres tras Xyz |
| Segundo frente a monstruos | C05 si el molino aporta; elegir Xyz Hapi/Amset | Vampiro para presión variable, sin inventar cartas enviadas | No promete una respuesta fija ni OTK |
| Turno rival con Tristaros | C03/V05/V06 | Sincronía reactiva luego de activación de carta/efecto rival | La Sincronía no niega el CL1 original |
| Remontar si Droll cortó búsquedas | H20 / bifurcación de C07 | Conservar Sarcófago y Horus; no resolver Inclusión que no fue añadida | Una búsqueda posterior del Deck a mano está prohibida |
| Recuperar recursos desterrados | C02/V01 | Recoger carta Cristron elegible con Elesqueletus | Confirmar objetivo GY/destierro y restricciones del Extra |

### A03–A05 · Censo certificado de las cartas y fotos efectivamente recibidas
Cada fila usa la identidad **CID Konami** y la cantidad real en **Main/Extra/Side/Reserva**. La galería enlaza 1 imagen verdadera por identidad; las copias se representan por su cantidad, no por archivos duplicados.

### A06–A07 · Materiales, cadenas y condiciones del texto de las cartas
Para las cartas registradas, verificar la posibilidad de Invocación y los efectos conforme a requisitos, materiales, costes, ventanas, límites de uso por turno y recursos efectivamente disponibles. La matriz individual A05–A06 conserva las identidades y cantidades originales.

### A08 · Side y planes concretos SIN editar el inventario
**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

### A09 · Revisión de TODAS las fichas de rutas existentes, sin sumar variantes como familias nuevas
| ID original | Clasificación editorial y formato | Pasos escritos | Punto de control / prueba que falta |
|---|---|---:|---|
| **C01** | COMBO | 4 | Citree produce la Sincronía en turno rival; sus materiales acaban desterrados, no en GY. |
| **C02** | COMBO | 6 | Tras Smiger en campo no se permiten Xyz ese turno; citree y sulfador se mandan al GY por Sincronía propia. |
| **C03** | COMBO | 4 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **C04** | COMBO | 4 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **C05** | COMBO | 4 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **C06** | COMBO | 6 | Infinito necesita dos Nivel5 y conserva Nova como material; no activar Smiger de Campo. |
| **C07** | COMBO | 6 | Horus Nivel8 permanece en Campo durante la Sincronía reactiva; no es material de Elesqueletus. |
| **V01** | VARIANTE_CONDICIONAL | 4 | No es apertura autónoma: requiere salida C02 que sobrevivió hasta turno rival. |
| **V02** | VARIANTE_CONDICIONAL | 3 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **V03** | VARIANTE_CONDICIONAL | 4 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **V04** | VARIANTE_CONDICIONAL | 3 | Comprobar mano inicial, materiales, ventana, zonas finales y respuesta rival; NO simulado. |
| **V05** | VARIANTE_CONDICIONAL | 4 | Salida alterna desde Smiger: no sumar a C01 como dos tableros simultáneos. |
| **V06** | VARIANTE_CONDICIONAL | 4 | Dos búsquedas sucesivas: Entierro→Smiger→Inclusión→Tristaros, expuesto a Droll. |
| **V07** | VARIANTE_CONDICIONAL | 4 | Si Hapi ya está en mano, Sarcófago puede moverla primero al GY; elegir un solo Rango8. |

**Criterio de salida del simulador (A09):** documentar por cada ID mano de cinco, cartas previas en GY/destierro, fase, Normal utilizada, CL1/CL2, efecto una vez por turno, cartas que pasan a material Xyz, restricciones Extra, campo tras cada paso, fotografía/captura del resultado y prueba de una negación en el paso vulnerable. Estado de todos: `DOC_VERIFICADO_CID / SIN_REPLAY`; nunca `PROBADO` por leer texto o ver imágenes.

### A10 · Guías visuales ligadas a la ficha canónica, no fuentes nuevas de reglas
[Abrir la galería visual ilustrada, con paneles de acciones y las imágenes genuinas del deck](guias/GUIA_VISUAL_A01_A10.html#rutas). Cada panel enlaza al texto canónico de su ID en A09: visualizaciones resumidas NO reemplazan costes ni ventanas de A09. Si una secuencia requiere condiciones o recursos adicionales, su etiqueta aparece en el panel visual.

### Control de importación y límites verificables
**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.
- **No demostrado:** porcentaje de victoria, tasa de combos resolviendo contra interrupciones, prueba en MDPro/Omega, despliegue real en Station X, identidad real del `deck_id`, reglas locales pendientes.
- **Sin permiso para completar por invención:** Side no recibido, espacios desconocidos, reemplazos de cartas restringidas y reescritura del inventario físico. Permanecen marcados como tales.


---

<a id="verificacion-efectos-konami-v39"></a>
## CORTE V39 · Validación individual A01–A10 de rutas y requisitos (17-11-2026)
**Fuente de reglas:** textos de efecto originales de Yu-Gi-Oh! Neuron/Konami, CID por CID. No se reproduce masivamente el texto protegido; cada comprobación tiene enlaces directos a la ficha de origen.
**Cobertura de este deck:** 39/39 identidades de carta del inventario comparadas contra ficha Konami; 14/14 rutas o variantes con estado inicial, regla específica, condición de interrupción y referencia.
**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.

### A01–A02 · Declarar recursos antes del paso 1
Los escenarios de abajo distinguen una línea de una carta, una línea de dos/tres cartas y una extensión que exige un tablero o cementerio previo. Ninguna línea puede consumir cartas no presentes en la apertura o que no hayan sido buscadas por un efecto resuelto.

### A03–A05 · Integridad de las cartas originales
No se cambiaron cantidades ni la separación Main / Extra / Side. La identidad CID controla una sola imagen real, reutilizada visualmente entre copias y rutas; se conserva la evidencia fotográfica previa.

### A06–A08 · Efectos, interrupciones y Side real
Las respuestas se estudian conforme al texto de cada carta y la ventana de activación. Side y Reserva solo contienen las copias registradas físicamente; ninguna carta se incorpora por sugerencia. No hay sustituciones automáticas ni comprobación de listas externas.

### A09 · 51 fichas auditadas, comprobaciones por ID de este deck
#### C01 · verificación por texto oficial
- **Inicio exigido:** Smiger Normal; Citree disponible en Deck; Smiger objetivo de Citree en GY hasta turno rival.
- **Regla comprobada:** Smiger permite solamente UNO de sus efectos por turno; Citree sincroniza durante Main/Battle rival y destierra esos materiales.
- **Si se interrumpe / no aplica:** Si rival retira Citree antes de la ventana, no Hagoita; no buscar Inclusión con Smiger el mismo turno.
- **Textos oficiales comprobados:** [Crystron Smiger](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=en), [Crystron Citree](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12606&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C02 · verificación por texto oficial
- **Inicio exigido:** Inclusión + Sulfador en mano; Smiger, Citree, Tristaros, Thystvern en Deck.
- **Regla comprobada:** Sulfador destruye Inclusión, manda hasta 2 nombres al GY; Smiger limita Extra a Sincronías Máquina en turno propio.
- **Si se interrumpe / no aplica:** Si destruyen Inclusión antes de Sulfador o sin objetivo recuperable, no asegurar Elesqueletus + Inclusión devuelta.
- **Textos oficiales comprobados:** [Crystron Sulfador](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=en), [Crystron Eleskeletus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20778&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C03 · verificación por texto oficial
- **Inicio exigido:** Tristaros Normal permanece al turno rival; Sulfador en Deck; rival activa una carta/efecto.
- **Regla comprobada:** Tristaros responde a una activación rival y obliga a sincronizar usando al monstruo que Invoca del Deck.
- **Si se interrumpe / no aplica:** El CL1 rival no queda negado por sincronizar; sin disparador rival no hay Synchro por esta línea.
- **Textos oficiales comprobados:** [Crystron Tristaros](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C04 · verificación por texto oficial
- **Inicio exigido:** Amset e Hapi inicialmente en mano; Número90 en Extra; Sarcófago en Deck.
- **Regla comprobada:** Imsety envía dos cartas de mano incluyéndose y busca Sarcófago; los dos Horus invocados son materiales del único Rango8.
- **Si se interrumpe / no aplica:** Si niegan la búsqueda de Sarcófago no hay acceso por las condiciones descritas; robo opcional no se conoce.
- **Textos oficiales comprobados:** [Imsety, Glory of Horus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19153&ope=2&request_locale=en), [Hapi, Guidance of Horus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19155&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C05 · verificación por texto oficial
- **Inicio exigido:** Sarcófago + Amset en mano; Hapi en Deck; Vampiro Zombi en Extra.
- **Regla comprobada:** Sarcófago manda una carta de mano a GY y después Horus del Deck; la molienda del Vampiro es aleatoria.
- **Si se interrumpe / no aplica:** No prometer que el molino contiene monstruos ni una tercera invocación; el material desacoplado deja de ser material.
- **Textos oficiales comprobados:** [King's Sarcophagus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19200&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C06 · verificación por texto oficial
- **Inicio exigido:** Inclusión + Sulfador + Azufafnir en mano; Smiger y 2.ª Azufafnir disponibles.
- **Regla comprobada:** Sulfador limita Extra a Máquinas, que permite Xyz Nova; se descarta Smiger sin activar su efecto de campo.
- **Si se interrumpe / no aplica:** Sin segunda Azufafnir en Deck o sin dos Máquina Nivel5, no Nova; no usar el efecto de Smiger en campo.
- **Textos oficiales comprobados:** [Crystron Sulfador](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=en), [Crystron Sulfefnir](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12756&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### C07 · verificación por texto oficial
- **Inicio exigido:** Amset + Smiger en mano; Sarcófago e Inclusión en Deck; Tristaros y Sulfador disponibles.
- **Regla comprobada:** Smiger desterrado busca M/T sin imponer el bloqueo del efecto de campo; Tristaros espera activación rival.
- **Si se interrumpe / no aplica:** Si Droll aplica después de Sarcófago, se pierde Inclusión; Amset Nivel8 NO cuenta como material de Synchro Nivel7.
- **Textos oficiales comprobados:** [Crystron Smiger](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=en), [Crystron Tristaros](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V01 · verificación por texto oficial
- **Inicio exigido:** Tablero completo de C02 y un turno rival posterior; Citree en GY; segundo Tristaros y Sulfador en Deck.
- **Regla comprobada:** Tristaros en GY destruye Synchro propio para Invocar 2 Cristron; rival debe activar para el Tristaros de campo.
- **Si se interrumpe / no aplica:** Es EXTENSIÓN multi-turno, no una mano de una carta; comprobar niveles 2+2+5 y 2 Cantantes.
- **Textos oficiales comprobados:** [Crystron Tristaros](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=en), [Crystron Quariongandrax](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12781&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V02 · verificación por texto oficial
- **Inicio exigido:** Inclusión en mano; Smiger y Citree en Deck; turno rival siguiente.
- **Regla comprobada:** Es acceso a C01, mismo resultado, no otra familia independiente de combo.
- **Si se interrumpe / no aplica:** Sin Citree sobreviviendo hasta turno rival no se sincroniza Hagoita.
- **Textos oficiales comprobados:** [Crystron Inclusion](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20798&ope=2&request_locale=en), [Crystron Citree](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12606&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V03 · verificación por texto oficial
- **Inicio exigido:** Azufafnir + Smiger en mano; Tristaros en Deck; Agrupamiento en Deck.
- **Regla comprobada:** Smiger se usa desde GY para buscar Trampa; Agrupamiento colocada no se activa el turno de colocación; en turno rival apunta 1 o 2.
- **Si se interrumpe / no aplica:** Sin 1 Cristron para reciclar no destruye; el segundo blanco requiere Crystron Synchro controlado.
- **Textos oficiales comprobados:** [Crystron Cluster](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20817&ope=2&request_locale=en), [Crystron Sulfefnir](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12756&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V04 · verificación por texto oficial
- **Inicio exigido:** Exactamente primeros cuatro pasos de C02 resueltos; Destructor Samurái en Extra.
- **Regla comprobada:** Cambiar Elesqueletus por Samurai Destroyer pierde recuperación de Inclusión; sigue legal con lock Synchro Máquina.
- **Si se interrumpe / no aplica:** Si Citree o Sulfador ya salió del campo, no hay materiales 2+5 para esta variante.
- **Textos oficiales comprobados:** [Crystron Smiger](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=en), [Crystron Sulfador](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20759&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V05 · verificación por texto oficial
- **Inicio exigido:** Smiger en mano; Tristaros y Sulfador disponibles en Deck; espera turno rival.
- **Regla comprobada:** Ruta ALTERNATIVA a C01, no suma Hagoita + Elesqueletus: Tristaros invoca Sulfador y sincroniza.
- **Si se interrumpe / no aplica:** Sin activación rival o si Tristaros fue negado, no afirmar Elesqueletus.
- **Textos oficiales comprobados:** [Crystron Tristaros](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20758&ope=2&request_locale=en), [Crystron Smiger](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V06 · verificación por texto oficial
- **Inicio exigido:** Entierro Insensato en mano; Smiger, Inclusión, Tristaros y Sulfador en Deck.
- **Regla comprobada:** Enviar Smiger no es destruirlo; se destierra para buscar Inclusión; Tristaros sincroniza al activarse algo rival.
- **Si se interrumpe / no aplica:** Droll después de 1.ª adición puede impedir la siguiente búsqueda de Inclusión; no contar recursos no añadidos.
- **Textos oficiales comprobados:** [Crystron Smiger](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12608&ope=2&request_locale=en), [Crystron Inclusion](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20798&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

#### V07 · verificación por texto oficial
- **Inicio exigido:** Sarcófago + Hapi en mano; Amset en Deck; un Rango8 concreto en Extra.
- **Regla comprobada:** Enviar Hapi de mano por Sarcófago, mover Amset Deck→GY, invocar ambos Horus y elegir SOLO un Xyz.
- **Si se interrumpe / no aplica:** Si Sarcófago no permanece boca arriba no invocar Horus del GY por esa condición; Xyz no garantiza material al turno siguiente.
- **Textos oficiales comprobados:** [King's Sarcophagus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19200&ope=2&request_locale=en), [Hapi, Guidance of Horus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19155&ope=2&request_locale=en).
- **Ensayo de simulador:** NO APORTADO; este control es documental, no ejecución.

### A10 · Revisión de la guía de imágenes
Cada ficha A09 tiene su panel ilustrado y, ahora, su condición de inicio y respuesta ante interrupciones. Se abren dentro de `guias/GUIA_VISUAL_A01_A10.html#rutas`. Las imágenes locales tienen CID verificable.

### Criterio formal para decir «100 %»
| Rubro | Estado V39 |
|---|---|
| Identidades y fotografías efectivamente identificadas | **39/39** |
| Fichas A09 revisadas con texto oficial | **14/14** |
| Ensayos ejecutados en simulador, con estados y replays | **0; pendiente** |
| Registro de importación ejecutado dentro de Station X | **No ejecutado** |
| Cambios automáticos de cartas/cantidades | **No autorizados** |
| Side faltante y/o carta sin imagen original | **Pendiente de datos del propietario si aplica** |

**Control documental:** respetar los materiales, costes, zonas, ventanas, límites por turno y recursos del inventario físico; no se atribuyen simulaciones ejecutadas.


---

<a id="tactica-y-probabilidad-v40"></a>
## CORTE V40 · Análisis de apertura, acceso al Extra y metajuego sin inventario nuevo (17-11-2026)

### A01–A02 · Probabilidades exactas de apertura de 5 cartas

Se calculan combinaciones sin reemplazo sobre **únicamente el Main Deck físico**. **No son tasas de victoria, éxito de combo ni porcentajes de matchup.** Los eventos «Y» indican coincidencia física de grupos en cinco cartas.

| Coincidencia física en mano de 5 | Probabilidad exacta | Interpretación |
|---|---:|---|
| ≥1 Smiger o Inclusión | **57.71 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| Inclusión Y Sulfador | **6.81 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| Inclusión Y Sulfador Y Azufafnir (C06) | **1.58 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| Amset Y Smiger | **9.80 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| Amset Y Sarcófago | **6.81 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| ≥1 Amset o Sarcófago | **50.66 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| ≥1 Gotas o Súper Polimerización | **57.71 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |
| ≥1 Entierro Insensato | **12.50 %** | NO garantiza jugar la ruta: requiere zona, costes y resoluciones. |

**Cómo usar estos números:** un evento de extracción alto sirve para elegir qué ensayar, no garantiza que el efecto resuelva. Revisar si una misma carta aparece en Main y Side: solo cuenta la cantidad del Main.

### A03–A07 · Cómo invocar y para qué utilizar cada monstruo del Extra Deck

Requisitos abreviados cotejados por CID con texto oficial; cuando exista un procedimiento alterno (Purrely, Santuario, ZEUS, Nova/Infinity o Metamorfosis) debe usarse **la condición especial de la ficha**, no inventar materiales. La columna de función compara utilidad de tablero/duelo.

| Copia(s) / Monstruo del Extra | Materiales / acceso | Función y decisión |
|---|---|---|
| 2 × [F.A. Coche Trucado del Amanecer](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13710&ope=2&request_locale=en) | 1 Cantante + 1 o más no Cantantes; Sincronía | Requiere materiales, zona y ventana de efecto comprobables; ruta documental condicionada |
| 2 × [Cristron Elesqueletus](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20778&ope=2&request_locale=en) | 1 Cantante + 1 o más no Cantantes; Sincronía | Sincronía Nivel7: recupera Cristron de GY/destierro; si destruida estando sincronizada, revive. |
| 1 × [Cristron Quariongandrax](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12781&ope=2&request_locale=en) | 2 o más Cantantes + 1 no Cantante; Sincronía | Sincronía Nivel9 con ≥2 Cantantes: destierra hasta tantos monstruos rivales como materiales reales. |
| 1 × [S:P Pequeña Caballera](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=19188&ope=2&request_locale=en) | Enlace 2: 2 monstruos de efecto. | Link2 de dos efectos; reacción que destierra temporalmente 2 monstruos. |
| 1 × [Caballero Mecánico](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=20787&ope=2&request_locale=en) | Enlace 1: 1 Máquina que NO sea de Enlace y tenga ATK original de 1000 o menos. | Link1 Máquina débil no Link: acceso y posible conversión de Continua M/T, no generalizar. |
| 1 × [Ciber Dragón del Infinito](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=11765&ope=2&request_locale=en) | 3 monstruos Nivel6 LUZ Máquina; Xyz | Xyz por Nova como material; negación rápida con desacople y cuenta de materiales. |
| 1 × [Ciber Dragón Nova](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=10870&ope=2&request_locale=en) | 2 monstruos Nivel5 Máquina; Xyz | Necesita 2 Máquinas Nivel5; alternativa C06 sin bloquearse por Smiger en campo. |
| 1 × [Hagoita de Alta-Velociroid](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=12157&ope=2&request_locale=en) | 1 Cantante + 1 o más no Cantantes; Sincronía | Destino Nivel5 de Citree en turno rival, citree+Smiger usados salen desterrados. |
| 1 × [Número 90: Señor Fotónico de Ojos Galácticos](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13826&ope=2&request_locale=en) | 2 monstruos Nivel8; Xyz | Rango8 Horus que conserva interrupción de efecto de monstruo con sus condiciones. |
| 1 × [El Vampiro Zombi](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=16850&ope=2&request_locale=en) | 2 o más monstruos Nivel 8; Xyz | Rango8 Horus que muele cartas aleatorias de ambos Decks; no fijar resultados. |
| 1 × [Destructor Samurái](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13360&ope=2&request_locale=en) | 1 Cantante + 1 o más no Cantantes; Sincronía | Sincronía Máquina Nivel7 para combate contra efectos durante Damage Step. |
| 1 × [Garura, Alas de Vida Resonante](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=17746&ope=2&request_locale=en) | Fusión: 2 monstruos de igual Tipo y Atributo pero nombres diferentes. | Fusión útil con Súper Polimerización si rival ofrece mismo Tipo/Atributo de nombres distintos. |
| 1 × [Fangodragón del Pantano](https://www.db.yugioh-card.com/yugiohdb/card_search.action?cid=13454&ope=2&request_locale=en) | Fusión: 2 monstruos con igual Atributo y Tipos diferentes. | Fusión útil con Súper Polimerización si existen dos Atributos iguales y Tipos distintos. |

### A08 · Laboratorio estratégico de seis clases de rival

Estos son **30 escenarios editoriales para cinco decks**: no predicciones de metajuego, duelos simulados ni cambios ejecutados. Cada uno distingue primer/segundo y señala Side físico real.

| Rival / situación | Si empiezas | Si vas segundo | Side físico / posibilidad | Error a evitar |
|---|---|---|---|---|
| Oponente encadena mucha búsqueda | Preparar Citree o Tristaros y recursos en GY para sincronizar en turno rival. | Amset y Sarcófago permiten presión y continuidad; comparar las respuestas disponibles. | Droll ×3 en Main, elegir momento de activación según cadena |
| Destierro de GY como plan rival | Preferir línea Horus de dos Nivel8 si Crystron necesita Cementerio. | Priorizar conservar Smiger para inclusión y remover pieza rival antes de extender. | Lancea ×2 Side, SOLO turno rival; tensiona Crystron que quiere desterrar. | Lancea puede bloquear búsqueda de Smiger y efectos en GY en el turno donde esté activa. |
| Tablero de monstruos con negaciones | Preparar Tristaros reactivo sin declarar que su Synchro niega la cadena. | Gotas/Súper Polimerización solo con objetivos y materiales correctos. | Cazadora del Caos ×2 Side versus planes específicos. | Super Polimerización del Main no siempre tiene Fusión objetivo Garura/Dragón válido. |
| Rival de backrow / trampas | Sarcófago ofrece presión recurrente, pero no niega M/T. | Usar Cluster contra boca arriba cuando haya un Cristron reciclable. | Juicio ×3 y Regaño ×1 del Side, sujetos a ventanas y costes propios. | Sin monstruo Sincronía Cristron, Cluster necesita objetivo elegible y los recursos descritos. |
| Rival usa muchas invocaciones Extra | Decidir si Quariongandrax vale riesgo de dos cantantes y turno rival. | Número90 o Vampiro requieren dos Horus Nivel8; escoger una sola ruta. | Fuwalos ×3 Main y Purulia física Main2+Side1 según evento. | No suponer que robo de handtraps o molino Vampiro da cartas predeterminadas. |
| Grind tras perder Smiger / Citree | Sulfador recupera motor y Elesqueletus rescata Cristron de GY/destierro. | Sincronizar con materiales exactos; Nova solo si no hubo bloqueo de Smiger. | Llamado y Talento físicos del Side tienen efectos condicionales distintos. | El límite de Extra de Smiger (Sincronía Máquina) difiere del de Sulfador (Máquina). |

### A09–A10 · Lectura de las guías y reglas de finalización

- [Abrir las seis decisiones estratégicas visuales](guias/GUIA_VISUAL_A01_A10.html#tacticas-v40) y después navegar a las rutas ilustradas A09.
- La lista original, el número de copias, los nombres de ruta y las fotografías no se cambiaron. Se añadieron **únicamente análisis**.
- Las 51 rutas de V39 siguen clasificadas como comprobación documental con 0 replays reales; NO declarar legal una carta prohibida, ni importar Side inexistente.
- Las recomendaciones de mejora son opcionales: solo el usuario puede autorizar cambios a las cartas físicas; los análisis conservan las listas originales. GOAT mantiene su contexto histórico.
